# Guide 2 - Deploy for real use (with PostgreSQL)

Two things are needed: (A) a PostgreSQL database that keeps your data safely, (B) a server that runs the app.

## A. Database (pick one)
- **Neon (neon.tech) - free tier, easiest.** Sign up > Create project > copy the "connection string"
  (starts with postgres://). Free: 0.5 GB (enough for roughly 100K bills), data is kept when idle. Free tier keeps only
  a short history, so ALSO run `npm run backup` regularly.
- **Supabase** - similar; free projects pause after a week without use (data kept, must be un-paused).
- **Render PostgreSQL / Railway - paid (about $7/month)** with automatic daily backups. Recommended for real payments data.

## B. Server (pick one)
- **Render.com Web Service**: connect your GitHub repo, Build Command `npm install && npm run build`,
  Start Command `npm start`. Add Environment variable  DATABASE_URL = (your connection string).
  Choose an instance with **at least 2 GB RAM** for 100K bills (Free/512 MB is OK for testing only; it also sleeps when idle).
- **Oracle Cloud "Always Free" VM** - truly free, 2 GB+ RAM and PostgreSQL can run on the same machine,
  but a technical person must set it up and schedule backups.
- Any Node.js host (Railway, Fly.io, DigitalOcean, VPS): same build/start commands, same DATABASE_URL.

## C. After deploying
1. Open the link, log in admin / admin123, change the password.
2. Admin: add campuses/budget codes, users, employees, bank accounts, offices.
3. Take one bill through every stage and check Reports.
4. Take a backup: `npm run backup` (or your database provider's backup button) and keep the file safely.

## Honest limits
- One server process runs the accounting logic (like Google's script lock). Dozens of simultaneous users are fine;
  hundreds of heavy users would need a later phase (screens asking the database directly).
- "Free" has no guarantee and no support. For payments data, budget about $7-15 per month for managed backups.
