# Your data now lives in real database tables (Step 2)

**Nothing for you to do.** Start the project as before (`npm install`, `npm start`). The first time it starts on a
database that was created by the previous version, it moves your data into the new tables automatically
(you will see lines such as `moved "Entries" (100000 rows) into its own table`). Take a backup first with `npm run backup`
if you already have real data.

## What changed
* Every Google-Sheet tab is now a proper table: `entries`, `users`, `campuses`, `budget_heads`, `allocations`, `vendors`,
  `employees`, `students`, `payment_batches`, `diary`, `payment_confirmations`, ... (30 in all).
* Every column is a real typed column: amounts and rates are numbers, dates are dates, yes/no fields are true/false,
  the rest is text. Column names are lower-case (`EntryID` -> `entry_id`, `CNIC_NTN` -> `cnic_ntn`).
* Fast look-up indexes exist on the columns you search by (entry id, status, financial year, CNIC/NTN, batch id, ...).
* The three duplicate tabs **VendorEntries, EmployeeEntries, StudentEntries** are no longer stored twice. They are
  database **views** (`vendor_entries`, `employee_entries`, `student_entries`) that always show the current bills.
  This also removes about three times the wasted space and the risk of them going out of date.

## Why this matters to you
* Any reporting tool (Metabase, Power BI, Excel via ODBC, pgAdmin, Neon/Supabase "SQL editor") can now read your data directly, e.g.
  `select status, count(*), sum(amount) from entries where fy='2026-27' group by status;`
* The database enforces the structure; backups and restores use standard PostgreSQL tools (`pg_dump`).

## Important rules (please read)
1. **Read, do not edit, in the SQL tools.** The application works from the exact copy kept in a hidden `_raw` column of each table.
   Changing a normal column with SQL would not change what the application shows. Make changes only through the application screens.
2. If a value does not fit its column type (for example text typed in an amount column) the typed column stays empty for that
   one cell; the application still keeps and shows the exact original value.
3. `npm run backup` still works and is the simplest backup. For a hosted database also use the provider's own backups.

## Honest limits
The accounting screens still work on an in-memory copy of the tables (this is what makes them fast) and write every change to the database
before answering. That is comfortable for several hundred thousand bills on a server with 2 GB or more of memory. Making every screen
ask the database directly is a much larger rewrite; it is not needed at 100K bills.
