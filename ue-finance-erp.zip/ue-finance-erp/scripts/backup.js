/* Saves a complete copy of ALL data to data/backups/backup-<date>.json.gz  (run:  npm run backup)
   Works with PostgreSQL (DATABASE_URL) or the built-in database. Keep copies somewhere safe (e.g. Google Drive). */
process.env.TZ = 'Asia/Karachi';
const fs = require('fs'), path = require('path'), zlib = require('zlib');
const store = require('../server/store');
(async () => {
  const kind = await store.initStore();
  const out = { exportedAt: new Date().toISOString(), storage: kind, props: Object.assign({}, store.state.props, { GEMINI_API_KEY: undefined }), sheets: {} };
  for (const [name, d] of Object.entries(store.state.sheets)) {
    const header = d.rows[0] || [];
    out.sheets[name] = { columns: header, rows: d.rows.slice(1).map(r => r.map(c => (c instanceof Date ? c.toISOString() : c))) };
  }
  const dir = path.join(store.DATA_DIR, 'backups'); fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, 'backup-' + new Date().toISOString().slice(0, 10) + '.json.gz');
  fs.writeFileSync(file, zlib.gzipSync(JSON.stringify(out)));
  console.log('Backup saved: ' + file + ' (' + Object.values(out.sheets).reduce((n, s) => n + s.rows.length, 0) + ' rows)');
  await store.closeStore(); process.exit(0);
})().catch(e => { console.error('Backup failed: ' + e.message); process.exit(1); });
