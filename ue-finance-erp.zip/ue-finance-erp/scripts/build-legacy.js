/* ============================================================
   build-legacy.js - turns the original Google Apps Script web page
   (legacy-src/*.html) into the three plain files the React website
   loads: body.html (screens), styles.css and scripts.js.
   Runs automatically as part of "npm run build".
   ============================================================ */
const fs = require('fs');
const path = require('path');

const SRC = path.join(__dirname, '..', 'legacy-src');
const OUT = path.join(__dirname, '..', 'client', 'public', 'legacy');
fs.mkdirSync(OUT, { recursive: true });

const read = f => fs.readFileSync(path.join(SRC, f + '.html'), 'utf8');

const stripTag = (text, tag) => text.replace(new RegExp('^\\s*<' + tag + '[^>]*>', 'i'), '').replace(new RegExp('</' + tag + '>\\s*$', 'i'), '');

// 1) styles
fs.writeFileSync(path.join(OUT, 'styles.css'), stripTag(read('Styles').trim(), 'style'));

// 2) scripts (Scripts.html first, then ScriptsDiary.html, which deliberately overrides some of its functions)
const scripts = stripTag(read('Scripts').trim(), 'script') + '\n\n' + stripTag(read('ScriptsDiary').trim(), 'script');
fs.writeFileSync(path.join(OUT, 'scripts.js'), scripts);

// 3) the page body, with every include('...') replaced by that file's content
let index = read('Index');
const body = index.slice(index.indexOf('<body>') + 6, index.lastIndexOf('</body>'));
const html = body.replace(/<\?!=\s*include\('([A-Za-z]+)'\);?\s*\?>/g, (m, name) => {
  if (name === 'Scripts' || name === 'ScriptsDiary') return '';
  return read(name);
});
if (/<\?!=/.test(html)) throw new Error('An include() was not replaced in Index.html');
fs.writeFileSync(path.join(OUT, 'body.html'), html);

// 4) legacy.html - the not-yet-converted screens (Diary, New Entry, Reports, Admin) as one page shown inside the React shell
const page = '<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">\n' +
  '<title>Legacy screens</title>\n<link rel="stylesheet" href="/legacy/styles.css">\n' +
  '<style>header, nav.tabs { display:none !important; } #loginScreen { display:none !important; }</style></head>\n<body>\n' +
  html + '\n<script src="/legacy/bridge.js"></script>\n<script src="/legacy/scripts.js"></script>\n<script src="/legacy/frame.js"></script>\n' +
  '<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>\n' +
  '<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js"></script>\n</body></html>';
fs.writeFileSync(path.join(OUT, '..', 'legacy.html'), page);

console.log('Legacy screens built: body.html ' + html.length + ' bytes, scripts.js ' + scripts.length + ' bytes.');
