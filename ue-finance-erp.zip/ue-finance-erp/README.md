# UE Finance ERP - Node.js + React + PostgreSQL (phase 3 - database tables + first real React screens)

Your Google Apps Script project, running on Node.js with a React website and a REAL database.
Your accounting logic (`server/gas/*.gs`) is still your original code; `server/gas-shim.js` stands in for Google Sheets.

First login: **admin / admin123** (change it when asked).

## Run
    npm install
    npm start          -> http://localhost:3000

## Where data is stored (automatic)
| Setting | Storage |
|---|---|
| `DATABASE_URL` set (postgres://...) | **PostgreSQL** - use this in production |
| nothing set | built-in PostgreSQL (PGlite) in `data/pgdata` - testing / StackBlitz |
| `STORAGE=file` | JSON file - last resort |

Every change is saved to the database BEFORE the screen says "saved". Only changed rows are written.

## Measured with 100,000 bills (real PostgreSQL 16)
save a bill ~1-2.5 s, move a bill between stages ~0.4 s, open a list ~0.3 s, yearly report ~1 s, start-up load ~1.8 s. Database size ~140 MB.
Memory used: about 0.7 GB, so host it on a server with at least 2 GB RAM.

## Backups
`npm run backup` writes data/backups/backup-DATE.json.gz (all data). Also enable your database provider's daily backups.

## Other settings
`PORT`, `DATA_DIR`, `PGSSL=disable` (only for a local database without SSL). `npm test` runs the self-test
(`TEST_DATABASE_URL=postgres://... npm test` tests against your PostgreSQL).

See **GUIDE_3_YOUR_DATABASE_TABLES.md** for what the database tables look like and how your old data is moved automatically.
See **GUIDE_4_WHAT_IS_NOW_REAL_REACT.md** for which screens are real React pages now and which are still the original screens.
