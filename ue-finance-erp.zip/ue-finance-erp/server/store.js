/* ============================================================
   store.js - the database layer (phase 2).

   All working data is held in memory (that is what makes every
   screen fast, even with 100,000+ bills) and EVERY change is saved
   to a real database BEFORE the server answers the user:

     * PostgreSQL ........ when the DATABASE_URL setting is present
                           (production: Neon, Supabase, Render, your own server)
     * PGlite ............ a built-in real PostgreSQL stored in data/pgdata
                           (testing, StackBlitz, small installations)
     * JSON file ......... last-resort fallback (set STORAGE=file)

   Only the rows that changed are written (not the whole database).
   If a save fails, the change stays queued and the user is told.
   ============================================================ */
const fs = require('fs');
const path = require('path');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_FILE = path.join(DATA_DIR, 'db.json');

/* sheets[name] = { rows:[[cells]], rids:[rowId per row], textCols:[], nextRid, _lc, _cache } */
const state = { sheets: {}, props: {}, blobs: {} };

const dirty = { rows: new Map(), deletes: new Map(), meta: new Set(), props: new Set(), blobs: new Set() };
const key = (s, r) => s + '\u0000' + r;
function markRow(sheet, rid) { dirty.rows.set(key(sheet, rid), [sheet, rid]); }
function markDelete(sheet, rid) { dirty.rows.delete(key(sheet, rid)); dirty.deletes.set(key(sheet, rid), [sheet, rid]); }
function markMeta(sheet) { dirty.meta.add(sheet); }
function markProp(k) { dirty.props.add(k); }
function markBlob(id) { dirty.blobs.add(id); }
function isDirty() { return dirty.rows.size || dirty.deletes.size || dirty.meta.size || dirty.props.size || dirty.blobs.size; }

/* ---- cell encoding: a Date is stored as "\u0001D<iso>" so JSON keeps it exactly ---- */
function encodeRow(row) {
  return JSON.stringify(row.map(c => (c instanceof Date ? '\u0001D' + (isNaN(c) ? '' : c.toISOString()) : (c === undefined ? '' : c))));
}
function decodeRow(text) {
  const arr = JSON.parse(text);
  for (let i = 0; i < arr.length; i++) {
    const c = arr[i];
    if (typeof c === 'string' && c.charCodeAt(0) === 1 && c.charCodeAt(1) === 68) arr[i] = c.length > 2 ? new Date(c.slice(2)) : new Date(NaN);
  }
  return arr;
}

function newSheetData() { return { rows: [], rids: [], textCols: [], nextRid: 1, _lc: 0, _cache: new WeakMap(), _sig: '' }; }

/* ================= adapters ================= */
const SC = require('./schema');
const q_ = n => '"' + n.replace(/"/g, '""') + '"';

class SqlAdapter {
  constructor(url, schema) {
    this.url = url; this.schema = schema || { sheets: {} };
    this.kind = url ? 'PostgreSQL' : 'PGlite (built-in PostgreSQL)';
    this.tables = {};   // sheet -> { sig, cols, table }
  }
  isRel(sheet) { return !!this.schema.sheets[sheet] && !SC.VIEWS[sheet]; }
  async init() {
    if (this.url) {
      const { Pool } = require('pg');
      const local = /localhost|127\.0\.0\.1/.test(this.url) || process.env.PGSSL === 'disable';
      this.pool = new Pool({ connectionString: this.url, max: 4, ssl: local ? undefined : { rejectUnauthorized: false } });
      this.query = (sql, p) => this.pool.query(sql, p);
      this.tx = async fn => {
        const c = await this.pool.connect();
        try { await c.query('BEGIN'); const r = await fn({ query: (s, p) => c.query(s, p) }); await c.query('COMMIT'); return r; }
        catch (e) { try { await c.query('ROLLBACK'); } catch (x) {} throw e; }
        finally { c.release(); }
      };
    } else {
      const { PGlite } = require('@electric-sql/pglite');
      const dir = process.env.PGLITE_DIR || path.join(DATA_DIR, 'pgdata');
      this.db = process.env.PGLITE_MEMORY ? new PGlite() : new PGlite(dir);
      await this.db.waitReady;
      this.query = (sql, p) => this.db.query(sql, p);
      this.tx = fn => this.db.transaction(tx => fn({ query: (s, p) => tx.query(s, p) }));
    }
    await this.query('CREATE TABLE IF NOT EXISTS sheet_rows (sheet text NOT NULL, rid bigint NOT NULL, data text NOT NULL, PRIMARY KEY (sheet, rid))');
    await this.query('CREATE TABLE IF NOT EXISTS sheet_meta (sheet text PRIMARY KEY, text_cols text NOT NULL, next_rid bigint NOT NULL)');
    await this.query('ALTER TABLE sheet_meta ADD COLUMN IF NOT EXISTS header text');
    await this.query('ALTER TABLE sheet_meta ADD COLUMN IF NOT EXISTS header_rid bigint');
    await this.query('ALTER TABLE sheet_meta ADD COLUMN IF NOT EXISTS rel boolean NOT NULL DEFAULT false');
    await this.query('CREATE TABLE IF NOT EXISTS props (k text PRIMARY KEY, v text NOT NULL)');
    await this.query('CREATE TABLE IF NOT EXISTS blobs (id text PRIMARY KEY, name text, mime text, folder text, b64 text NOT NULL)');
    // real tables for every sheet (created empty on a new database)
    for (const sheet of Object.keys(this.schema.sheets)) if (this.isRel(sheet)) await this.ensureTable(this.query, sheet, this.schema.sheets[sheet]);
    await this.migrateFromPhase1();
    await this.createViews();
  }

  /* make sure the table (and every column and index) for this sheet exists */
  async ensureTable(q, sheet, header) {
    const sig = JSON.stringify(header);
    const known = this.tables[sheet];
    if (known && known.sig === sig) return known;
    const table = SC.snake(sheet), cols = SC.columnsFor(header);
    await q('CREATE TABLE IF NOT EXISTS ' + q_(table) + ' (rid bigint PRIMARY KEY, _raw text NOT NULL)');
    for (const c of cols) await q('ALTER TABLE ' + q_(table) + ' ADD COLUMN IF NOT EXISTS ' + q_(c.name) + ' ' + c.type);
    for (const c of cols) if (SC.INDEXED.has(c.name)) await q('CREATE INDEX IF NOT EXISTS ' + q_(table + '_' + c.name + '_idx') + ' ON ' + q_(table) + ' (' + q_(c.name) + ')');
    return (this.tables[sheet] = { sig, cols, table });
  }
  async createViews() {
    for (const v of Object.keys(SC.VIEWS)) {
      const base = this.tables[SC.VIEWS[v].of]; if (!base) continue;
      const list = ['rid'].concat(base.cols.map(c => q_(c.name))).join(', ');
      await this.query('DROP VIEW IF EXISTS ' + q_(SC.snake(v)));
      await this.query('CREATE VIEW ' + q_(SC.snake(v)) + ' AS SELECT ' + list + ' FROM ' + q_(base.table) + ' WHERE ' + SC.VIEWS[v].where);
    }
  }

  /* insert / update rows of one sheet table (typed columns + the exact row in _raw) */
  async upsertRows(q, sheet, header, rows) {
    const t = await this.ensureTable(q, sheet, header), cols = t.cols, n = cols.length + 2;
    const per = Math.max(1, Math.floor(60000 / n));
    const names = ['rid', '_raw'].concat(cols.map(c => q_(c.name))).join(',');
    const upd = ['_raw'].concat(cols.map(c => q_(c.name))).map(c => c === '_raw' ? '_raw = EXCLUDED._raw' : c + ' = EXCLUDED.' + c).join(', ');
    for (let i = 0; i < rows.length; i += per) {
      const part = rows.slice(i, i + per), params = [], tuples = [];
      for (let j = 0; j < part.length; j++) {
        const r = part[j], base = params.length, ph = new Array(n);
        params.push(r.rid, r.data);
        for (let k = 0; k < cols.length; k++) params.push(SC.convert(r.cells[cols[k].i], cols[k].type));
        for (let k = 0; k < n; k++) ph[k] = '$' + (base + k + 1);
        tuples.push('(' + ph.join(',') + ')');
      }
      await q('INSERT INTO ' + q_(t.table) + ' (' + names + ') VALUES ' + tuples.join(',') + ' ON CONFLICT (rid) DO UPDATE SET ' + upd, params);
    }
  }

  /* one-time: move data saved by the first database version (generic sheet_rows) into the real tables */
  async migrateFromPhase1() {
    const old = (await this.query('SELECT sheet FROM sheet_meta WHERE rel = false')).rows.map(r => r.sheet);
    for (const sheet of old) {
      if (SC.VIEWS[sheet]) {   // duplicate copy of Entries - replaced by a view
        await this.query('DELETE FROM sheet_rows WHERE sheet=$1', [sheet]); await this.query('DELETE FROM sheet_meta WHERE sheet=$1', [sheet]);
        continue;
      }
      if (!this.isRel(sheet)) continue;
      const rows = []; let last = 0;
      for (;;) {
        const r = (await this.query('SELECT rid, data FROM sheet_rows WHERE sheet=$1 AND rid > $2 ORDER BY rid LIMIT 20000', [sheet, last])).rows;
        if (!r.length) break;
        for (const x of r) rows.push({ rid: Number(x.rid), data: x.data });
        last = rows[rows.length - 1].rid;
      }
      const hdr = rows.length ? decodeRow(rows[0].data) : this.schema.sheets[sheet];
      const hrid = rows.length ? rows[0].rid : null;
      const body = rows.slice(1).map(r => ({ rid: r.rid, data: r.data, cells: decodeRow(r.data) }));
      await this.tx(async tx => {
        await this.upsertRows(tx.query, sheet, hdr, body);
        await tx.query('UPDATE sheet_meta SET rel=true, header=$2, header_rid=$3 WHERE sheet=$1', [sheet, encodeRow(hdr), hrid]);
        await tx.query('DELETE FROM sheet_rows WHERE sheet=$1', [sheet]);
      });
      console.log('[database] moved "' + sheet + '" (' + body.length + ' rows) into its own table');
    }
  }

  async load() {
    const out = { sheets: {}, props: {}, blobs: {} };
    const relRows = [];
    for (const m of (await this.query('SELECT sheet, text_cols, next_rid, header, header_rid, rel FROM sheet_meta')).rows) {
      const d = newSheetData(); d.textCols = JSON.parse(m.text_cols); d.nextRid = Number(m.next_rid); out.sheets[m.sheet] = d;
      if (m.rel) {
        if (m.header) { d.rows.push(decodeRow(m.header)); d.rids.push(Number(m.header_rid)); }
        relRows.push(m.sheet);
      }
    }
    // rows are read in pages so a very large database never needs one giant result
    for (const sheet of relRows) {
      const d = out.sheets[sheet], table = q_(SC.snake(sheet)); let last = 0;
      for (;;) {
        const r = (await this.query('SELECT rid, _raw FROM ' + table + ' WHERE rid > $1 ORDER BY rid LIMIT 20000', [last])).rows;
        if (!r.length) break;
        for (const x of r) { d.rows.push(decodeRow(x._raw)); d.rids.push(Number(x.rid)); }
        last = d.rids[d.rids.length - 1];
        if (last >= d.nextRid) d.nextRid = last + 1;
      }
    }
    let lastSheet = '', lastRid = 0;
    for (;;) {
      const r = (await this.query('SELECT sheet, rid, data FROM sheet_rows WHERE (sheet, rid) > ($1, $2) ORDER BY sheet, rid LIMIT 20000', [lastSheet, lastRid])).rows;
      if (!r.length) break;
      for (const x of r) {
        const d = out.sheets[x.sheet] || (out.sheets[x.sheet] = newSheetData());
        d.rows.push(decodeRow(x.data)); d.rids.push(Number(x.rid));
        if (Number(x.rid) >= d.nextRid) d.nextRid = Number(x.rid) + 1;
      }
      lastSheet = r[r.length - 1].sheet; lastRid = Number(r[r.length - 1].rid);
    }
    for (const p of (await this.query('SELECT k, v FROM props')).rows) out.props[p.k] = p.v;
    for (const b of (await this.query('SELECT id, name, mime, folder, b64 FROM blobs')).rows) out.blobs[b.id] = { name: b.name, mime: b.mime, folder: b.folder, b64: b.b64 };
    return out;
  }

  async save(ch) {
    try { await this.saveInner(ch); } catch (e) { this.tables = {}; throw e; }
  }
  async saveInner(ch) {
    await this.tx(async tx => {
      const generic = [], rel = {};
      for (const r of ch.rows) {
        if (this.isRel(r.sheet)) { if (!r.isHeader) (rel[r.sheet] || (rel[r.sheet] = [])).push(r); }
        else generic.push(r);
      }
      for (const sheet of Object.keys(rel)) await this.upsertRows(tx.query, sheet, ch.headers[sheet], rel[sheet]);
      for (let i = 0; i < generic.length; i += 300) {
        const part = generic.slice(i, i + 300), params = [];
        const vals = part.map((r, j) => { params.push(r.sheet, r.rid, r.data); return '($' + (j * 3 + 1) + ',$' + (j * 3 + 2) + ',$' + (j * 3 + 3) + ')'; });
        await tx.query('INSERT INTO sheet_rows (sheet, rid, data) VALUES ' + vals.join(',') + ' ON CONFLICT (sheet, rid) DO UPDATE SET data = EXCLUDED.data', params);
      }
      const gdel = [], rdel = {};
      for (const r of ch.deletes) { if (this.isRel(r.sheet)) (rdel[r.sheet] || (rdel[r.sheet] = [])).push(r.rid); else gdel.push(r); }
      for (const sheet of Object.keys(rdel)) {
        const t = this.tables[sheet] || await this.ensureTable(tx.query, sheet, ch.headers[sheet] || this.schema.sheets[sheet]);
        for (let i = 0; i < rdel[sheet].length; i += 5000) await tx.query('DELETE FROM ' + q_(t.table) + ' WHERE rid = ANY($1::bigint[])', [rdel[sheet].slice(i, i + 5000)]);
      }
      for (let i = 0; i < gdel.length; i += 300) {
        const part = gdel.slice(i, i + 300), params = [];
        const conds = part.map((r, j) => { params.push(r.sheet, r.rid); return '(sheet=$' + (j * 2 + 1) + ' AND rid=$' + (j * 2 + 2) + ')'; });
        await tx.query('DELETE FROM sheet_rows WHERE ' + conds.join(' OR '), params);
      }
      for (const m of ch.meta) {
        const isRel = this.isRel(m.sheet);
        if (isRel && ch.headers[m.sheet]) await this.ensureTable(tx.query, m.sheet, ch.headers[m.sheet]);
        await tx.query('INSERT INTO sheet_meta (sheet, text_cols, next_rid, header, header_rid, rel) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (sheet) DO UPDATE SET text_cols=EXCLUDED.text_cols, next_rid=EXCLUDED.next_rid, header=EXCLUDED.header, header_rid=EXCLUDED.header_rid, rel=EXCLUDED.rel',
          [m.sheet, m.textCols, m.nextRid, isRel ? m.header : null, isRel ? m.headerRid : null, isRel]);
      }
      for (const p of ch.props) {
        if (p.v === null) await tx.query('DELETE FROM props WHERE k=$1', [p.k]);
        else await tx.query('INSERT INTO props (k, v) VALUES ($1,$2) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v', [p.k, p.v]);
      }
      for (const b of ch.blobs) {
        await tx.query('INSERT INTO blobs (id, name, mime, folder, b64) VALUES ($1,$2,$3,$4,$5) ON CONFLICT (id) DO UPDATE SET name=EXCLUDED.name, mime=EXCLUDED.mime, folder=EXCLUDED.folder, b64=EXCLUDED.b64', [b.id, b.name, b.mime, b.folder, b.b64]);
      }
    });
  }
  async close() { try { if (this.pool) await this.pool.end(); else if (this.db) await this.db.close(); } catch (e) {} }
}

class FileAdapter {
  constructor() { this.kind = 'JSON file (testing only)'; }
  async init() {}
  async load() {
    const out = { sheets: {}, props: {}, blobs: {} };
    if (!fs.existsSync(DB_FILE)) return out;
    const j = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    for (const n of Object.keys(j.sheets || {})) {
      const d = newSheetData(); d.textCols = j.sheets[n].textCols || []; d.nextRid = j.sheets[n].nextRid || 1;
      d.rows = j.sheets[n].rows.map(decodeRow); d.rids = j.sheets[n].rids; out.sheets[n] = d;
    }
    out.props = j.props || {}; out.blobs = j.blobs || {};
    return out;
  }
  async save() {
    const j = { sheets: {}, props: state.props, blobs: state.blobs };
    for (const n of Object.keys(state.sheets)) {
      const d = state.sheets[n];
      j.sheets[n] = { textCols: d.textCols, nextRid: d.nextRid, rids: d.rids, rows: d.rows.map(r => encodeRow(r)) };
    }
    const tmp = DB_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(j)); fs.renameSync(tmp, DB_FILE);
  }
  async close() {}
}

let adapter = null;
const VIRTUAL = new Set(Object.keys(require('./schema').VIEWS));   // sheets that are database views (nothing stored)
async function initStore(schema) {
  if (!schema) schema = { sheets: require('./load-gas').loadGas().schema };
  const url = process.env.DATABASE_URL;
  if (process.env.STORAGE === 'file') adapter = new FileAdapter();
  else {
    try { adapter = new SqlAdapter(url, schema); await adapter.init(); }
    catch (e) {
      if (url) throw new Error('Could not connect to the database (DATABASE_URL): ' + e.message);
      console.error('[store] Built-in PostgreSQL could not start (' + e.message + ') - using the JSON file instead.');
      adapter = new FileAdapter(); await adapter.init();
    }
  }
  const loaded = await adapter.load();
  state.sheets = loaded.sheets; state.props = loaded.props; state.blobs = loaded.blobs;
  return adapter.kind;
}

/* Saves every queued change. Called after each request, before the user gets the answer. */
let committing = Promise.resolve();
function commit() {
  committing = committing.then(async () => {
    if (!isDirty()) return;
    const ch = { rows: [], deletes: [], meta: [], props: [], blobs: [], headers: {} };
    const snap = { rows: new Map(dirty.rows), deletes: new Map(dirty.deletes), meta: new Set(dirty.meta), props: new Set(dirty.props), blobs: new Set(dirty.blobs) };
    const touched = new Set();
    for (const [sheet, rid] of snap.rows.values()) {
      const d = state.sheets[sheet]; if (!d || VIRTUAL.has(sheet)) continue;
      const i = bsearch(d.rids, rid);
      if (i >= 0) { ch.rows.push({ sheet, rid, data: encodeRow(d.rows[i]), cells: d.rows[i], isHeader: i === 0 }); touched.add(sheet); if (i === 0) snap.meta.add(sheet); }
    }
    for (const [sheet, rid] of snap.deletes.values()) { if (VIRTUAL.has(sheet)) continue; ch.deletes.push({ sheet, rid }); touched.add(sheet); }
    for (const sheet of snap.meta) {
      const d = state.sheets[sheet]; if (!d || VIRTUAL.has(sheet)) continue;
      ch.meta.push({ sheet, textCols: JSON.stringify(d.textCols), nextRid: d.nextRid, header: d.rows.length ? encodeRow(d.rows[0]) : null, headerRid: d.rows.length ? d.rids[0] : null });
      touched.add(sheet);
    }
    for (const sheet of touched) { const d = state.sheets[sheet]; if (d && d.rows.length) ch.headers[sheet] = d.rows[0]; }
    for (const k of snap.props) ch.props.push({ k, v: Object.prototype.hasOwnProperty.call(state.props, k) ? state.props[k] : null });
    for (const id of snap.blobs) { const b = state.blobs[id]; if (b) ch.blobs.push({ id, name: b.name, mime: b.mime, folder: b.folder, b64: b.b64 }); }
    dirty.rows.clear(); dirty.deletes.clear(); dirty.meta.clear(); dirty.props.clear(); dirty.blobs.clear();
    try { await adapter.save(ch); }
    catch (err) {
      // keep everything queued so the next save retries it
      snap.rows.forEach((v, k) => dirty.rows.set(k, v)); snap.deletes.forEach((v, k) => dirty.deletes.set(k, v));
      snap.meta.forEach(v => dirty.meta.add(v)); snap.props.forEach(v => dirty.props.add(v)); snap.blobs.forEach(v => dirty.blobs.add(v));
      throw new Error('DATABASE_SAVE_FAILED: ' + err.message);
    }
  });
  const p = committing;
  committing = committing.catch(() => {});
  return p;
}
function bsearch(arr, x) {
  let lo = 0, hi = arr.length - 1;
  while (lo <= hi) { const mid = (lo + hi) >> 1; if (arr[mid] === x) return mid; if (arr[mid] < x) lo = mid + 1; else hi = mid - 1; }
  return -1;
}
async function closeStore() { try { await commit(); } catch (e) {} if (adapter) await adapter.close(); }
function storageKind() { return adapter ? adapter.kind : 'not started'; }

module.exports = { state, DATA_DIR, DB_FILE, newSheetData, markRow, markDelete, markMeta, markProp, markBlob, initStore, commit, closeStore, storageKind, adapter: () => adapter, encodeRow, decodeRow };
