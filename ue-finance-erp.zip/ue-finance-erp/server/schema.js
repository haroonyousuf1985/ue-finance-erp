/* ============================================================
   schema.js - turns the sheet layout (SCHEMA in Code.gs) into real
   database tables: one table per sheet, one typed column per header.

   * Table / column names are written in snake_case (EntryID -> entry_id).
   * Types are chosen from the column name: money/rates -> numeric,
     dates -> timestamptz, yes/no flags -> boolean, everything else -> text.
   * A value that does not fit its column type is left empty in the typed
     column (it is still kept exactly in the hidden "_raw" column, which is
     what the application itself reads, so nothing is ever lost or altered).
   ============================================================ */

function snake(s) {
  return String(s).replace(/([a-z0-9])([A-Z])/g, '$1_$2').replace(/([A-Z]+)([A-Z][a-z])/g, '$1_$2')
    .replace(/[^A-Za-z0-9_]+/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '').toLowerCase();
}

const BOOL_EXACT = new Set(['Active', 'Excluded', 'OnHold', 'AffidavitLowIncome', 'PendingOfficeConfirmation', 'Section149PaidCreditRecorded']);
const NUM_EXACT = new Set(['Amount', 'NetAmount', 'IncomeBeforeThisBill', 'IncomeAfterThisBill', 'BudgetAllocatedAtEntry', 'BudgetExpensesBeforeThisBill',
  'BudgetAfterThisBill', 'Section149CreditApplied', 'RecoveryDeducted', 'SourceNetPaid', 'Threshold', 'FileSize', 'LineNo', 'SplitFromLineNo',
  'VisitingCrHrs', 'VisitingRate', 'VisitingLectures']);

function typeOf(h) {
  if (BOOL_EXACT.has(h) || /Applied$/.test(h) && h !== 'Section149CreditApplied' || /^Manual.*Override$/.test(h)) return 'boolean';
  if (NUM_EXACT.has(h) || /(Amount|Rate|Total|Count)$/.test(h) || /^(AmountPaidTwice|AllocatedAmount)$/.test(h)) return 'numeric';
  if (/Date$|^Date|Timestamp$|^LastUpdated$/.test(h) && !/Basis|Mode/.test(h)) return 'timestamptz';
  return 'text';
}

/* columns of a table for the given header row */
function columnsFor(headers) {
  const used = new Set(['rid', '_raw']), cols = [];
  headers.forEach((h, i) => {
    if (h === '' || h == null) return;
    let n = snake(h) || 'col', k = n, c = 2;
    while (used.has(k)) k = n + '_' + (c++);
    used.add(k);
    cols.push({ i, header: String(h), name: k, type: typeOf(String(h)) });
  });
  return cols;
}

const clean = s => s.indexOf('\u0000') >= 0 ? s.replace(/\u0000/g, '') : s;
function convert(v, type) {
  if (v === undefined || v === null || v === '') return null;
  switch (type) {
    case 'numeric': return (typeof v === 'number' && isFinite(v)) ? v : null;
    case 'boolean': return typeof v === 'boolean' ? v : null;
    case 'timestamptz': return (v instanceof Date && !isNaN(v)) ? v.toISOString() : null;
    default:
      if (v instanceof Date) return isNaN(v) ? null : v.toISOString();
      return clean(typeof v === 'string' ? v : String(v));
  }
}

/* sheets that are only copies of the Entries sheet become database VIEWS (no duplicate data is stored) */
const VIEWS = {
  VendorEntries: { of: 'Entries', where: "payee_type = 'Vendor'" },
  StudentEntries: { of: 'Entries', where: "payee_type = 'Student'" },
  EmployeeEntries: { of: 'Entries', where: "payee_type NOT IN ('Vendor','Student')" }
};

const INDEXED = new Set(['entry_id', 'parent_entry_id', 'diary_id', 'batch_id', 'status', 'fy', 'cnic_ntn', 'username', 'recovery_id',
  'source_entry_id', 'key', 'payee_type', 'campus_id', 'head_id', 'employee_id', 'student_id']);

module.exports = { snake, typeOf, columnsFor, convert, VIEWS, INDEXED };
