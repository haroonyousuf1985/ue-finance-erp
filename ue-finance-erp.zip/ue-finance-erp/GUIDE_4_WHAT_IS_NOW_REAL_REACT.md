# Step 3 - real React screens (what changed, what is next)

**Nothing for you to do** - run `npm install` and `npm start` as before. Log in with your usual username and password.

## Now written as real React pages
* Login, the top bar (theme, password, logout) and the tab bar with the number badges
* **2. Processing**, **3. Passing**, **4. Payment/IBFT** (with the IBFT report, CSV download and Past Batches)
* **5. Confirmation** (mark failed / confirm all remaining)
* **6. Reconciliation** (needs-correction bills, older failed lines, FBR tax adjustments, edit and resubmit)
* **0. Diary** - Log a New Bill/Letter, Pending Diary Items (with column picker), Returned / On Hold, Sent to Other Offices, My Diary Position, My Diary Queue, and every pop-up (Re-assign & Resume, Reassign, Return, Process Letter, Diary Trail with file view/download). "Enter This Bill" opens New Entry pre-filled from the Diary item.
* **1. New Entry** - single bills for all four payee types (Vendor, UE Employee, Non-UE Employee, Student), multiple budget heads, live tax preview, Section 149 income card, Release of Security, Admin bypass, bulk CSV upload (Vendor / Student / Employee) with Diary numbers, the "Bill Saved - Please Confirm" window, and Edit mode.
* **All twelve Reports** - including the last five: **Sanction Proforma** (pick bills, letter preview, Word download, Print / Save as PDF), **AI Report** (Gemini key + questions, tables downloadable as CSV), **Tax Deduction Statement**, **Diary Report** (with chart) and **Tax Calculation Details** (with column picker).
* **Admin > Bill Management & Section 149 Tools** - Manage Entries, Cancelled-Bill Income Threshold Repair, Already-Paid Over/Under-Deductions, Tax Deduction Statement, Outstanding Credit Balances, Manual Income Inclusion Override, and Redirect a Paid Bill (with Preview and confirmation windows).
* **Admin > Bill Management: Manage Entries** (Edit / Delete / Cancel). Edit opens the bill in New Entry.
* The **Bill Audit View** window that opens when you click any Bill ID
* The change-password window (also shown after a first login with the default password)

Small improvements you will notice: a "select all" tick box in the table heading, and a live count of selected bills.

## Still the original screens
None. Every screen is now a real React page. (The old original screens are still kept inside the project, unused, in the folder `legacy-src`, as a reference. They can be deleted later.)

## Two small differences
* "Download PDF" buttons in the converted screens are now **Print / Save as PDF** - in the print window choose "Save as PDF" (CSV downloads work as before).
* The pipeline pages no longer need the internet-hosted PDF library.

## Checked automatically
A real browser test logged in, took three bills through Processing, Passing, Payment (IBFT batch), failed one in Confirmation,
fixed and resubmitted it in Reconciliation, opened the Bill Audit View, switched theme, opened the four original screens and logged out - all passed.


## Small differences in New Entry
* After a bill is saved the form clears the deductions too (the original kept them ticked), so one bill's security or penalty can never carry onto the next.
* Editing a Received bill no longer asks for a Diary number again - the bill already has it.
* The New Entry form keeps what you typed when you switch to another tab and come back.
