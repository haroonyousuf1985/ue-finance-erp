import React, { useState } from 'react';
import { gs } from '../api.js';
import { useToast, Modal } from '../ui.jsx';

export default function PasswordModal({ user, onClose, forced }) {
  const { run } = useToast();
  const [o, setO] = useState('');
  const [n, setN] = useState('');
  async function save() {
    const res = await run(() => gs('changePassword', user.username, o, n), 'Updating password...', 'Password updated.');
    if (res && res.success) onClose();
  }
  return (
    <Modal maxWidth={340} z={100} onClose={forced ? undefined : onClose}>
      <h3>Change Password</h3>
      {forced && <p style={{ fontSize: 13, color: 'var(--amber)' }}>You are still using the default password (admin123). Please change it now.</p>}
      <div className="field"><label>Old Password</label><input type="password" value={o} onChange={e => setO(e.target.value)} /></div>
      <div className="field"><label>New Password</label><input type="password" value={n} onChange={e => setN(e.target.value)} /></div>
      <button className="primary" onClick={save}>Update</button>{' '}
      <button className="secondary" onClick={onClose}>{forced ? 'Later' : 'Cancel'}</button>
    </Modal>
  );
}
