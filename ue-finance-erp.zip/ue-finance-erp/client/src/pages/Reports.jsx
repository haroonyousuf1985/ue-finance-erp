import React, { useEffect, useState } from 'react';
import { gs } from '../api.js';
import { Yearly, Consumption, BillStatus } from './reports/Reports1to3.jsx';
import { ControlRegister, GeneralLedger, IbftPayment, ConfirmedPayments } from './reports/Reports4to7.jsx';
import { SanctionProforma, AiReport, TaxDeductionStatement, DiaryReport, TaxCalcDetails } from './reports/ReportsRest.jsx';

/* The Reports tab. All twelve reports are real React pages. */
const SUBS = [
  ['rep1', 'Yearly Budget Matrix'], ['rep2', 'Budget Consumption'], ['rep3', 'Bill Status'], ['rep4', 'Budget Control Register'],
  ['rep5', 'General Ledger'], ['rep6', 'IBFT Payment'], ['rep7', 'Sanction Proforma'], ['rep8', 'AI Report'],
  ['rep9', 'Tax Deduction Statement'], ['rep10', 'Diary Report'], ['rep11', 'Confirmed Payments'], ['rep12', 'Tax Calculation Details']
];

export default function Reports({ user, onOpenBill, onOpenDiaryTrail }) {
  const clerk = user.role === 'DiaryClerk';           // the Diary Clerk only sees the Diary Report
  const subs = clerk ? SUBS.filter(s => s[0] === 'rep10') : SUBS;
  const [sub, setSub] = useState(subs[0][0]);
  const [campuses, setCampuses] = useState([]);
  const [heads, setHeads] = useState([]);
  useEffect(() => {
    if (clerk) return;
    gs('getCampuses').then(setCampuses).catch(() => {});
    gs('getBudgetHeads').then(setHeads).catch(() => {});
  }, [clerk]);

  const common = { campuses, heads, onOpenBill };
  let body;
  switch (sub) {
    case 'rep1': body = <Yearly {...common} />; break;
    case 'rep2': body = <Consumption {...common} />; break;
    case 'rep3': body = <BillStatus {...common} />; break;
    case 'rep4': body = <ControlRegister {...common} />; break;
    case 'rep5': body = <GeneralLedger {...common} />; break;
    case 'rep6': body = <IbftPayment />; break;
    case 'rep11': body = <ConfirmedPayments {...common} />; break;
    case 'rep7': body = <SanctionProforma campuses={campuses} />; break;
    case 'rep8': body = <AiReport user={user} />; break;
    case 'rep9': body = <TaxDeductionStatement user={user} onOpenBill={onOpenBill} />; break;
    case 'rep10': body = <DiaryReport user={user} onOpenDiaryTrail={onOpenDiaryTrail} />; break;
    case 'rep12': body = <TaxCalcDetails user={user} onOpenBill={onOpenBill} />; break;
    default: body = null;
  }
  return (
    <div className="tabpanel active">
      <nav className="subtabs no-print">
        {subs.map(([id, label]) => <button key={id} className={'sub-btn' + (id === sub ? ' active' : '')} onClick={() => setSub(id)}>{label}</button>)}
      </nav>
      {body}
    </div>
  );
}
