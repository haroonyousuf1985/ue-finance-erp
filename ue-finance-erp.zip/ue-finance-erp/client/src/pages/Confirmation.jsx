import React, { useMemo, useState } from 'react';
import { gs } from '../api.js';
import { fmtDate, num, netOf, fyOptions } from '../util.js';
import { useToast, EmptyRow, FYSelect, BillLink } from '../ui.jsx';

/* Stage 5: did the money really move? Tick the few that bounced -> Failed; confirm the rest in one go.
   An ID is either a plain Bill ID or a bulk beneficiary line such as E123-4. */
const isBulkLine = id => /-\d+$/.test(String(id));

export default function Confirmation({ user, onOpenBill, onChanged }) {
  const { toast, run } = useToast();
  const [fy, setFy] = useState('');
  const [all, setAll] = useState(null);
  const [loading, setLoading] = useState(false);
  const [sel, setSel] = useState(() => new Set());
  const [f, setF] = useState({ bill: '', batch: '', ben: '' });

  async function load() {
    setLoading(true);
    const list = await gs('getPaymentsNeedingConfirmation', fy).catch(e => { toast(e.message, 'error'); return []; });
    setAll(list || []); setSel(new Set()); setF({ bill: '', batch: '', ben: '' }); setLoading(false);
    onChanged && onChanged();
  }
  const shown = useMemo(() => {
    const has = (v, q) => !q.trim() || String(v || '').toLowerCase().includes(q.trim().toLowerCase());
    return (all || []).filter(e => has(e.EntryID, f.bill) && has(e.BatchID, f.batch) && has(e.VendorName, f.ben));
  }, [all, f]);
  const toggle = (id, on) => setSel(s => { const n = new Set(s); on ? n.add(id) : n.delete(id); return n; });

  async function markFailed() {
    if (!sel.size) { toast('Tick at least one item first.', 'error'); return; }
    const reason = window.prompt('Reason for the ' + sel.size + ' selected item(s) failing (e.g. wrong IBAN, closed account, title mismatch).\n\nA failed bulk beneficiary is separated into its own new bill (E...-A) and moved to Reconciliation; the rest of the bulk bill is not affected.');
    if (reason === null) return;
    if (!reason.trim()) { toast('A reason is required.', 'error'); return; }
    const ids = Array.from(sel), singles = ids.filter(i => !isBulkLine(i)), lines = ids.filter(isBulkLine);
    const res = await run(async () => {
      let count = 0, created = [], messages = [];
      if (singles.length) { const r = await gs('markPaymentsFailed', singles, reason.trim(), user.username); if (r.success) count += r.count; else messages.push(r.message); }
      if (lines.length) { const r = await gs('markBulkLinesFailed', lines, reason.trim(), user.username); if (r.success) { count += r.count; created = created.concat(r.created || []); } if (r.message) messages.push(r.message); }
      if (!count) return { success: false, message: messages.join(' | ') || 'Nothing was marked failed.' };
      return { success: true, count, created, messages };
    }, 'Marking as failed...');
    if (res && res.success) {
      toast(res.count + ' item(s) marked Failed - moved to Reconciliation.' + (res.created.length ? ' New Bill ID(s): ' + res.created.map(c => c.newEntryId).join(', ') + '.' : ''), 'success');
      if (res.messages.length) toast(res.messages.join(' | '), 'error');
      load();
    }
  }
  async function confirmRemaining() {
    if (!shown.length) { toast('Nothing currently shown to confirm.', 'error'); return; }
    if (!window.confirm('Confirm payment for all ' + shown.length + ' item(s) currently shown? Anything you meant to mark Failed should be ticked and handled first.')) return;
    const ids = shown.map(e => e.EntryID), singles = ids.filter(i => !isBulkLine(i)), lines = ids.filter(isBulkLine);
    const res = await run(async () => {
      let count = 0;
      if (singles.length) { const r = await gs('confirmPayments', singles, user.username); if (r.success) count += r.count; }
      if (lines.length) { const r = await gs('confirmBulkLines', lines, user.username); if (r.success) count += r.count; }
      return { success: true, count };
    }, 'Confirming...');
    if (res && res.success) { toast(res.count + ' item(s) confirmed.', 'success'); load(); }
  }

  return (
    <div className="tabpanel active">
      <div className="card no-print">
        <h3>Confirmation <span className="pill Paid">from Payment/IBFT</span></h3>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>
          Generating the IBFT batch only means the file was sent to the bank - it does not mean the money moved. Load the list, tick the few that actually bounced and mark them Failed, then confirm everything else in one go. A bounced bulk beneficiary is separated into its own new bill (e.g. E123-A) and moves to Reconciliation; the rest of the bulk bill is not affected.
        </p>
        <div className="row">
          <div className="field" style={{ maxWidth: 220 }}><label>Financial Year</label><FYSelect value={fy} onChange={setFy} options={fyOptions()} /></div>
          <div className="field" style={{ alignSelf: 'flex-end' }}><button className="primary" disabled={loading} onClick={load}>Load</button></div>
        </div>
        {all && all.length > 0 && (
          <>
            <div className="row">
              <div className="field"><label>Bill ID contains</label><input type="text" value={f.bill} onChange={e => setF({ ...f, bill: e.target.value })} /></div>
              <div className="field"><label>Batch contains</label><input type="text" value={f.batch} onChange={e => setF({ ...f, batch: e.target.value })} /></div>
              <div className="field"><label>Beneficiary Name contains</label><input type="text" value={f.ben} onChange={e => setF({ ...f, ben: e.target.value })} /></div>
            </div>
            <div className="row" style={{ alignItems: 'center' }}>
              <button className="secondary" style={{ color: 'var(--danger)' }} onClick={markFailed}>Mark Selected as Failed</button>
              <button className="primary" onClick={confirmRemaining}>Confirm All Remaining</button>
              <span style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>{shown.length} item(s) shown, {sel.size} selected.</span>
            </div>
          </>
        )}
        <div className="table-wrap" style={{ marginTop: 10 }}>
          <table>
            <thead><tr><th></th><th>Bill / Line ID</th><th>IBFT Submitted</th><th>Batch</th><th>Beneficiary</th><th>FBR Section</th><th>IBAN</th><th className="num">Net Amount</th></tr></thead>
            <tbody>
              {all === null && <EmptyRow cols={8} text={loading ? 'Loading...' : 'Set the Financial Year above and click Load.'} />}
              {all !== null && shown.length === 0 && <EmptyRow cols={8} />}
              {shown.map(e => (
                <tr key={e.EntryID}>
                  <td><input type="checkbox" checked={sel.has(e.EntryID)} onChange={ev => toggle(e.EntryID, ev.target.checked)} /></td>
                  <td><BillLink id={e.EntryID} onOpen={onOpenBill} /></td><td>{fmtDate(e.PaidDate)}</td><td>{e.BatchID}</td><td>{e.VendorName}</td>
                  <td>{e.IncomeTaxSection || '-'}</td><td>{e.IBAN}</td><td className="num">{num(netOf(e))}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
