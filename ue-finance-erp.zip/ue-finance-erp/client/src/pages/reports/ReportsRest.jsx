import React, { useEffect, useRef, useState } from 'react';
import { gs } from '../../api.js';
import { DEFAULT_FY, todayISO, fyOptions, fmtDate, num, exportCSV, tableToCSV, payeeTypeLabel } from '../../util.js';
import { useToast, EmptyRow, BillLink } from '../../ui.jsx';
import { ExportButtons, Caption, Status, Filter, useTableRef } from './common.jsx';

/* The five reports that used to run as the original screens:
   Sanction Proforma, AI Report, Tax Deduction Statement, Diary Report and Tax Calculation Details. */
const FYS = fyOptions();
const note = { fontSize: 12.5, color: 'var(--text-muted)' };

/* ================= Sanction Proforma ================= */
const SANCTION_COLUMNS = [
  ['billId', 'Bill ID', true], ['date', 'Date', true], ['campus', 'Campus', true], ['head', 'Budget Head', false], ['vendor', 'Payee', true],
  ['billNo', 'Bill No.', false], ['description', 'Description', true], ['nature', 'Nature', false], ['gross', 'Gross Amount', true],
  ['incomeTax', 'Income Tax', false], ['salesTax', 'Sales Tax', false], ['pst', 'Punjab Sales Tax', false], ['security', 'Security', false],
  ['penalty', 'Penalty', false], ['other', 'Other Deduction', false], ['net', 'Net Amount', true], ['status', 'Status', false]
];
const NUMERIC_KEYS = ['gross', 'incomeTax', 'salesTax', 'pst', 'security', 'penalty', 'other', 'net'];
const isSplitId = id => /^E\d+-[A-Z]+$/.test(String(id || '').trim());
const parentOf = id => { id = String(id || ''); return isSplitId(id) ? id : (id.includes('-') ? id.split('-')[0] : id); };
const cellValue = (r, key) => NUMERIC_KEYS.includes(key) ? num(r[key]) : key === 'date' ? fmtDate(r.date) : key === 'head' ? (r.headCode || '') + ' ' + (r.headName || '') : (r[key] ?? '');

function groupRows(rows) {
  const groups = [];
  let cur = null;
  rows.forEach(r => {
    const p = parentOf(r.billId);
    if (!cur || cur.parentId !== p) { cur = { parentId: p, rows: [] }; groups.push(cur); }
    cur.rows.push(r);
  });
  return groups;
}

export function SanctionProforma({ campuses }) {
  const { toast, run } = useToast();
  const [f, setF] = useState({ fy: DEFAULT_FY, status: '', campus: '', billId: '', vendor: '', description: '' });
  const [list, setList] = useState(null);
  const [selected, setSelected] = useState(() => new Set());
  const [sanctionNo, setSanctionNo] = useState('');
  const [dated, setDated] = useState(todayISO());
  const [cols, setCols] = useState(() => SANCTION_COLUMNS.filter(c => c[2]).map(c => c[0]));
  const [data, setData] = useState(null);
  const [shownCols, setShownCols] = useState([]);
  const docRef = useRef(null);
  const up = k => e => setF({ ...f, [k]: e.target.value });

  async function load() {
    const res = await run(() => gs('getEntriesForSanctionPicker', { fy: f.fy, status: f.status, campusIds: f.campus ? [f.campus] : [], billId: f.billId, vendor: f.vendor, description: f.description }), 'Loading bills...');
    setList(Array.isArray(res) ? res : []);
  }
  async function generate() {
    const ids = Array.from(selected);
    if (!ids.length) { toast('Select at least one bill first.', 'error'); return; }
    const res = await run(() => gs('getSanctionProformaData', ids), 'Building sanction proforma...', 'Sanction proforma generated.');
    if (!res || res.error || res.success === false) return;
    setShownCols(SANCTION_COLUMNS.filter(c => cols.includes(c[0])));
    setData(res);
    setTimeout(() => { const el = document.getElementById('sp_previewCard'); if (el) el.scrollIntoView({ behavior: 'smooth' }); }, 50);
  }
  function downloadDoc() {
    if (!docRef.current) { toast('Generate the proforma first.', 'error'); return; }
    const html = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset="utf-8"><title>Sanction Proforma</title><style>body{font-family:'Times New Roman',serif;} table{border-collapse:collapse;width:100%;} th,td{border:1px solid #000;padding:5px 7px;} th{background:#EFEFEF;}</style></head><body>${docRef.current.innerHTML}</body></html>`;
    const url = URL.createObjectURL(new Blob(['﻿', html], { type: 'application/msword' }));
    const a = document.createElement('a'); a.href = url; a.download = 'Sanction_Proforma_' + (sanctionNo || 'draft').replace(/[^\w-]/g, '_') + '.doc';
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  }
  const toggleBill = (id, on) => setSelected(s => { const n = new Set(s); on ? n.add(id) : n.delete(id); return n; });
  const align = key => NUMERIC_KEYS.includes(key) ? { textAlign: 'right' } : undefined;
  const blank = '________________';

  return (
    <>
      <div className="card no-print">
        <h3>Step 1 - Find &amp; Select Bills</h3>
        <p style={note}>A bulk bill is selected here as a single bill - it will automatically expand into its individual beneficiaries in the letter's table. A beneficiary that was separated into its own bill (e.g. E123-A) must be selected separately.</p>
        <div className="row">
          <Filter label="Financial Year" max={200}><select id="sp_fy" value={f.fy} onChange={up('fy')}><option value="">All Years</option>{FYS.map(y => <option key={y}>{y}</option>)}</select></Filter>
          <Filter label="Status"><select id="sp_status" value={f.status} onChange={up('status')}><option value="">All</option><option>Received</option><option>Processed</option><option>Passed</option><option>Paid</option></select></Filter>
          <Filter label="Campus"><select id="sp_campus" value={f.campus} onChange={up('campus')}><option value="">All Campuses</option>{campuses.map(c => <option key={c.CampusID} value={c.CampusID}>{c.CampusName}</option>)}</select></Filter>
          <Filter label="Bill ID contains"><input type="text" id="sp_billid" value={f.billId} onChange={up('billId')} /></Filter>
          <Filter label="Vendor/Payee contains"><input type="text" id="sp_vendor" value={f.vendor} onChange={up('vendor')} /></Filter>
          <Filter label="Description contains"><input type="text" id="sp_description" value={f.description} onChange={up('description')} /></Filter>
        </div>
        <button className="primary" id="btnSpLoad" onClick={load}>Load Bills</button>
        <span id="sp_selectedCount" style={{ ...note, marginLeft: 10 }}>{selected.size} bill(s) selected so far (selections are kept even if you change the filters and load again).</span>
        <div className="table-wrap" style={{ marginTop: 10, maxHeight: 320, overflowY: 'auto' }}>
          <table id="sanctionPickerTable">
            <thead><tr><th></th><th>Bill ID</th><th>Date</th><th>Campus</th><th>Head</th><th>Payee</th><th>Description</th><th>Nature</th><th className="num">Amount</th><th>Status</th></tr></thead>
            <tbody>{list === null ? <EmptyRow cols={10} text="Set filters above and click Load Bills." /> : list.length ? list.map(e => (
              <tr key={e.EntryID}>
                <td><input type="checkbox" className="spbill" checked={selected.has(e.EntryID)} onChange={ev => toggleBill(e.EntryID, ev.target.checked)} /></td>
                <td>{e.EntryID}{e.PayeeType === 'Bulk' && <span style={{ color: 'var(--amber)', fontSize: 11 }}> (bulk)</span>}</td>
                <td>{fmtDate(e.EntryDate)}</td><td>{e.CampusName}</td><td>{e.HeadCode || ''} {e.HeadName || ''}</td><td>{e.VendorName}</td><td>{e.BillDescription || ''}</td><td>{e.BillNature || ''}</td>
                <td className="num">{num(e.Amount)}</td><td><Status s={e.Status} /></td></tr>)) : <EmptyRow cols={10} />}</tbody>
          </table>
        </div>
      </div>

      <div className="card no-print">
        <h3>Step 2 - Letter Detail &amp; Table Columns</h3>
        <div className="row">
          <Filter label="Sanction No."><input type="text" id="sp_sanctionNo" placeholder="e.g. 123/UE/2026" value={sanctionNo} onChange={e => setSanctionNo(e.target.value)} /></Filter>
          <Filter label="Dated"><input type="date" id="sp_dated" value={dated} onChange={e => setDated(e.target.value)} /></Filter>
        </div>
        <label>Table Columns <label style={{ display: 'inline', fontWeight: 'normal' }}><input type="checkbox" style={{ width: 'auto' }} checked={cols.length === SANCTION_COLUMNS.length} onChange={e => setCols(e.target.checked ? SANCTION_COLUMNS.map(c => c[0]) : [])} /> Select All</label></label>
        <div className="checklist" id="sp_columns">{SANCTION_COLUMNS.map(([k, l]) => (
          <label key={k}><input type="checkbox" className="spcol" checked={cols.includes(k)} onChange={e => setCols(c => e.target.checked ? c.concat(k) : c.filter(x => x !== k))} /> {l}</label>))}</div>
        <button className="primary" id="btnSpGenerate" onClick={generate} style={{ marginTop: 12 }}>Generate Sanction Proforma</button>
      </div>

      {data && (
        <div className="card" id="sp_previewCard">
          <h3 className="no-print">Preview <button className="secondary" onClick={downloadDoc}>Download Word (.doc)</button> <button className="secondary" onClick={() => window.print()} title="In the print window choose 'Save as PDF' to keep a PDF copy">Print / Save as PDF</button></h3>
          <div id="sp_previewWrap">
            <div className="sanction-doc" id="sanctionDocContent" ref={docRef}>
              <h2 style={{ textAlign: 'center', textDecoration: 'underline', marginBottom: 4 }}>UNIVERSITY OF EDUCATION, LAHORE</h2>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 18 }}><div>SANCTION NO. {sanctionNo || blank}</div><div>Dated: {dated ? fmtDate(dated) : blank}</div></div>
              <p style={{ marginTop: 14 }}>Subject:&nbsp;&nbsp;<b><u>Sanction of the Expenditure</u></b></p>
              <p style={{ textAlign: 'justify' }}>
                In pursuance of Section 2.2.1 of the Delegation of Financial Powers Rules, 2003, as contained in the Chapter 2 of Financial Rules of the Calendar of the University of Education, Lahore, sanction is hereby accorded to the incurrence of expenditure of Rs. <b>{num(data.grossAmount)}</b>/- Rupees <b><u>{data.grossAmountWords}</u></b> in connection with <b>{data.billDescription}</b>. The expenditure so made shall be debited under head <b>{data.headText}</b> of University of Education, Lahore for the Financial Year {data.fy || DEFAULT_FY}.
              </p>
              <table style={{ marginTop: 14 }}>
                <thead><tr>{shownCols.map(([k, l]) => <th key={k} style={align(k)}>{l}</th>)}</tr></thead>
                <tbody>
                  {groupRows(data.rows).map((g, gi) => (
                    <React.Fragment key={gi}>
                      {g.rows.map((r, ri) => <tr key={ri}>{shownCols.map(([k]) => <td key={k} style={align(k)}>{cellValue(r, k)}</td>)}</tr>)}
                      {g.rows.length > 1 && <tr style={{ background: '#EFEFEF' }}>{shownCols.map(([k], i) => (
                        <td key={k} style={align(k)}>{i === 0 ? <b>Subtotal - Bill {g.parentId}</b> : k === 'gross' ? <b>{num(g.rows.reduce((s, r) => s + r.gross, 0))}</b> : k === 'net' ? <b>{num(g.rows.reduce((s, r) => s + r.net, 0))}</b> : ''}</td>))}</tr>}
                    </React.Fragment>))}
                  <tr>{shownCols.map(([k], i) => <td key={k} style={align(k)}>{i === 0 ? <b>Grand Total</b> : k === 'gross' ? <b>{num(data.grossAmount)}</b> : k === 'net' ? <b>{num(data.rows.reduce((s, r) => s + r.net, 0))}</b> : ''}</td>)}</tr>
                </tbody>
              </table>
              <div style={{ marginTop: 60, display: 'flex', justifyContent: 'space-between', textAlign: 'center' }}>
                {['Accounts Assistant', 'Assistant Director', 'Deputy Director', 'Treasurer'].map(t => <div key={t} style={{ minWidth: 140 }}>{blank}<br />{t}</div>)}
              </div>
              <div style={{ marginTop: 50, textAlign: 'right' }}>{blank}<br />Vice Chancellor</div>
            </div>
          </div>
        </div>)}
    </>
  );
}

/* ================= AI Report (Google Gemini) ================= */
function AiAnswer({ md }) {
  const lines = String(md || '').replace(/\r\n/g, '\n').split('\n');
  const out = [];
  let table = [], list = null, k = 0;
  const inline = s => {
    const parts = []; const re = /\*\*(.+?)\*\*|\*(.+?)\*|`(.+?)`/g; let last = 0, m;
    while ((m = re.exec(s))) {
      if (m.index > last) parts.push(s.slice(last, m.index));
      parts.push(m[1] ? <b key={parts.length}>{m[1]}</b> : m[2] ? <i key={parts.length}>{m[2]}</i> : <code key={parts.length}>{m[3]}</code>);
      last = m.index + m[0].length;
    }
    if (last < s.length) parts.push(s.slice(last));
    return parts;
  };
  const flushList = () => { if (list) { const T = list.type; out.push(<T key={k++} style={{ margin: '6px 0', paddingLeft: 22 }}>{list.items.map((x, i) => <li key={i}>{inline(x)}</li>)}</T>); list = null; } };
  const flushTable = () => {
    if (!table.length) return;
    const cells = l => l.trim().replace(/^\||\|$/g, '').split('|').map(c => c.trim());
    const [h, , ...body] = table; table = [];
    out.push(<AiTable key={k++} head={cells(h)} rows={body.map(cells)} />);
  };
  lines.forEach(line => {
    if (/^\s*\|.*\|\s*$/.test(line)) { flushList(); table.push(line); return; }
    flushTable();
    const hd = line.match(/^(#{1,4})\s+(.*)/);
    if (hd) { flushList(); const L = 'h' + Math.min(hd[1].length + 2, 6); out.push(React.createElement(L, { key: k++, style: { margin: '14px 0 6px' } }, inline(hd[2]))); return; }
    const bu = line.match(/^\s*[-*]\s+(.*)/), nu = line.match(/^\s*\d+\.\s+(.*)/);
    if (bu) { if (!list || list.type !== 'ul') { flushList(); list = { type: 'ul', items: [] }; } list.items.push(bu[1]); return; }
    if (nu) { if (!list || list.type !== 'ol') { flushList(); list = { type: 'ol', items: [] }; } list.items.push(nu[1]); return; }
    flushList();
    out.push(line.trim() === '' ? <div key={k++} style={{ height: 8 }} /> : <p key={k++} style={{ margin: '4px 0' }}>{inline(line)}</p>);
  });
  flushTable(); flushList();
  return <>{out}</>;
}
function AiTable({ head, rows }) {
  const ref = useTableRef();
  const { toast } = useToast();
  return (
    <>
      <div className="table-wrap" style={{ margin: '8px 0' }}>
        <table ref={ref}><thead><tr>{head.map((c, i) => <th key={i}>{c}</th>)}</tr></thead><tbody>{rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}>{c}</td>)}</tr>)}</tbody></table>
      </div>
      <button className="secondary no-print" style={{ margin: '-4px 0 10px' }} onClick={() => { if (!tableToCSV(ref.current, 'AI_Report_Table.csv')) toast('Nothing to export.', 'error'); }}>Download this table as CSV</button>
    </>
  );
}

export function AiReport({ user }) {
  const { toast, run } = useToast();
  const [status, setStatus] = useState(null);
  const [key, setKey] = useState('');
  const [model, setModel] = useState('');
  const [fy, setFy] = useState(DEFAULT_FY);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState(null);
  const [info, setInfo] = useState('');
  const loadStatus = () => gs('getGeminiKeyStatus').then(setStatus).catch(() => setStatus(null));
  useEffect(() => { loadStatus(); }, []);
  async function saveKey() {
    if (!key.trim()) { toast('Paste an API key first.', 'error'); return; }
    const res = await run(() => gs('saveGeminiApiKey', user.username, key.trim()), 'Saving key...', 'Gemini API key saved.');
    if (res && res.success) { setKey(''); if (model.trim()) await gs('saveGeminiModel', user.username, model.trim()); loadStatus(); }
  }
  async function clearKey() {
    if (!window.confirm('Remove the saved Gemini API key? AI Report will stop working until a new one is added.')) return;
    const res = await run(() => gs('clearGeminiApiKey', user.username), 'Clearing key...', 'Gemini API key removed.');
    if (res && res.success) loadStatus();
  }
  async function ask() {
    if (!question.trim()) { toast('Enter a question first.', 'error'); return; }
    setAnswer(null);
    const res = await run(() => gs('askAIReport', question.trim(), fy, user.username), 'Asking Gemini (this can take a few seconds)...');
    if (!res || !res.success) return;
    setInfo('Answered from ' + res.rowCount + ' row(s) of data' + (fy ? ' (' + fy + ')' : ' (all years)') + '.');
    setAnswer(res.answer);
  }
  return (
    <>
      <div className="card no-print" id="ai_keyCard">
        <h3>Gemini API Key</h3>
        <p style={note}>Your own Google Gemini API key, used only by this system to answer questions below - it's stored on the server (not in any sheet or shared with anyone else) and never sent back to your browser once saved. Get a key at <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener noreferrer">aistudio.google.com/apikey</a>.</p>
        <div id="ai_keyStatus" style={{ fontSize: 13, marginBottom: 10 }}>
          {status && status.hasKey ? <><span style={{ color: 'var(--accent)' }}>&#10003; A Gemini API key is set</span> (model: {status.model || 'gemini-2.0-flash'}). Questions below are ready to use.</>
            : <><span style={{ color: 'var(--amber)' }}>No API key set yet.</span> Paste one below and click Save before asking a question.</>}
        </div>
        <div className="row">
          <Filter label="Gemini API Key"><input type="password" id="ai_apiKey" autoComplete="off" placeholder={status && status.hasKey ? 'Already set - paste a new key here to replace it' : 'Paste your key here'} value={key} onChange={e => setKey(e.target.value)} /></Filter>
          <Filter label="Model (optional)" max={220}><input type="text" id="ai_model" placeholder="gemini-2.0-flash" value={model} onChange={e => setModel(e.target.value)} /></Filter>
          <div className="field" style={{ alignSelf: 'flex-end' }}><button className="primary" id="btnSaveGeminiKey" onClick={saveKey}>Save Key</button> <button className="secondary" onClick={clearKey}>Clear Key</button></div>
        </div>
      </div>
      <div className="card no-print">
        <h3>Ask a Question</h3>
        <p style={note}>Examples: "Compare electricity bill totals across all campuses this year." &middot; "What's the status of bill E1023?" &middot; "List every bill for vendor ABC Traders." &middot; "Total income tax deducted each month, by section." The AI only reports what's actually in the database below - no opinions, no suggestions, no outside knowledge. The answer always appears right here in the browser - if it includes a table, a "Download this table as CSV" button appears under it, but nothing ever downloads unless you click that button yourself.</p>
        <div className="row"><Filter label="Financial Year (recommended, keeps it fast)" max={220}><select id="ai_fy" value={fy} onChange={e => setFy(e.target.value)}><option value="">All Years</option>{FYS.map(y => <option key={y}>{y}</option>)}</select></Filter></div>
        <div className="field"><label>Your Question</label><textarea id="ai_question" rows={3} style={{ resize: 'vertical' }} value={question} onChange={e => setQuestion(e.target.value)} /></div>
        <button className="primary" id="btnAskAI" onClick={ask}>Ask</button>
        <span id="ai_rowInfo" style={{ fontSize: 12, color: 'var(--text-muted)', marginLeft: 10 }}>{info}</span>
      </div>
      {answer !== null && (
        <div className="card" id="ai_answerCard">
          <h3 className="no-print">Answer <button className="secondary" onClick={() => window.print()}>Print / Save as PDF</button></h3>
          <div id="ai_answerWrap" style={{ lineHeight: 1.7 }}><AiAnswer md={answer} /></div>
        </div>)}
    </>
  );
}

/* ================= Tax Deduction Statement (also used by Admin > Section 149 later) ================= */
const tdsSection = t => t.section === '149' ? '149 - Salary (Slab)' : t.section === '156' ? "156 - Honoraria to Statutory Body Meeting's Member" : '153(1)(b) - Services (Individual/AOP)';
const tdsSlabText = t => (!t.slabBreakdown || !t.slabBreakdown.length)
  ? (t.method === 'flat' ? 'Flat ' + ((t.flatRate || 0) * 100).toFixed(2) + '% of gross' : '-')
  : t.slabBreakdown.map(seg => seg.label + ' @ ' + (seg.rate * 100).toFixed(2) + '%: ' + num(seg.portionAmount) + ' -> ' + num(seg.taxOnPortion)).join('\n');
const TDS_CSV = [['billId', 'Bill ID'], ['date', 'Date'], ['nature', 'Nature of Bill'], ['section', 'FBR Section'], ['gross', 'Gross Amount'], ['incomeBefore', 'Income Before'], ['incomeAfter', 'Income After'],
  ['slabLabel', 'Slab'], ['slabRate', 'Rate'], ['portionAmount', 'Portion Amount'], ['taxOnPortion', 'Tax on Portion'], ['correctTax', 'Correct Total Tax (Bill)'], ['actualTax', 'Actually Withheld (Bill)'], ['creditApplied', 'Credit Applied (Bill)'], ['status', 'Status']];

export function TaxDeductionStatement({ user, onOpenBill }) {
  const { toast, run } = useToast();
  const [payeeType, setPayeeType] = useState('Employee');
  const [key, setKey] = useState('');
  const [fy, setFy] = useState(DEFAULT_FY);
  const [res, setRes] = useState(null);
  const [err, setErr] = useState('');
  async function generate() {
    if (!key.trim()) { toast('Enter the ' + (payeeType === 'Employee' ? 'Employee ID' : 'CNIC') + ' first.', 'error'); return; }
    const r = await run(() => gs('getSection149TaxDeductionStatement', key.trim(), payeeType, fy || DEFAULT_FY, user.username), 'Building statement...');
    if (!r || r.success === false) { setRes(null); setErr((r && r.message) || 'Could not build the statement.'); return; }
    setErr(''); setRes(r);
  }
  function csv() {
    const s = res.statement, rows = [];
    s.transactions.forEach(t => {
      const base = { billId: t.id, date: t.date ? fmtDate(t.date) : '', nature: t.billNature, section: tdsSection(t), gross: num(t.gross), incomeBefore: t.incomeBefore !== null ? num(t.incomeBefore) : '', incomeAfter: t.incomeAfter !== null ? num(t.incomeAfter) : '', correctTax: num(t.correctTax), actualTax: num(t.actualTax), creditApplied: num(t.creditApplied || 0), status: t.status + (t.excludedReason ? ' - ' + t.excludedReason : '') };
      if (t.slabBreakdown && t.slabBreakdown.length) t.slabBreakdown.forEach(seg => rows.push({ ...base, slabLabel: seg.label, slabRate: (seg.rate * 100).toFixed(2) + '%', portionAmount: num(seg.portionAmount), taxOnPortion: num(seg.taxOnPortion) }));
      else rows.push({ ...base, slabLabel: t.method === 'flat' ? 'Flat Rate' : '-', slabRate: t.flatRate ? (t.flatRate * 100).toFixed(2) + '%' : '-', portionAmount: num(t.gross), taxOnPortion: num(t.actualTax) });
    });
    if (!exportCSV(rows, TDS_CSV, 'Tax_Deduction_Statement_' + String(s.key).replace(/[^\w-]/g, '_') + '_' + s.fy + '.csv')) toast('Nothing to export.', 'error');
  }
  const s = res && res.statement;
  const lbl = { color: 'var(--text-muted)' };
  return (
    <>
      <div className="card no-print">
        <h3>Tax Deduction Statement</h3>
        <p style={note}>A complete, auditable justification of every rupee of Income Tax on record for one UE/Non-UE Employee in one FY - every transaction, chronologically, with the FBR section applied, and for a Section 149 slab transaction, exactly which bracket(s) its amount fell into and the rate applied to each portion. Any credit applied, and the running annual income before/after each transaction, are shown too - downloadable as CSV or PDF.</p>
        <div className="row">
          <Filter label="Payee Type" max={200}><select id="rtds_payeeType" value={payeeType} onChange={e => setPayeeType(e.target.value)}><option value="Employee">UE Employee</option><option value="NonUEEmployee">Non-UE Employee</option></select></Filter>
          <Filter label={payeeType === 'Employee' ? 'Employee ID' : 'CNIC'}><input type="text" id="rtds_key" value={key} onChange={e => setKey(e.target.value)} /></Filter>
          <Filter label="Financial Year" max={200}><select id="rtds_fy" value={fy} onChange={e => setFy(e.target.value)}>{FYS.map(y => <option key={y}>{y}</option>)}</select></Filter>
          <div className="field" style={{ alignSelf: 'flex-end' }}>
            <button className="primary" id="btnRtdsGenerate" onClick={generate}>Generate</button>
            {s && <> <button className="secondary" id="btnRtdsCsv" onClick={csv}>Download CSV</button> <button className="secondary" id="btnRtdsPdf" onClick={() => window.print()}>Print / Save as PDF</button></>}
          </div>
        </div>
      </div>
      <div className="card" id="rtdsResult">
        {err && <p className="error">{err}</p>}
        {s && <>
          <div style={{ border: '1px solid var(--border)', borderRadius: 8, padding: 14, marginBottom: 14 }}>
            <div style={{ fontWeight: 700, color: 'var(--accent)', marginBottom: 8, fontSize: 15 }}>{res.displayName}{res.designation ? ' - ' + res.designation : ''} ({payeeType === 'Employee' ? 'UE Employee' : 'Non-UE Employee'}, {key.trim()}) - FY {s.fy}</div>
            <div className="row" style={{ gap: 20 }}>
              {[['Annual Taxable Income on file', s.annualIncomeAtStart], ['Cumulative Income after all counted transactions', s.finalCumulativeIncome], ['Total Slab Gross (counted)', s.totalSlabGross], ['Total Actually Withheld', s.totalSlabActualTax], ['Total Correct Tax Due', s.totalSlabCorrectTax], ['Total Credit Applied', s.totalCreditApplied]].map(([l, v]) => <div key={l}><span style={lbl}>{l}</span><br /><b>{num(v)}</b></div>)}
              <div><span style={lbl}>Current Ledger Balance</span><br /><b style={{ color: s.currentLedgerBalance >= 0 ? 'var(--accent)' : 'var(--danger)' }}>{num(Math.abs(s.currentLedgerBalance))} {s.currentLedgerBalance >= 0 ? '(Credit)' : '(Outstanding)'}</b></div>
            </div>
          </div>
          <div className="table-wrap"><table>
            <thead><tr><th>Bill ID</th><th>Date</th><th>Nature</th><th>FBR Section</th><th>Gross</th><th>Income Before</th><th>Income After</th><th>Slab Breakdown</th><th>Correct Tax</th><th>Actually Withheld</th><th>Credit Applied</th><th>Status</th></tr></thead>
            <tbody>{s.transactions.map((t, i) => (
              <tr key={i} style={!t.countsTowardThreshold && t.method === 'slab' ? { opacity: 0.55 } : undefined}>
                <td><BillLink id={t.id} onOpen={onOpenBill} /></td><td>{fmtDate(t.date)}</td><td>{t.billNature}</td><td>{tdsSection(t)}</td><td>{num(t.gross)}</td>
                <td>{t.incomeBefore !== null ? num(t.incomeBefore) : '-'}</td><td>{t.incomeAfter !== null ? num(t.incomeAfter) : '-'}</td>
                <td style={{ whiteSpace: 'pre-line' }}>{tdsSlabText(t)}</td><td>{num(t.correctTax)}</td><td>{num(t.actualTax)}</td><td>{num(t.creditApplied || 0)}</td>
                <td>{t.status}{t.excludedReason ? ' - ' + t.excludedReason : ''}</td></tr>))}</tbody>
          </table></div>
        </>}
      </div>
    </>
  );
}

/* ================= Diary Report ================= */
function DiaryChart({ rows }) {
  const days = (rows || []).map(r => Number(r.daysInQueue) || 0);
  const data = [{ day: '0-1', count: days.filter(d => d <= 1).length }];
  for (let d = 2; d <= 6; d++) data.push({ day: String(d), count: days.filter(x => x === d).length });
  data.push({ day: '7+', count: days.filter(d => d >= 7).length });
  const max = Math.max(1, ...data.map(d => d.count));
  return (
    <div id="diaryReportChart">
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, padding: '10px 4px', borderBottom: '1px solid var(--border)' }}>
        {data.map(d => (
          <div key={d.day} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-end', flex: 1, minWidth: 36, height: 170 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>{d.count}</div>
            <div style={{ width: '60%', background: 'var(--accent)', borderRadius: '4px 4px 0 0', height: Math.round((d.count / max) * 140), minHeight: 2 }} />
            <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 6 }}>{d.day}</div>
          </div>))}
      </div>
      <div style={{ textAlign: 'center', fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>Days in Queue / to Complete &rarr;</div>
    </div>
  );
}

export function DiaryReport({ user, onOpenDiaryTrail }) {
  const { run } = useToast();
  const clerk = user.role === 'DiaryClerk';
  const [users, setUsers] = useState([]);
  const [offices, setOffices] = useState([]);
  const [f, setF] = useState({ user: clerk ? '' : user.username, office: '', query: '', completed: true });
  const [rows, setRows] = useState(null);
  const [cap, setCap] = useState('');
  const ref = useTableRef();
  useEffect(() => {
    gs('getDiaryEligibleUsers').then(setUsers).catch(() => {});
    gs('getReceivingOffices').then(setOffices).catch(() => {});
  }, []);
  async function load() {
    const res = await run(() => gs('getDiaryReport', { assignedTo: f.user, originatingOfficeId: f.office, query: f.query.trim(), includeCompleted: f.completed }), 'Building report...', 'Report loaded.');
    if (!res || !res.rows) return;
    const office = offices.find(o => o.OfficeID === f.office);
    const bits = ['User: ' + (f.user || 'All Users'), 'Originating Office: ' + (office ? office.OfficeName : 'All Offices')];
    if (f.query.trim()) bits.push('Search "' + f.query.trim() + '"');
    setCap(bits.join('  |  ')); setRows(res.rows);
  }
  const typeLabel = r => (r.itemType === 'Bill' && r.billType) ? 'Bill (' + r.billType + ')' : r.itemType;
  return (
    <>
      <div className="card no-print">
        <h3>Filters</h3>
        <div className="row">
          <Filter label="User"><select id="dr_user" value={f.user} onChange={e => setF({ ...f, user: e.target.value })}><option value="">All Users</option>{users.map(u => <option key={u.Username} value={u.Username}>{u.FullName}</option>)}</select></Filter>
          <Filter label="Originating Office"><select id="dr_office" value={f.office} onChange={e => setF({ ...f, office: e.target.value })}><option value="">All Offices</option>{offices.map(o => <option key={o.OfficeID} value={o.OfficeID}>{o.OfficeName}</option>)}</select></Filter>
          <Filter label="Beneficiary/Vendor/Employee Name or ID"><input type="text" id="dr_query" value={f.query} onChange={e => setF({ ...f, query: e.target.value })} /></Filter>
          <div className="field" style={{ alignSelf: 'flex-end' }}><label style={{ display: 'flex', alignItems: 'center', gap: 6, fontWeight: 'normal' }}><input type="checkbox" id="dr_includeCompleted" style={{ width: 'auto' }} checked={f.completed} onChange={e => setF({ ...f, completed: e.target.checked })} /> Include Completed</label></div>
        </div>
        <button className="primary" id="btnDiaryReport" onClick={load}>Load Report</button> <ExportButtons tables={[{ ref, file: 'Diary_Report.csv' }]} />
      </div>
      <div className="card">
        <h3 style={{ fontSize: 14, color: 'var(--text-muted)' }}>Turnaround - Number of Bills/Letters by Days in Queue (or Days to Complete)</h3>
        {rows && <DiaryChart rows={rows} />}
      </div>
      <div className="card table-wrap">
        <Caption text={cap} />
        <table id="diaryReportTable" ref={ref}>
          <thead><tr><th>Diary Number</th><th>Date</th><th>Type</th><th>Originating Office</th><th>Assigned To</th><th>Current Status</th><th className="num">Days in Queue / Total Days</th></tr></thead>
          <tbody>{rows === null ? <EmptyRow cols={7} text="Click Load Report." /> : rows.length ? rows.map(r => (
            <tr key={r.diaryId}>
              <td><a href="#trail" onClick={e => { e.preventDefault(); onOpenDiaryTrail(r.diaryId); }} style={{ color: 'var(--accent)', fontWeight: 600, textDecoration: 'underline' }}>{r.diaryId}</a></td>
              <td>{fmtDate(r.date)}</td><td>{typeLabel(r)}</td><td>{r.campus}</td><td>{r.assignedTo}</td><td>{r.currentStatus}</td><td className="num">{r.daysInQueue}{r.isComplete ? ' (total)' : ''}</td></tr>)) : <EmptyRow cols={7} />}</tbody>
        </table>
      </div>
    </>
  );
}

/* ================= Tax Calculation Details ================= */
// [key, label, shown by default, kind]
const TCD_COLUMNS = [
  ['billId', 'Bill / Line ID', true, 'id'], ['parentBillId', 'Parent Bill ID', false, 'id'], ['date', 'Date', false, 'date'], ['campus', 'Campus', false],
  ['payeeType', 'Beneficiary Type', true, 'payeeType'], ['employeeId', 'Employee ID', true], ['cnic', 'CNIC / NTN', false], ['beneficiary', 'Beneficiary Name', true],
  ['iban', 'IBAN', false], ['designation', 'Designation', false], ['billNature', 'Nature of Bill', true], ['gross', 'Gross Amount', true, 'amount'],
  ['fbrSection', 'FBR Section', true], ['incomeTaxRate', 'Income Tax Rate', true, 'rate'], ['incomeTaxAmount', 'Income Tax Amount', true, 'amount'],
  ['affidavit', 'Affidavit of Low Income (Non-UE)', false, 'bool'], ['nonUeTaxMethod', 'Non-UE Tax Method', false],
  ['incomeBefore', 'Income Before This Bill', false, 'amount'], ['incomeAfter', 'Income After This Bill', false, 'amount'],
  ['creditApplied', 'Section 149 Credit Applied', false, 'amount'], ['outstandingAdjusted', 'Section 149 Outstanding Adjusted', false, 'amount'],
  ['salesTaxRate', 'Sales Tax Rate', false, 'rate'], ['salesTaxAmount', 'Sales Tax Amount', false, 'amount'], ['pstRate', 'Punjab Sales Tax Rate', false, 'rate'],
  ['pstAmount', 'Punjab Sales Tax Amount', false, 'amount'], ['pstCategory', 'Contract Category (PST)', false], ['securityRate', 'Security Rate', false, 'rate'],
  ['securityAmount', 'Security Amount', false, 'amount'], ['penaltyRate', 'Penalty Rate', false, 'rate'], ['penaltyAmount', 'Penalty Amount', false, 'amount'],
  ['otherDeductionRate', 'Other Deduction Rate', false, 'rate'], ['otherDeductionAmount', 'Other Deduction Amount', false, 'amount'],
  ['studentDeductionAmount', 'Student Deduction', false, 'amount'], ['manualTaxOverride', 'Manual Tax Override', false, 'bool'], ['netAmount', 'Net Amount', true, 'amount'],
  ['pipelineStatus', 'Pipeline Status', true], ['linePaymentStatus', 'Payment Status', false], ['redirectedTo', 'Redirected / Isolated To', false, 'id']
];

export function TaxCalcDetails({ user, onOpenBill }) {
  const { toast, run } = useToast();
  const [billId, setBillId] = useState('');
  const [res, setRes] = useState(null);
  const [vis, setVis] = useState(() => TCD_COLUMNS.filter(c => c[2]).map(c => c[0]));
  const [picker, setPicker] = useState(false);
  const ref = useTableRef();
  async function load() {
    if (!billId.trim()) { toast('Enter a Bill ID first.', 'error'); return; }
    const r = await run(() => gs('getTaxCalculationDetails', billId.trim(), user.username), 'Calculating...');
    if (!r || r.success === false) return;
    setRes(r);
  }
  const selected = TCD_COLUMNS.filter(c => vis.includes(c[0]));
  const cell = (row, [key, , , kind]) => {
    const v = row[key];
    if (kind === 'amount') return (v === null || v === undefined || v === '') ? '-' : num(v);
    if (kind === 'rate') return v ? (v * 100).toFixed(2) + '%' : '-';
    if (kind === 'bool') return (v === null || v === undefined) ? 'Not Recorded' : (v ? 'Yes' : 'No');
    if (kind === 'date') return v ? fmtDate(v) : '-';
    if (kind === 'id') return v ? <BillLink id={v} onOpen={onOpenBill} /> : '-';
    if (kind === 'payeeType') return payeeTypeLabel(v);
    return (v === null || v === undefined || v === '') ? '-' : v;
  };
  return (
    <>
      <div className="card no-print">
        <h3>Tax Calculation Details</h3>
        <p style={note}>Enter a Bill ID for a single-payee bill, a bulk bill's own ID (shows every beneficiary, one row each, each with its own FBR Section), or one specific beneficiary's own line ID (e.g. E345-2) for just that person.</p>
        <div className="row">
          <Filter label="Bill ID / Line ID"><input type="text" id="tcd_billid" placeholder="e.g. E1042 or E1042-3" value={billId} onChange={e => setBillId(e.target.value)} /></Filter>
          <div className="field" style={{ alignSelf: 'flex-end' }}>
            <button className="primary" id="btnTcdLoad" onClick={load}>Load</button> <button className="secondary" onClick={() => setPicker(p => !p)}>Column Visibility</button> <ExportButtons tables={[{ ref, file: 'Tax_Calculation_Details.csv' }]} />
          </div>
        </div>
        {picker && <div style={{ marginTop: 10 }}>
          <label>Columns <label style={{ display: 'inline', fontWeight: 'normal' }}><input type="checkbox" style={{ width: 'auto' }} checked={vis.length === TCD_COLUMNS.length} onChange={e => setVis(e.target.checked ? TCD_COLUMNS.map(c => c[0]) : [])} /> Select All</label></label>
          <div className="checklist" id="tcd_columns">{TCD_COLUMNS.map(([k, l]) => <label key={k}><input type="checkbox" className="tcdcol" checked={vis.includes(k)} onChange={e => setVis(v => e.target.checked ? v.concat(k) : v.filter(x => x !== k))} /> {l}</label>)}</div>
        </div>}
      </div>
      <div className="card table-wrap">
        {res && <Caption text={'Bill: ' + res.billId + (res.isBulk ? ' (Bulk - ' + res.rows.length + ' beneficiar' + (res.rows.length === 1 ? 'y' : 'ies') + ')' : '') + '  |  Nature: ' + (res.billNature || '-')} />}
        <table id="tcdTable" ref={ref}>
          <thead><tr>{selected.map(c => <th key={c[0]} className={c[3] === 'amount' || c[3] === 'rate' ? 'num' : undefined}>{c[1]}</th>)}</tr></thead>
          <tbody>{!res ? <tr><td style={{ textAlign: 'center', color: 'var(--text-muted)' }}>Enter a Bill ID above and click Load.</td></tr>
            : res.rows.length ? res.rows.map((row, i) => <tr key={i}>{selected.map(c => <td key={c[0]} className={c[3] === 'amount' || c[3] === 'rate' ? 'num' : undefined}>{cell(row, c)}</td>)}</tr>)
            : <EmptyRow cols={selected.length || 1} text="No rows." />}</tbody>
        </table>
      </div>
    </>
  );
}
