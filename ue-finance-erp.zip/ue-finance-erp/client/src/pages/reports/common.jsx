import React, { useRef } from 'react';
import { tableToCSV } from '../../util.js';
import { useToast } from '../../ui.jsx';

/* Buttons shared by every report: Download CSV for one or more tables, and Print / Save as PDF. */
export function ExportButtons({ tables }) {   // tables: [{ref, file, label}]
  const { toast } = useToast();
  return (
    <>
      {tables.map(t => (
        <button key={t.file} className="secondary" onClick={() => { if (!tableToCSV(t.ref.current, t.file)) toast('Nothing to export - load the report first.', 'error'); }}>
          {t.label || 'Download CSV'}
        </button>
      ))}
      <button className="secondary" onClick={() => window.print()} title="In the print window choose 'Save as PDF' to keep a PDF copy">Print / Save as PDF</button>
    </>
  );
}
export const Caption = ({ text }) => text ? <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginBottom: 10 }}>{text}</div> : null;
export function Status({ s }) { return <span className={'pill ' + s}>{s}</span>; }
export function Filter({ label, children, max }) { return <div className="field" style={max ? { maxWidth: max } : undefined}><label>{label}</label>{children}</div>; }
export function useTableRef() { return useRef(null); }
