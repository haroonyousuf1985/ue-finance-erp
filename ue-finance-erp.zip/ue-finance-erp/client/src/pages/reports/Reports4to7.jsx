import React, { useMemo, useState } from 'react';
import { gs } from '../../api.js';
import { DEFAULT_FY, todayISO, fyOptions, fmtDate, num, netOf, oneCampusLabel, rowMatches, IBFT_COLUMNS, IBFT_NUMERIC, exportCSV } from '../../util.js';
import { useToast, EmptyRow, FYSelect, BillLink } from '../../ui.jsx';
import { ExportButtons, Caption, Status, Filter, useTableRef } from './common.jsx';

const FYS = fyOptions();
const CampusSel = ({ value, onChange, campuses }) => <select value={value} onChange={e => onChange(e.target.value)}><option value="">All Campuses</option>{campuses.map(c => <option key={c.CampusID} value={c.CampusID}>{c.CampusName}</option>)}</select>;

/* ---------- Budget Control Register ---------- */
export function ControlRegister({ campuses, heads, onOpenBill }) {
  const { run } = useToast();
  const [f, setF] = useState({ fy: DEFAULT_FY, campus: '', head: '' });
  const [rep, setRep] = useState(null);
  const [cap, setCap] = useState('');
  const ref = useTableRef();
  async function load() {
    const filters = { fy: f.fy, campusIds: f.campus ? [f.campus] : [], headIds: f.head ? [f.head] : [] };
    const r = await run(() => gs('getBudgetControlRegister', filters), 'Building register...', 'Register loaded.');
    if (!r || r.success === false) return;
    const headLabel = f.head ? (heads.find(h => h.HeadID === f.head) || {}).HeadName : 'All Budget Heads';
    setCap('Cost Centre: ' + oneCampusLabel(f.campus, campuses) + '  |  Financial Year: ' + f.fy + '  |  Budget Head: ' + headLabel);
    setRep(r);
  }
  return (
    <>
      <div className="card no-print">
        <h3>Filters</h3>
        <div className="row">
          <Filter label="Financial Year"><select value={f.fy} onChange={e => setF({ ...f, fy: e.target.value })}>{FYS.map(y => <option key={y}>{y}</option>)}</select></Filter>
          <Filter label="Campus"><CampusSel value={f.campus} campuses={campuses} onChange={v => setF({ ...f, campus: v })} /></Filter>
          <Filter label="Budget Head"><select value={f.head} onChange={e => setF({ ...f, head: e.target.value })}><option value="">All Budget Heads</option>{heads.map(h => <option key={h.HeadID} value={h.HeadID}>{h.HeadName}</option>)}</select></Filter>
        </div>
        <button className="primary" onClick={load}>Load Register</button> <ExportButtons tables={[{ ref, file: 'Budget_Control_Register.csv' }]} />
      </div>
      <div className="card table-wrap">
        <Caption text={cap} />
        <table ref={ref}>
          <thead><tr><th>Campus</th><th>Budget Head</th><th>Bill ID</th><th>Date</th><th>Description</th><th className="num">Allocation</th><th className="num">Bill Amount</th><th className="num">Already Consumed</th><th className="num">New Total</th><th className="num">Remaining Balance</th></tr></thead>
          <tbody>
            {!rep && <EmptyRow cols={10} text="Click Load Register." />}
            {rep && rep.groups.length === 0 && <EmptyRow cols={10} />}
            {rep && rep.groups.map((g, gi) => g.bills.length === 0
              ? <tr key={gi}><td>{g.campusName}</td><td>{g.headCode} - {g.headName}</td><td colSpan={7} style={{ color: 'var(--text-muted)' }}>No bills posted yet</td><td className="num">{num(g.allocated)}</td></tr>
              : g.bills.map((b, i) => (
                <tr key={gi + '-' + i}>
                  <td>{i === 0 ? g.campusName : ''}</td><td>{i === 0 ? g.headCode + ' - ' + g.headName : ''}</td>
                  <td><BillLink id={b.entryId} onOpen={onOpenBill} /></td><td>{fmtDate(b.date)}</td><td>{b.description || ''}</td>
                  <td className="num">{i === 0 ? num(g.allocated) : ''}</td><td className="num">{num(b.amount)}</td><td className="num">{num(b.consumedBefore)}</td><td className="num">{num(b.progressiveTotal)}</td><td className="num">{num(b.runningBalance)}</td>
                </tr>)))}
          </tbody>
        </table>
      </div>
    </>
  );
}

/* ---------- General Ledger ---------- */
export function GeneralLedger({ onOpenBill }) {
  const { run } = useToast();
  const [f, setF] = useState({ fy: '', vendor: '', cnic: '', iban: '', employeeId: '' });
  const [rep, setRep] = useState(null);
  const [cap, setCap] = useState('');
  const sRef = useTableRef(), dRef = useTableRef();
  const set = k => e => setF({ ...f, [k]: e.target.value });
  async function load() {
    const r = await run(() => gs('getGeneralLedger', f), 'Building ledger...', 'Ledger loaded.');
    if (!r || r.success === false) return;
    const bits = ['Cost Centre: All Cost Centres', 'Financial Year: ' + r.fy];
    [['vendor', 'Vendor/Employee'], ['cnic', 'CNIC/NTN'], ['iban', 'IBAN'], ['employeeId', 'Employee ID']].forEach(([k, l]) => f[k] && bits.push(l + ' contains "' + f[k] + '"'));
    setCap(bits.join('  |  ')); setRep(r);
  }
  const details = rep ? rep.vendors.flatMap(v => v.bills.map(b => ({ v, b }))) : [];
  return (
    <>
      <div className="card no-print">
        <h3>Filters</h3>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>Vendors and Employees only - Students don't get a General Ledger account.</p>
        <div className="row">
          <Filter label="Financial Year"><FYSelect value={f.fy} onChange={v => setF({ ...f, fy: v })} options={FYS} /></Filter>
          <Filter label="Vendor/Employee contains"><input type="text" value={f.vendor} onChange={set('vendor')} /></Filter>
          <Filter label="CNIC/NTN contains"><input type="text" value={f.cnic} onChange={set('cnic')} /></Filter>
          <Filter label="IBAN contains"><input type="text" value={f.iban} onChange={set('iban')} /></Filter>
          <Filter label="Employee ID contains"><input type="text" value={f.employeeId} onChange={set('employeeId')} /></Filter>
        </div>
        <button className="primary" onClick={load}>Load Ledger</button>{' '}
        <ExportButtons tables={[{ ref: sRef, file: 'General_Ledger.csv' }, { ref: dRef, file: 'General_Ledger_Detail.csv', label: 'Download Detail CSV' }]} />
      </div>
      <div className="card table-wrap">
        <Caption text={cap} />
        <table ref={sRef}>
          <thead><tr><th>Vendor/Employee</th><th>Employee ID</th><th>IBAN</th><th>CNIC/NTN</th><th className="num">Bills Paid</th><th className="num">Gross Disbursed</th><th className="num">Income Tax</th><th className="num">Sales Tax</th><th className="num">Punjab Sales Tax</th><th className="num">Penalty</th><th className="num">Security Deducted</th><th className="num">Other Deductions</th><th className="num">Net Paid</th><th className="num">Security Balance (all years)</th></tr></thead>
          <tbody>
            {!rep && <EmptyRow cols={14} text="Click Load Ledger." />}
            {rep && rep.vendors.length === 0 && <EmptyRow cols={14} />}
            {rep && rep.vendors.map((v, i) => (
              <tr key={i}><td>{v.vendorName}</td><td>{v.employeeId || ''}</td><td>{v.iban || ''}</td><td>{v.cnic || ''}</td><td className="num">{v.billCount}</td><td className="num">{num(v.totals.gross)}</td>
                <td className="num">{num(v.totals.incomeTax)}</td><td className="num">{num(v.totals.salesTax)}</td><td className="num">{num(v.totals.pst)}</td><td className="num">{num(v.totals.penalty)}</td>
                <td className="num">{num(v.totals.security)}</td><td className="num">{num(v.totals.otherDeductions)}</td><td className="num">{num(v.totals.net)}</td><td className="num">{num(v.securityBalance)}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="card">
        <h3>Bill-level Detail</h3>
        <div className="table-wrap">
          <table ref={dRef}>
            <thead><tr><th>Vendor</th><th>Bill ID</th><th>Date</th><th>Campus</th><th>Budget Head</th><th>Status</th><th>Bill No.</th><th>Description</th><th>Nature</th><th className="num">Gross</th><th className="num">Income Tax</th><th className="num">Sales Tax</th><th className="num">Punjab Sales Tax</th><th className="num">Penalty</th><th className="num">Security</th><th className="num">Other</th><th className="num">Net</th></tr></thead>
            <tbody>
              {!rep && <EmptyRow cols={17} text="Click Load Ledger." />}
              {rep && details.length === 0 && <EmptyRow cols={17} />}
              {details.map(({ v, b }, i) => (
                <tr key={i}><td>{v.vendorName}</td><td><BillLink id={b.entryId} onOpen={onOpenBill} /></td><td>{fmtDate(b.date)}</td><td>{b.campus || ''}</td>
                  <td>{b.headCode ? b.headCode + ' - ' + (b.headName || '') : (b.headName || '')}</td><td><Status s={b.status || ''} /></td><td>{b.billNo || ''}</td><td>{b.description || ''}</td><td>{b.nature || ''}</td>
                  <td className="num">{num(b.gross)}</td><td className="num">{num(b.incomeTax)}</td><td className="num">{num(b.salesTax)}</td><td className="num">{num(b.pst)}</td><td className="num">{num(b.penalty)}</td><td className="num">{num(b.security)}</td><td className="num">{num(b.otherDeductions)}</td><td className="num">{num(b.net)}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

/* ---------- IBFT Payment (every bill actually paid out) ---------- */
export function IbftPayment() {
  const { run, toast } = useToast();
  const [from, setFrom] = useState('2026-07-01');
  const [to, setTo] = useState(todayISO());
  const [res, setRes] = useState(null);
  const [cap, setCap] = useState('');
  const [q, setQ] = useState('');
  const shown = useMemo(() => (res ? res.items.filter(it => !q.trim() || IBFT_COLUMNS.some(([k]) => String(it[k] ?? '').toLowerCase().includes(q.trim().toLowerCase()))) : []), [res, q]);
  const totalNet = shown.reduce((s, it) => s + Number(it.netPayment || 0), 0);
  async function load() {
    const r = await run(() => gs('getIBFTPaymentReport', { fromDate: from, toDate: to }), 'Loading IBFT Payment report...');
    if (!r || r.success === false) return;
    setRes(r); setQ(''); setCap('Cost Centre: All Cost Centres  |  Payment Date: ' + (from || 'earliest') + ' to ' + (to || 'latest'));
  }
  return (
    <>
      <div className="card no-print">
        <h3>Filters</h3>
        <div className="row"><Filter label="Payment Date From"><input type="date" value={from} onChange={e => setFrom(e.target.value)} /></Filter><Filter label="Payment Date To"><input type="date" value={to} onChange={e => setTo(e.target.value)} /></Filter></div>
        <button className="primary" onClick={load}>Load Report</button>{' '}
        <button className="secondary" onClick={() => { if (!exportCSV(shown, IBFT_COLUMNS, 'IBFT_Payment_Report.csv')) toast('Nothing to export - load the report first.', 'error'); }}>Download CSV</button>{' '}
        <button className="secondary" onClick={() => window.print()}>Print / Save as PDF</button>
      </div>
      <div className="card">
        <h3 style={{ color: 'var(--text-muted)', fontSize: 14 }}>{res ? shown.length + ' payment(s)' : ''} &nbsp; Total Net Payment: {res ? num(totalNet) : '-'}</h3>
        <Caption text={cap} />
        <div className="row no-print"><Filter label="Search (all loaded fields - name, CNIC, IBAN, Bill ID, description, ...)"><input type="text" value={q} onChange={e => setQ(e.target.value)} placeholder="Type to filter the rows already loaded above" /></Filter></div>
        {res && shown.length === 0 && <p style={{ color: 'var(--text-muted)' }}>No paid bills match.</p>}
        {res && shown.length > 0 && (
          <div className="table-wrap"><table>
            <thead><tr>{IBFT_COLUMNS.map(([, l]) => <th key={l}>{l}</th>)}</tr></thead>
            <tbody>{shown.map((it, i) => <tr key={i}>{IBFT_COLUMNS.map(([k]) => <td key={k} className={IBFT_NUMERIC.has(k) ? 'num' : undefined}>{IBFT_NUMERIC.has(k) ? num(it[k]) : (it[k] ?? '')}</td>)}</tr>)}</tbody>
          </table></div>
        )}
      </div>
    </>
  );
}

/* ---------- Confirmed Payments ---------- */
export function ConfirmedPayments({ campuses, onOpenBill }) {
  const { run, toast } = useToast();
  const [f, setF] = useState({ fy: '', campusId: '', billId: '', employeeId: '', vendor: '', description: '', minAmount: '', maxAmount: '' });
  const [list, setList] = useState(null);
  const [cap, setCap] = useState('');
  const [q, setQ] = useState('');
  const ref = useTableRef();
  const set = k => e => setF({ ...f, [k]: e.target.value });
  const shown = useMemo(() => (list || []).filter(r => rowMatches(r, q)), [list, q]);
  async function load() {
    const r = await run(() => gs('getConfirmedPayments', f), 'Loading confirmed payments...', 'Loaded.');
    if (!r || r.success === false) return;
    setList(r.rows || []); setQ('');
    if (r.truncated) toast('Showing the first 1000 of ' + r.totalMatched + ' matching payments - narrow your filters to see the rest.', 'error');
    const bits = ['Cost Centre: ' + oneCampusLabel(f.campusId, campuses), 'Financial Year: ' + (f.fy || 'All Years')];
    [['billId', 'Bill ID contains "'], ['employeeId', 'Employee ID contains "'], ['vendor', 'Name contains "'], ['description', 'Description contains "']].forEach(([k, l]) => f[k] && bits.push(l + f[k] + '"'));
    if (f.minAmount) bits.push('Min Amount ' + f.minAmount); if (f.maxAmount) bits.push('Max Amount ' + f.maxAmount);
    setCap(bits.join('  |  '));
  }
  return (
    <>
      <div className="card no-print">
        <h3>Confirmed Payments</h3>
        <p style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>Set your filters, then click Load - this does not fetch automatically, to stay fast as the number of confirmed payments grows into the thousands.</p>
        <div className="row">
          <Filter label="Financial Year" max={200}><FYSelect value={f.fy} onChange={v => setF({ ...f, fy: v })} options={FYS} /></Filter>
          <Filter label="Campus"><CampusSel value={f.campusId} campuses={campuses} onChange={v => setF({ ...f, campusId: v })} /></Filter>
          <Filter label="Bill ID contains"><input type="text" value={f.billId} onChange={set('billId')} /></Filter>
          <Filter label="Employee ID contains"><input type="text" value={f.employeeId} onChange={set('employeeId')} /></Filter>
        </div>
        <div className="row">
          <Filter label="Vendor/Employee/Name contains"><input type="text" value={f.vendor} onChange={set('vendor')} /></Filter>
          <Filter label="Description contains"><input type="text" value={f.description} onChange={set('description')} /></Filter>
          <Filter label="Min Amount"><input type="number" value={f.minAmount} onChange={set('minAmount')} /></Filter>
          <Filter label="Max Amount"><input type="number" value={f.maxAmount} onChange={set('maxAmount')} /></Filter>
        </div>
        <button className="primary" onClick={load}>Load</button> <ExportButtons tables={[{ ref, file: 'Confirmed_Payments.csv' }]} />
        <div className="row"><Filter label="Search (loaded results)"><input type="text" value={q} onChange={e => setQ(e.target.value)} placeholder="Type to filter rows already loaded above" /></Filter></div>
      </div>
      <div className="card table-wrap">
        <Caption text={cap} />
        <table ref={ref}>
          <thead><tr><th>Bill / Line ID</th><th>Campus</th><th>Employee ID</th><th>Beneficiary</th><th>IBAN</th><th>Bill Description</th><th>FBR Section</th><th className="num">Gross Amount</th><th className="num">Income Tax</th><th className="num">Sales Tax</th><th className="num">Punjab Sales Tax</th><th className="num">Security</th><th className="num">Penalty</th><th className="num">Other Deductions</th><th className="num">Net</th><th>Confirmed Date</th><th>Status</th></tr></thead>
          <tbody>
            {list === null && <EmptyRow cols={17} text="Set filters above and click Load." />}
            {list && shown.length === 0 && <EmptyRow cols={17} />}
            {shown.map((e, i) => (
              <tr key={i}><td><BillLink id={e.EntryID} onOpen={onOpenBill} /></td><td>{e.CampusName}</td><td>{e.EmployeeID || ''}</td><td>{e.VendorName}</td><td>{e.IBAN || ''}</td><td>{e.BillDescription || ''}</td><td>{e.IncomeTaxSection || '-'}</td>
                <td className="num">{num(e.Amount)}</td><td className="num">{num(e.IncomeTaxAmount)}</td><td className="num">{num(e.SalesTaxAmount)}</td><td className="num">{num(e.PSTAmount)}</td><td className="num">{num(e.SecurityAmount)}</td><td className="num">{num(e.PenaltyAmount)}</td><td className="num">{num(e.OtherDeductionAmount)}</td>
                <td className="num">{num(netOf(e))}</td><td>{fmtDate(e.LinePaymentConfirmedDate || e.PaymentConfirmedDate || e.PaidDate)}</td><td><Status s={e.Status} /></td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
