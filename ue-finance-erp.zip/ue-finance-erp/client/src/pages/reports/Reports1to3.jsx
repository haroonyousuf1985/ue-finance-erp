import React, { useMemo, useState } from 'react';
import { gs } from '../../api.js';
import { DEFAULT_FY, fyOptions, fmtDate, num, netOf, campusLabel, oneCampusLabel, rowMatches } from '../../util.js';
import { useToast, EmptyRow, FYSelect } from '../../ui.jsx';
import { ExportButtons, Caption, Status, Filter, useTableRef } from './common.jsx';

const FYS = fyOptions();
const FYPlain = ({ value, onChange }) => <select value={value} onChange={e => onChange(e.target.value)}>{FYS.map(f => <option key={f}>{f}</option>)}</select>;

/* ---------- Yearly Budget Matrix ---------- */
export function Yearly({ campuses }) {
  const { run } = useToast();
  const [fy, setFy] = useState(DEFAULT_FY);
  const [picked, setPicked] = useState(null);       // null = all
  const [rep, setRep] = useState(null);
  const [cap, setCap] = useState('');
  const ref = useTableRef();
  const ids = picked || campuses.map(c => c.CampusID);
  const toggle = id => setPicked(p => { const cur = new Set(p || campuses.map(c => c.CampusID)); cur.has(id) ? cur.delete(id) : cur.add(id); return Array.from(cur); });

  async function load() {
    const r = await run(() => gs('getYearlyBudgetReport', fy, ids), 'Building report...', 'Report loaded.');
    if (!r || r.success === false) return;
    setRep(r); setCap('Cost Centre: ' + campusLabel(ids, campuses) + '  |  Financial Year: ' + fy);
  }
  return (
    <>
      <div className="card no-print">
        <h3>Filters</h3>
        <div className="row"><Filter label="Financial Year" max={220}><FYPlain value={fy} onChange={setFy} /></Filter></div>
        <label>Cost Centres <label style={{ display: 'inline', fontWeight: 'normal' }}>
          <input type="checkbox" style={{ width: 'auto' }} checked={ids.length === campuses.length} onChange={e => setPicked(e.target.checked ? null : [])} /> Select All</label></label>
        <div className="checklist">{campuses.map(c => <label key={c.CampusID}><input type="checkbox" checked={ids.includes(c.CampusID)} onChange={() => toggle(c.CampusID)} /> {c.CampusName}</label>)}</div>
        <div style={{ marginTop: 10 }}><button className="primary" onClick={load}>Load Report</button> <ExportButtons tables={[{ ref, file: 'Yearly_Budget_Matrix.csv' }]} /></div>
      </div>
      <div className="card table-wrap">
        <Caption text={cap} />
        <table ref={ref}>
          <thead><tr>{rep && <><th>Budget Head</th>{rep.months.map(m => <th key={m} className="num">{m}</th>)}<th className="num">Total Spent</th><th className="num">Allocated</th></>}</tr></thead>
          <tbody>
            {!rep && <EmptyRow cols={3} text="Choose a year and click Load Report." />}
            {rep && rep.rows.length === 0 && <EmptyRow cols={rep.months.length + 3} />}
            {rep && rep.rows.map(r => (
              <tr key={r.headCode + r.headName}><td>{r.headCode} - {r.headName}</td>{r.months.map((v, i) => <td key={i} className="num">{v ? num(v) : ''}</td>)}<td className="num">{num(r.totalSpent)}</td><td className="num">{num(r.allocated)}</td></tr>
            ))}
          </tbody>
          {rep && <tfoot><tr><td>Monthly Total</td>{rep.monthColumnTotals.map((v, i) => <td key={i} className="num">{num(v)}</td>)}<td className="num">{num(rep.grandTotalSpent)}</td><td className="num">{num(rep.grandAllocated)}</td></tr></tfoot>}
        </table>
      </div>
    </>
  );
}

/* ---------- Budget Consumption ---------- */
export function Consumption({ campuses, heads }) {
  const { run } = useToast();
  const [f, setF] = useState({ fy: '', campus: '', head: '', from: '', to: '', vendor: '' });
  const [rep, setRep] = useState(null);
  const [cap, setCap] = useState('');
  const sRef = useTableRef(), dRef = useTableRef();
  const set = k => e => setF({ ...f, [k]: e.target.value });

  async function load() {
    const filters = { fy: f.fy, campusIds: f.campus ? [f.campus] : [], headIds: f.head ? [f.head] : [], fromDate: f.from, toDate: f.to, vendor: f.vendor };
    const r = await run(() => gs('getConsumptionReport', filters), 'Building report...', 'Report loaded.');
    if (!r || r.success === false) return;
    const headLabel = f.head ? (heads.find(h => h.HeadID === f.head) || {}).HeadName : 'All Budget Heads';
    const bits = [];
    if (f.from) bits.push('From ' + f.from); if (f.to) bits.push('To ' + f.to); if (f.vendor) bits.push('Vendor contains "' + f.vendor + '"');
    setCap('Cost Centre: ' + r.scopeLabel + '  |  Financial Year: ' + r.fy + '  |  Budget Head: ' + headLabel + (bits.length ? '  |  ' + bits.join('  |  ') : ''));
    setRep(r);
  }
  return (
    <>
      <div className="card no-print">
        <h3>Filters</h3>
        <div className="row">
          <Filter label="Financial Year"><FYSelect value={f.fy} onChange={v => setF({ ...f, fy: v })} options={FYS} /></Filter>
          <Filter label="Campus"><select value={f.campus} onChange={set('campus')}><option value="">All Campuses</option>{campuses.map(c => <option key={c.CampusID} value={c.CampusID}>{c.CampusName}</option>)}</select></Filter>
          <Filter label="Budget Head"><select value={f.head} onChange={set('head')}><option value="">All Budget Heads</option>{heads.map(h => <option key={h.HeadID} value={h.HeadID}>{h.HeadName}</option>)}</select></Filter>
        </div>
        <div className="row">
          <Filter label="From Date (optional)"><input type="date" value={f.from} onChange={set('from')} /></Filter>
          <Filter label="To Date (optional)"><input type="date" value={f.to} onChange={set('to')} /></Filter>
          <Filter label="Vendor contains (optional)"><input type="text" value={f.vendor} onChange={set('vendor')} /></Filter>
        </div>
        <button className="primary" onClick={load}>Load Report</button>{' '}
        <ExportButtons tables={[{ ref: sRef, file: 'Budget_Consumption_Summary.csv', label: 'Download Summary CSV' }, { ref: dRef, file: 'Budget_Consumption_Detail.csv', label: 'Download Detail CSV' }]} />
      </div>
      <div className="card">
        <h3 style={{ color: 'var(--text-muted)', fontSize: 14 }}>{cap}</h3>
        <div className="balance-box">
          <div className="bal-allocated"><span className="label">Total Allocated</span><span className="val">{rep ? num(rep.totals.allocated) : '-'}</span></div>
          <div className="bal-spent"><span className="label">Total Consumed</span><span className="val">{rep ? num(rep.totals.spent) : '-'}</span></div>
          <div className="bal-remaining"><span className="label">Total Balance</span><span className="val">{rep ? num(rep.totals.balance) : '-'}</span></div>
        </div>
        <div className="table-wrap" style={{ marginTop: 14 }}>
          <table ref={sRef}>
            <thead><tr><th>Budget Code</th><th>Budget Head</th><th className="num">Allocated</th><th className="num">Spent</th><th className="num">Consumed %</th><th></th><th className="num">Balance</th></tr></thead>
            <tbody>
              {!rep && <EmptyRow cols={7} text="Click Load Report." />}
              {rep && rep.rows.length === 0 && <EmptyRow cols={7} />}
              {rep && rep.rows.map(r => {
                const pct = Math.round(r.consumedPct), cls = r.consumedPct > 100 ? 'over' : (r.consumedPct >= 80 ? 'high' : '');
                return <tr key={r.headCode + r.headName}><td>{r.headCode}</td><td>{r.headName}</td><td className="num">{num(r.allocated)}</td><td className="num">{num(r.spent)}</td><td className="num">{pct}%</td>
                  <td style={{ width: 110 }}><div className="progress-track"><div className={'progress-fill ' + cls} style={{ width: Math.min(pct, 100) + '%' }} /></div></td><td className="num">{num(r.balance)}</td></tr>;
              })}
            </tbody>
            {rep && <tfoot><tr><td colSpan={2}>Total</td><td className="num">{num(rep.totals.allocated)}</td><td className="num">{num(rep.totals.spent)}</td><td className="num">{Math.round(rep.totals.consumedPct)}%</td><td></td><td className="num">{num(rep.totals.balance)}</td></tr></tfoot>}
          </table>
        </div>
      </div>
      <div className="card">
        <h3>Bill-level Detail</h3>
        <div className="table-wrap">
          <table ref={dRef}>
            <thead><tr><th>Date</th><th>Campus</th><th>Code</th><th>Head</th><th>Vendor</th><th>Bill No.</th><th className="num">Amount</th><th>Status</th></tr></thead>
            <tbody>
              {!rep && <EmptyRow cols={8} text="Click Load Report." />}
              {rep && rep.entries.length === 0 && <EmptyRow cols={8} />}
              {rep && rep.entries.map((e, i) => <tr key={i}><td>{fmtDate(e.EntryDate)}</td><td>{e.CampusName}</td><td>{e.HeadCode}</td><td>{e.HeadName}</td><td>{e.VendorName}</td><td>{e.BillNo || ''}</td><td className="num">{num(e.Amount)}</td><td><Status s={e.Status} /></td></tr>)}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

/* ---------- Bill Status ---------- */
export function BillStatus({ campuses }) {
  const { run } = useToast();
  const [f, setF] = useState({ fy: '', status: '', campus: '', from: '', to: '', vendor: '', employeeId: '', amount: '', description: '', iban: '' });
  const [list, setList] = useState(null);
  const [cap, setCap] = useState('');
  const [q, setQ] = useState('');
  const ref = useTableRef();
  const set = k => e => setF({ ...f, [k]: e.target.value });
  const shown = useMemo(() => (list || []).filter(r => rowMatches(r, q)), [list, q]);

  async function load() {
    const filters = { fy: f.fy, status: f.status, campusIds: f.campus ? [f.campus] : [], fromDate: f.from, toDate: f.to, vendor: f.vendor, employeeId: f.employeeId, amount: f.amount, description: f.description, iban: f.iban };
    const r = await run(() => gs('getBillStatusReport', filters), 'Building report...', 'Report loaded.');
    if (!Array.isArray(r)) return;
    setList(r); setQ('');
    const bits = ['Cost Centre: ' + oneCampusLabel(f.campus, campuses), 'Financial Year: ' + (f.fy || 'All Years')];
    if (f.status) bits.push('Status: ' + f.status); if (f.from) bits.push('From ' + f.from); if (f.to) bits.push('To ' + f.to);
    [['vendor', 'Vendor'], ['employeeId', 'Employee ID'], ['amount', 'Amount'], ['description', 'Description'], ['iban', 'IBAN']].forEach(([k, l]) => f[k] && bits.push(l + ' contains "' + f[k] + '"'));
    setCap(bits.join('  |  '));
  }
  const heads = ['Bill ID', 'Bill No.', 'Entry Date', 'FY', 'Campus', 'Budget Code', 'Budget Head', 'Payee Type', 'Employee ID', 'Vendor/Payee', 'CNIC/NTN', 'IBAN', 'Description', 'Nature of Bill', 'FBR Section', 'Gross Amount', 'Income Tax', 'Sales Tax', 'Punjab Sales Tax', 'Security', 'Penalty', 'Other Deductions', 'Net Amount', 'Entered By', 'Status', 'Received Date', 'Processed By', 'Processed Date', 'Passed By', 'Passed Date', 'Paid By', 'Paid Date'];
  const numCols = new Set(['Gross Amount', 'Income Tax', 'Sales Tax', 'Punjab Sales Tax', 'Security', 'Penalty', 'Other Deductions', 'Net Amount']);
  return (
    <>
      <div className="card no-print">
        <h3>Filters</h3>
        <div className="row">
          <Filter label="Financial Year"><FYSelect value={f.fy} onChange={v => setF({ ...f, fy: v })} options={FYS} /></Filter>
          <Filter label="Status"><select value={f.status} onChange={set('status')}><option value="">All</option>{['Received', 'Processed', 'Passed', 'Paid', 'Cancelled'].map(s => <option key={s}>{s}</option>)}</select></Filter>
          <Filter label="Campus"><select value={f.campus} onChange={set('campus')}><option value="">All Campuses</option>{campuses.map(c => <option key={c.CampusID} value={c.CampusID}>{c.CampusName}</option>)}</select></Filter>
          <Filter label="From Date"><input type="date" value={f.from} onChange={set('from')} /></Filter>
          <Filter label="To Date"><input type="date" value={f.to} onChange={set('to')} /></Filter>
        </div>
        <div className="row">
          <Filter label="Vendor contains"><input type="text" value={f.vendor} onChange={set('vendor')} /></Filter>
          <Filter label="Employee ID"><input type="text" value={f.employeeId} onChange={set('employeeId')} /></Filter>
          <Filter label="Amount contains"><input type="text" value={f.amount} onChange={set('amount')} /></Filter>
          <Filter label="Description contains"><input type="text" value={f.description} onChange={set('description')} /></Filter>
          <Filter label="IBAN contains"><input type="text" value={f.iban} onChange={set('iban')} /></Filter>
        </div>
        <button className="primary" onClick={load}>Load Report</button> <ExportButtons tables={[{ ref, file: 'Bill_Status_Report.csv' }]} />
      </div>
      <div className="card no-print"><div className="row"><Filter label="Search (loaded results)"><input type="text" value={q} onChange={e => setQ(e.target.value)} placeholder="Type to filter rows already loaded above" /></Filter></div></div>
      <div className="card table-wrap">
        <Caption text={cap} />
        <table ref={ref}>
          <thead><tr>{heads.map(h => <th key={h} className={numCols.has(h) ? 'num' : undefined}>{h}</th>)}</tr></thead>
          <tbody>
            {list === null && <EmptyRow cols={32} text="Set filters above and click Load Report." />}
            {list && shown.length === 0 && <EmptyRow cols={32} />}
            {shown.map(e => (
              <tr key={e.EntryID}><td>{e.EntryID}</td><td>{e.BillNo || ''}</td><td>{fmtDate(e.EntryDate)}</td><td>{e.FY}</td><td>{e.CampusName}</td><td>{e.HeadCode}</td><td>{e.HeadName}</td>
                <td>{e.PayeeType || 'Vendor'}</td><td>{e.EmployeeID || ''}</td><td>{e.VendorName}</td><td>{e.CNIC_NTN || ''}</td><td>{e.IBAN || ''}</td><td>{e.BillDescription || ''}</td><td>{e.BillNature || ''}</td><td>{e.IncomeTaxSection || '-'}</td>
                <td className="num">{num(e.Amount)}</td><td className="num">{num(e.IncomeTaxAmount)}</td><td className="num">{num(e.SalesTaxAmount)}</td><td className="num">{num(e.PSTAmount)}</td><td className="num">{num(e.SecurityAmount)}</td><td className="num">{num(e.PenaltyAmount)}</td><td className="num">{num(e.OtherDeductionAmount)}</td><td className="num">{num(netOf(e))}</td>
                <td>{e.EnteredBy || ''}</td><td><Status s={e.Status} /></td><td>{fmtDate(e.EntryDate)}</td><td>{e.ProcessedBy || ''}</td><td>{fmtDate(e.ProcessedDate)}</td><td>{e.PassedBy || ''}</td><td>{fmtDate(e.PassedDate)}</td><td>{e.PaidBy || ''}</td><td>{fmtDate(e.PaidDate)}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
