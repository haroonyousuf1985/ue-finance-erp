import React, { useRef, useState } from 'react';
import { gs } from '../api.js';
import { num, fmtDate, DEFAULT_FY, fyOptions } from '../util.js';
import { useToast, EmptyRow, BillLink } from '../ui.jsx';
import { TaxDeductionStatement } from './reports/ReportsRest.jsx';

/* Admin > Bill Management & Section 149 Tools: Cancelled-Bill Repair, Already-Paid Over/Under-Deductions, Tax Deduction Statement,
   Outstanding Credit Balances, Manual Income Inclusion Override, Redirect a Paid Bill. */
const FYS = fyOptions();
const note = { fontSize: 12.5, color: 'var(--text-muted)' };
const h4 = { margin: '14px 0 6px', color: 'var(--text-muted)', fontSize: 12, textTransform: 'uppercase', letterSpacing: '.05em' };
const isCnic = v => /^\d{5}-\d{7}-\d{1}$/.test(String(v || '').trim());
const isSplitId = id => /^E\d+-[A-Z]+$/.test(String(id || '').trim());
const netOf = e => (e.NetAmount === '' || e.NetAmount === undefined || e.NetAmount === null) ? Number(e.Amount || 0) : Number(e.NetAmount);
const ptLabel = t => t === 'Employee' ? 'UE Employee' : 'Non-UE Employee';
const Line = ({ l, children }) => <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}><span>{l}</span><b>{children}</b></div>;
const F = ({ label, children, end, max }) => <div className="field" style={{ ...(end ? { alignSelf: 'flex-end' } : {}), ...(max ? { maxWidth: max } : {}) }}>{label && <label>{label}</label>}{children}</div>;

/* ---------- Cancelled-bill repair ---------- */
function CancelRepair({ user, onOpenBill }) {
  const { toast, run } = useToast();
  const [res, setRes] = useState(null);
  async function preview() {
    const r = await run(() => gs('previewSection149CancellationImpact', user.username), 'Checking Section 149 impact...');
    if (r && r.success !== false) setRes(r);
  }
  async function apply() {
    if (!res || !res.changedCount) { toast('Run Preview first.', 'error'); return; }
    if (!window.confirm('Apply the correction to ' + res.changedCount + ' bill(s)? Their Income Tax and Net Amount will be updated to the corrected figures shown below.')) return;
    const r = await run(() => gs('applySection149CancellationImpact', user.username), 'Applying correction...');
    if (!r || r.success === false) return;
    toast('Corrected ' + r.applied + ' bill(s).', 'success');
    preview();
  }
  const fixes = res ? res.singleEntryFixes.filter(f => f.changed) : [];
  const over = fixes.reduce((s, f) => s + Math.max(0, f.oldTax - f.newTax), 0);
  const ue = fixes.filter(f => f.payeeType === 'Employee').length;
  return (
    <div className="card">
      <h3>Section 149: Cancelled-Bill Income Threshold Repair</h3>
      <p style={note}>A Cancelled UE/Non-UE Employee bill is now correctly excluded from that person's annual Section 149 threshold going forward - but any bill saved <b>before</b> that fix, while still not yet Paid, may have Income Tax calculated against an inflated threshold because a since-cancelled bill was still being counted. <b>Preview</b> shows exactly what would change without touching anything; <b>Apply Fix</b> then writes the corrected Income Tax/Net Amount to those bills. Only Received/Processed/Passed bills are ever touched - Paid bills are never rewritten. Covers single-entry bills AND bulk-uploaded UE Employee lines (addressed by their own "ParentID-LineNo" ID, e.g. E1042-3) - a Non-UE bulk line can't be safely auto-corrected and is listed separately below for manual review; use Manual Income Inclusion Override further down, or cancel and re-upload the bulk bill, to fix those.</p>
      <button className="secondary" id="btnPreview149" onClick={preview}>Preview</button>{' '}
      {res && res.changedCount > 0 && <button className="primary" id="btnApply149" onClick={apply}>Apply Fix</button>}
      <div id="s149RepairSummary" style={{ marginTop: 10, fontSize: 13, color: 'var(--text-muted)' }}>
        {res && (res.changedCount > 0
          ? <>Checked {res.singleEntryFixes.length} bill(s) - <b style={{ color: 'var(--amber)' }}>{res.changedCount} need correction</b> ({ue} UE Employee, {fixes.length - ue} Non-UE Employee).{over > 0 && <> Total Income Tax over-deducted across these bills: <b style={{ color: 'var(--accent)' }}>{num(over)}</b>.</>}{res.bulkFlagCount ? ' Plus ' + res.bulkFlagCount + ' bulk-uploaded line(s) below for manual review.' : ''}</>
          : <>Checked {res.singleEntryFixes.length} bill(s) - all already correct.{res.bulkFlagCount ? ' ' + res.bulkFlagCount + ' bulk-uploaded line(s) below are worth a manual glance.' : ''}</>)}
      </div>
      <div className="table-wrap" style={{ marginTop: 10 }}>
        <table id="s149FixTable"><thead><tr><th>Bill ID</th><th>Payee</th><th>FY</th><th className="num">Gross</th><th className="num">Old Income Tax</th><th className="num">Corrected Income Tax</th><th className="num">Difference</th><th className="num">Old Net</th><th className="num">Corrected Net</th></tr></thead>
          <tbody>{!res ? <EmptyRow cols={9} text="Click Preview to check." /> : fixes.length ? fixes.map(f => {
            const diff = f.newTax - f.oldTax;
            return <tr key={f.entryId}><td><BillLink id={f.entryId} onOpen={onOpenBill} /></td><td>{f.name} ({ptLabel(f.payeeType)}{f.isBulkLine ? ', bulk line' : ''})</td><td>{f.fy}</td><td className="num">{num(f.gross)}</td><td className="num">{num(f.oldTax)}</td>
              <td className="num">{num(f.newTax)}</td><td className="num" style={{ color: diff < 0 ? 'var(--accent)' : 'var(--danger)', fontWeight: 700 }}>{diff < 0 ? '-' : '+'}{num(Math.abs(diff))}</td><td className="num">{num(f.oldNet)}</td><td className="num" style={{ color: 'var(--accent)', fontWeight: 700 }}>{num(f.newNet)}</td></tr>;
          }) : <EmptyRow cols={9} text="No bills need correction." />}</tbody></table>
      </div>
      {res && res.bulkLineFlags && res.bulkLineFlags.length > 0 && (
        <div className="table-wrap" style={{ marginTop: 14 }}>
          <table><thead><tr><th colSpan={5} style={{ textAlign: 'left', fontWeight: 800 }}>Bulk lines needing manual review</th></tr><tr><th>Bulk Bill ID</th><th>Beneficiary</th><th>Payee Type</th><th>FY</th><th className="num">Current Income Tax</th></tr></thead>
            <tbody>{res.bulkLineFlags.map((f, i) => <tr key={i}><td><BillLink id={f.parentEntryId + '-' + f.lineNo} onOpen={onOpenBill} /></td><td>{f.name}</td><td>Non-UE Employee, bulk line</td><td>{f.fy}</td><td className="num">{num(f.currentTax)}</td></tr>)}</tbody></table>
        </div>)}
    </div>
  );
}

/* ---------- Already-paid credit/outstanding + balances ---------- */
function PaidCredit({ user, onOpenBill, onApplied }) {
  const { toast, run } = useToast();
  const [res, setRes] = useState(null);
  async function preview() {
    const r = await run(() => gs('previewSection149PaidOverDeduction', user.username), 'Checking Paid transactions...');
    if (r && r.success !== false) setRes(r);
  }
  async function apply() {
    if (!res || !res.affectedCount) { toast('Run Preview first.', 'error'); return; }
    if (!window.confirm('Apply this reconciliation for ' + res.affectedCount + " employee(s)? This does NOT change any Paid bill itself - it only sets up a credit/outstanding balance that adjusts those employees' NEXT Section 149 transaction(s).")) return;
    const r = await run(() => gs('applySection149PaidOverDeduction', user.username), 'Applying...');
    if (!r || r.success === false) return;
    toast('Adjusted for ' + r.creditsCreated + ' employee(s), from ' + r.applied + ' Paid transaction(s).', 'success');
    preview(); onApplied();
  }
  const affected = res ? res.employees.filter(g => g.netAdjustment !== 0) : [];
  const credit = affected.filter(g => g.netAdjustment > 0).reduce((s, g) => s + g.netAdjustment, 0);
  const outstanding = -affected.filter(g => g.netAdjustment < 0).reduce((s, g) => s + g.netAdjustment, 0);
  return (
    <div className="card">
      <h3>Section 149: Already-Paid Over/Under-Deductions (Credit / Outstanding)</h3>
      <p style={note}>For a bill that's already <b>Paid</b>, the money has moved - its own Income Tax figure is never rewritten. This is computed <b>cumulatively per employee</b>, not bill-by-bill: every not-yet-reconciled Paid Section 149 transaction of theirs is combined into one holistic total actually withheld vs one total that should have been withheld (given their full, correctly-excluding-cancelled-bills history) - the difference becomes either a <b>credit</b> (owed back to them, automatically knocked off their next Section 149 transaction) or, in the rare mirror-image case, an <b>outstanding</b> amount (still owed by them, automatically collected on their next transaction). No further action is needed after Apply here. Covers single-entry bills AND Paid bulk-uploaded UE Employee lines - a Non-UE bulk line still needs Manual Income Inclusion Override below.</p>
      <button className="secondary" id="btnPreview149Paid" onClick={preview}>Preview</button>{' '}
      {res && res.affectedCount > 0 && <button className="primary" id="btnApply149Paid" onClick={apply}>Apply</button>}
      <div id="s149PaidSummary" style={{ marginTop: 10, fontSize: 13, color: 'var(--text-muted)' }}>
        {res && (res.affectedCount > 0
          ? <>Checked {res.checkedTransactionCount} Paid transaction(s) across not-yet-reconciled employees - <b style={{ color: 'var(--amber)' }}>{res.affectedCount} employee(s) need adjustment</b>.{credit > 0 && <> Total credit to be created: <b style={{ color: 'var(--accent)' }}>{num(credit)}</b>.</>}{outstanding > 0 && <> Total outstanding to be recorded: <b style={{ color: 'var(--danger)' }}>{num(outstanding)}</b>.</>}</>
          : <>Checked {res.checkedTransactionCount} Paid transaction(s) - every employee already reconciles correctly.</>)}
      </div>
      {res && !affected.length && <p style={{ ...note, fontSize: 13 }}>No employee shows a credit or outstanding right now.</p>}
      {affected.map((g, i) => {
        const isCredit = g.netAdjustment > 0;
        return (
          <div key={i} style={{ border: '1px solid var(--border)', borderRadius: 8, padding: 12, margin: '10px 0' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
              <div><b>{g.name}</b> ({ptLabel(g.payeeType)}) - FY {g.fy}</div>
              <div>{isCredit ? 'Credit owed to employee' : 'Outstanding owed by employee'}: <b style={{ color: isCredit ? 'var(--accent)' : 'var(--danger)', fontSize: 15 }}>{num(Math.abs(g.netAdjustment))}</b></div>
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)', margin: '6px 0' }}>Total actually withheld {num(g.totalActualTax)} vs total that should have been withheld {num(g.totalCorrectTax)}, across {g.transactions.length} Paid transaction(s):</div>
            <div className="table-wrap"><table><thead><tr><th>Bill ID</th><th>Date</th><th>Nature</th><th>Gross</th><th>Actually Withheld</th><th>Should Have Been</th></tr></thead>
              <tbody>{g.transactions.map((t, j) => <tr key={j}><td><BillLink id={t.id} onOpen={onOpenBill} /></td><td>{fmtDate(t.date)}</td><td>{t.billNature}</td><td>{num(t.gross)}</td><td>{num(t.actualTax)}</td><td>{num(t.correctTax)}</td></tr>)}</tbody></table></div>
          </div>);
      })}
    </div>
  );
}

function Balances({ user, reloadKey }) {
  const { run } = useToast();
  const [rows, setRows] = useState(null);
  const [seen, setSeen] = useState(reloadKey);
  const load = async () => { const r = await run(() => gs('listSection149CreditBalances', user.username), 'Loading balances...'); if (Array.isArray(r)) setRows(r); };
  if (seen !== reloadKey) { setSeen(reloadKey); if (rows) load(); }
  return (
    <div className="card">
      <h3>Section 149: Outstanding Credit Balances</h3>
      <p style={note}>Every employee currently owed money via reduced future Income Tax withholding - doesn't load automatically, click Load.</p>
      <button className="secondary" id="btnLoadS149Credits" onClick={load}>Load</button>
      <div className="table-wrap" style={{ marginTop: 10 }}>
        <table id="s149CreditsTable"><thead><tr><th>Employee/CNIC</th><th>Payee Type</th><th>FY</th><th className="num">Balance</th><th>Last Updated</th></tr></thead>
          <tbody>{rows === null ? <EmptyRow cols={5} text="Click Load to view." /> : rows.length ? rows.map((r, i) => {
            const c = r.creditAmount > 0;
            return <tr key={i}><td>{r.key}</td><td>{ptLabel(r.payeeType)}</td><td>{r.fy}</td><td style={{ fontWeight: 700, color: c ? 'var(--accent)' : 'var(--danger)' }}>{num(Math.abs(r.creditAmount))} {c ? '(Credit)' : '(Outstanding)'}</td><td>{fmtDate(r.lastUpdated)}</td></tr>;
          }) : <EmptyRow cols={5} text="No outstanding credit or dues right now." />}</tbody></table>
      </div>
    </div>
  );
}

/* ---------- Manual income inclusion override ---------- */
function ManualOverride({ user, onOpenBill }) {
  const { run } = useToast();
  const { toast } = useToast();
  const [payeeType, setPayeeType] = useState('Employee');
  const [key, setKey] = useState('');
  const [fy, setFy] = useState(DEFAULT_FY);
  const [items, setItems] = useState(null);
  async function load() {
    if (!key.trim()) { toast('Enter the ' + (payeeType === 'Employee' ? 'Employee ID' : 'CNIC') + ' first.', 'error'); return; }
    const r = await run(() => gs('getSection149IncomeItems', key.trim(), payeeType, fy, user.username), 'Loading...');
    if (Array.isArray(r)) setItems(r);
  }
  async function toggle(it, include) {
    let reason = '';
    if (!include) reason = window.prompt("Reason for excluding " + it.itemId + " from this person's Section 149 threshold (kept on record):") || '';
    setItems(list => list.map(x => x.itemId === it.itemId ? { ...x, manuallyExcluded: !include } : x));
    const r = await run(() => gs('setSection149ManualExclusion', key.trim(), payeeType, fy, it.itemId, !include, reason, user.username), 'Saving...', include ? 'Item re-included.' : 'Item excluded.');
    if (!r || r.success === false) load();
  }
  return (
    <div className="card">
      <h3>Section 149: Manual Income Inclusion Override</h3>
      <p style={note}>Full manual control over which bills/lines count toward a specific person's Section 149 annual income for a given FY - the direct fallback for anything the tools above can't safely judge on their own, chiefly a bulk Non-UE Employee line. Every taxable bill and bulk line for that person in that FY is listed, across every status, including ones already excluded automatically (Cancelled, Redirected - shown greyed out with the reason, since a manual override on top of those has no effect). Untick "Included" on any item to manually exclude it from that person's threshold calculation from now on - re-tick to bring it back in. This does not rewrite any bill's own Income Tax figure; it only changes what future bills for this person are calculated against.</p>
      <div className="row">
        <F label="Payee Type" max={200}><select id="mio_payeeType" value={payeeType} onChange={e => { setPayeeType(e.target.value); setItems(null); }}><option value="Employee">UE Employee</option><option value="NonUEEmployee">Non-UE Employee</option></select></F>
        <F label={payeeType === 'Employee' ? 'Employee ID' : 'CNIC'}><input type="text" id="mio_key" value={key} onChange={e => setKey(e.target.value)} /></F>
        <F label="Financial Year" max={200}><select id="mio_fy" value={fy} onChange={e => setFy(e.target.value)}>{FYS.map(y => <option key={y}>{y}</option>)}</select></F>
        <F end><button className="secondary" id="btnMioLoad" onClick={load}>Load</button></F>
      </div>
      <div className="table-wrap" style={{ marginTop: 10 }}>
        <table id="mioTable"><thead><tr><th>Bill/Line ID</th><th>Date</th><th>Nature</th><th className="num">Amount</th><th className="num">Income Tax</th><th>Status</th><th>Included in Threshold?</th></tr></thead>
          <tbody>{items === null ? <EmptyRow cols={7} text="Set Payee Type/ID/FY above and click Load." /> : items.length ? items.map(it => {
            const included = !it.autoExcluded && !it.manuallyExcluded;
            return <tr key={it.itemId} style={it.autoExcluded ? { opacity: 0.55 } : undefined}>
              <td><BillLink id={it.billId} onOpen={onOpenBill} /></td><td>{fmtDate(it.date)}</td><td>{it.billNature}</td><td className="num">{num(it.amount)}</td><td className="num">{num(it.incomeTaxAmount)}</td>
              <td>{it.autoExcluded ? it.status + ' - ' + it.autoExcludedReason : it.status}</td>
              <td><label style={{ display: 'flex', alignItems: 'center', gap: 6, fontWeight: 'normal' }}><input type="checkbox" style={{ width: 'auto' }} checked={included} disabled={!!it.autoExcluded} onChange={e => toggle(it, e.target.checked)} /> Included</label></td></tr>;
          }) : <EmptyRow cols={7} text="No taxable Section 149 bills/lines found for this person in this FY." />}</tbody></table>
      </div>
    </div>
  );
}

/* ---------- Redirect a paid bill ---------- */
function Redirect({ user, onChanged }) {
  const { toast, run } = useToast();
  const [billId, setBillId] = useState('');
  const [orig, setOrig] = useState(null);       // {id, isBulkLine, error, rows:[[label,value]], note}
  const [pt, setPt] = useState('Employee');
  const [ben, setBen] = useState({ employeeId: '', cnic: '', name: '', iban: '', bankName: '', nonUeTaxMethod: 'Section149', fbrStatus: 'Filer', affidavitLowIncome: false });
  const [empName, setEmpName] = useState('');
  const [prev, setPrev] = useState(null);
  const timer = useRef(null);
  const up = (k, v) => { setBen(b => ({ ...b, [k]: v })); setPrev(null); };
  const onEmp = v => {
    up('employeeId', v); setEmpName(''); clearTimeout(timer.current);
    if (v.trim()) timer.current = setTimeout(() => gs('getEmployeeById', v.trim()).then(e => { if (e) setEmpName(e.Name || ''); }).catch(() => {}), 250);
  };
  async function loadBill() {
    const id = billId.trim();
    if (!id) { toast('Enter a Bill ID first.', 'error'); return; }
    setPrev(null);
    const res = await gs('getBillDetail', id);
    if (!res || res.success === false) { toast((res && res.message) || 'Bill not found.', 'error'); return; }
    const e = res.bill;
    const bulkLine = id.includes('-') && !isSplitId(id);
    let src = e, line = null;
    if (bulkLine) {
      const lineNo = id.split('-').slice(1).join('-');
      line = (res.bulkItems || []).find(li => String(li.LineNo) === String(lineNo));
      if (!line) { toast('Beneficiary line ' + lineNo + ' was not found in bulk bill ' + id.split('-')[0] + '.', 'error'); return; }
      src = line;
    }
    const bad = m => setOrig({ id, error: m });
    if (e.Status !== 'Paid') return bad('This ' + (bulkLine ? 'bulk bill' : 'bill') + ' is at "' + e.Status + '", not Paid - this tool is only for bills already Paid. Use Edit or Cancel instead for anything still in the pipeline.');
    if (bulkLine) {
      if (line.PayeeType !== 'Employee') return bad("This tool only supports UE Employee lines within a bulk bill - a bulk Non-UE Employee line doesn't retain enough information to safely redirect automatically. Correct it manually instead.");
      if (line.RedirectedToEntryID || line.SplitToEntryID) return bad('This beneficiary line has already been ' + (line.SplitToEntryID ? 'isolated into its own bill ' + line.SplitToEntryID : 'redirected, to Bill ' + line.RedirectedToEntryID) + '.');
    } else {
      if ((e.PayeeType !== 'Employee' && e.PayeeType !== 'NonUEEmployee') || !e.EmployeeCategory || String(e.IncomeTaxSection || '').indexOf('149') !== 0)
        return bad('This bill isn\'t a Section 149 UE/Non-UE Employee bill - this tool doesn\'t apply here. (For a bulk bill, enter the specific beneficiary\'s own ID, e.g. "' + id + '-1".)');
      if (e.RedirectedToEntryID) return bad('This bill has already been redirected, to Bill ' + e.RedirectedToEntryID + '.');
    }
    setOrig({
      id, isBulkLine: bulkLine,
      note: bulkLine ? 'Beneficiary ' + id + ' inside bulk bill ' + id.split('-')[0] + ' - only this line will be affected, every other beneficiary in the same bulk bill is untouched.' : '',
      rows: [['Currently paid to (wrong beneficiary)', src.VendorName + ' (' + ptLabel(bulkLine ? 'Employee' : e.PayeeType) + ')'], ['FY', e.FY], ['Nature of Bill', src.BillNature], ['Gross Amount', num(src.Amount)],
        ["Income Tax Withheld (under wrong beneficiary's name)", num(src.IncomeTaxAmount)], ['Net Amount Paid', num(netOf(src))]]
    });
  }
  function beneficiary() {
    return pt === 'Employee' ? { payeeType: 'Employee', employeeId: ben.employeeId.trim() }
      : { payeeType: 'NonUEEmployee', cnic: ben.cnic.trim(), name: ben.name.trim(), iban: ben.iban.trim(), bankName: ben.bankName.trim(), nonUeTaxMethod: ben.nonUeTaxMethod, fbrStatus: ben.fbrStatus, affidavitLowIncome: ben.affidavitLowIncome };
  }
  async function preview() {
    const b = beneficiary();
    if (b.payeeType === 'Employee' && !b.employeeId) { toast("Enter the correct beneficiary's Employee ID.", 'error'); return; }
    if (b.payeeType === 'NonUEEmployee' && (!b.cnic || !b.name)) { toast("Enter the correct beneficiary's CNIC and Name.", 'error'); return; }
    if (b.payeeType === 'NonUEEmployee' && !isCnic(b.cnic)) { toast('CNIC must be in the format 35201-1222334-4.', 'error'); return; }
    const r = await run(() => gs('previewBillRedirect', orig.id, b, user.username), 'Calculating...');
    if (r && r.success !== false) setPrev(r);
  }
  async function apply() {
    if (!window.confirm('Redirect this payment? ' + (orig.isBulkLine ? 'Beneficiary line ' + orig.id + ' will be excluded (the rest of that bulk bill is untouched)' : 'Bill ' + orig.id + ' will be cancelled') + ", their own prior credit (if any) will be returned to them, the actual withheld tax will be tracked as an FBR Tax Adjustment (not credited to them), and a new Received bill will be created for the correct beneficiary. This cannot be undone from here.")) return;
    const r = await run(() => gs('applyBillRedirect', orig.id, beneficiary(), user.username), 'Redirecting payment...');
    if (!r || r.success === false) return;
    toast('Redirected - new Bill ' + r.newEntryId + ' created for ' + r.correctBeneficiary + '. It now waits in Processing.', 'success');
    setBillId(''); setOrig(null); setPrev(null); onChanged();
  }
  const is1531b = ben.nonUeTaxMethod === 'Section153_1b';
  return (
    <div className="card">
      <h3>Section 149: Redirect a Paid Bill to the Correct Beneficiary</h3>
      <p style={note}>Use this when a Section 149 UE/Non-UE Employee bill was <b>Paid to the wrong person by mistake</b> - either a normal single-entry bill, or one beneficiary inside a bulk-uploaded bill (enter that beneficiary's own ID, e.g. <b>E1042-2</b> for the 2nd line of bulk bill E1042 - only that one beneficiary is affected, every other beneficiary in the same bulk bill is left completely untouched). A bulk Non-UE Employee line isn't supported here (it doesn't retain enough information to redirect safely) - correct one of those manually instead. This does four things together: (1) excludes the original payment, so it's out of every calculation from now on - including the wrong beneficiary's own annual income for future bills; (2) credits the wrong beneficiary with the Income Tax already withheld/deposited under their name on that bill, so it's drawn down automatically on their next real bill; (3) creates a brand-new bill for the correct beneficiary, same Gross Amount, with Income Tax freshly calculated against <b>their own</b> annual threshold - it then goes through Processing/Passing/Payment normally, since the actual transfer to them hasn't happened yet; (4) links both records so either one's Bill Audit View shows the other. This does <b>not</b> reverse the money already sent to the wrong beneficiary's bank account - that recovery, if any, happens outside this system.</p>
      <div className="row">
        <F label="Original (Wrongly-Paid) Bill ID"><input type="text" id="rd_billid" placeholder="e.g. E1042, or E1042-1 / E1042-2 for one beneficiary inside a bulk bill" value={billId} onChange={e => setBillId(e.target.value)} /></F>
        <F end><button className="secondary" id="btnLoadRedirect" onClick={loadBill}>Load Bill</button></F>
      </div>
      {orig && (
        <div id="rd_originalInfo" style={{ margin: '10px 0', padding: 12, border: '1px solid var(--border)', borderRadius: 8, fontSize: 13 }}>
          {orig.error ? <span style={{ color: 'var(--danger)' }}>{orig.error}</span> : <>
            {orig.note && <div style={{ fontSize: 11.5, color: 'var(--amber)', marginBottom: 6 }}>{orig.note}</div>}
            {orig.rows.map(([l, v]) => <Line key={l} l={l}>{v}</Line>)}</>}
        </div>)}
      {orig && !orig.error && (
        <div id="rd_correctSection">
          <h4 style={h4}>Correct Beneficiary</h4>
          <div className="row" style={{ alignItems: 'center' }}>
            {[['Employee', 'UE Employee'], ['NonUEEmployee', 'Non-UE Employee']].map(([v, l]) => (
              <label key={v} style={{ display: 'flex', alignItems: 'center', gap: 6, fontWeight: 'normal' }}><input type="radio" name="rdPayeeType" value={v} style={{ width: 'auto' }} checked={pt === v} onChange={() => { setPt(v); setPrev(null); }} /> {l}</label>))}
          </div>
          {pt === 'Employee' ? (
            <div className="row">
              <F label="Employee ID"><input type="text" id="rd_employeeid" value={ben.employeeId} onChange={e => onEmp(e.target.value)} /></F>
              <F label="Name (auto)"><input type="text" id="rd_empname" readOnly value={empName} /></F>
            </div>
          ) : (<>
            <div className="row">
              <F label="CNIC"><input type="text" id="rd_cnic" placeholder="35201-1222334-4" maxLength={15} value={ben.cnic} onChange={e => up('cnic', e.target.value)} /></F>
              <F label="Name"><input type="text" id="rd_name" value={ben.name} onChange={e => up('name', e.target.value)} /></F>
              <F label="IBAN"><input type="text" id="rd_iban" value={ben.iban} onChange={e => up('iban', e.target.value)} /></F>
              <F label="Bank Name"><input type="text" id="rd_bank" value={ben.bankName} onChange={e => up('bankName', e.target.value)} /></F>
            </div>
            <div className="row" style={{ alignItems: 'center' }}>
              <F label="Tax Method"><select id="rd_nonueTaxMethod" value={ben.nonUeTaxMethod} onChange={e => setBen(b => ({ ...b, nonUeTaxMethod: e.target.value, affidavitLowIncome: false }))}>
                <option value="Section149">Section 149 (Slab, per Income Profile / Affidavit)</option><option value="Section153_1b">Section 153(1)(b) - Services (Individual/AOP) - flat rate</option></select></F>
              {!is1531b && <F><label style={{ display: 'flex', alignItems: 'center', gap: 6, fontWeight: 'normal', marginTop: 26 }}><input type="checkbox" id="rd_affidavit" style={{ width: 'auto' }} checked={ben.affidavitLowIncome} onChange={e => up('affidavitLowIncome', e.target.checked)} /> Affidavit of Low Income (Section 149 only - zero tax)</label></F>}
              {is1531b && <F label="Taxpayer Status"><select id="rd_taxpayerStatus" value={ben.fbrStatus} onChange={e => up('fbrStatus', e.target.value)}><option value="Filer">Active / Registered</option><option value="NonFiler">Inactive</option></select></F>}
            </div>
          </>)}
          <button className="secondary" id="btnPreviewRedirect" onClick={preview}>Preview Redirect</button>
          {prev && (<>
            <div id="rd_previewResult" style={{ marginTop: 10, padding: 12, border: '1px solid var(--accent)', borderRadius: 8, fontSize: 13 }}>
              <div style={{ fontWeight: 700, color: 'var(--accent)', marginBottom: 6 }}>If confirmed:</div>
              <Line l={'Bill ' + prev.original.entryId + ' (' + prev.original.name + ')'}>Cancelled</Line>
              <Line l={prev.original.name + "'s own prior credit, returned to them"}>{num(prev.creditToWrongBeneficiary)}</Line>
              <Line l={'Income Tax withheld under ' + prev.original.name + "'s name (NOT credited to them - tracked as an FBR Tax Adjustment for Payment/IBFT to reconcile)"}><span style={{ color: 'var(--amber)' }}>{num(prev.fbrAdjustmentAmount)}</span></Line>
              <div style={{ borderTop: '1px solid var(--border)', margin: '8px 0' }} />
              <Line l={'New bill for ' + prev.correct.name}>Gross {num(prev.original.gross)}</Line>
              <Line l={'Income Tax (' + (prev.newIncomeTaxSection || 'Section 149') + ', at ' + prev.correct.name + "'s own threshold)"}>{num(prev.newIncomeTax)}</Line>
              <Line l={'Net Amount to be paid to ' + prev.correct.name}><span style={{ color: 'var(--accent)' }}>{num(prev.newNet)}</span></Line>
            </div>
            <button className="primary" id="btnApplyRedirect" style={{ marginTop: 10 }} onClick={apply}>Confirm - Redirect Payment</button>
          </>)}
        </div>)}
    </div>
  );
}

export default function AdminTools({ user, onOpenBill, onChanged }) {
  const [balKey, setBalKey] = useState(0);
  return (
    <>
      <CancelRepair user={user} onOpenBill={onOpenBill} />
      <PaidCredit user={user} onOpenBill={onOpenBill} onApplied={() => setBalKey(k => k + 1)} />
      <TaxDeductionStatement user={user} onOpenBill={onOpenBill} />
      <Balances user={user} reloadKey={balKey} />
      <ManualOverride user={user} onOpenBill={onOpenBill} />
      <Redirect user={user} onChanged={onChanged} />
    </>
  );
}
