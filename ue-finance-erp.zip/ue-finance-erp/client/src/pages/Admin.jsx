import React, { useCallback, useEffect, useState } from 'react';
import { gs } from '../api.js';
import { DEFAULT_FY, fyOptions, num } from '../util.js';
import { useToast, EmptyRow, FYSelect, BillLink } from '../ui.jsx';
import { fmtDate } from '../util.js';
import AdminTools from './AdminTools.jsx';

/* Admin: the "Setup & Records" sections are real React forms. Manage Entries and the Section 149 tools / Redirect a Paid Bill (second button) are real React forms too. */
const FYS = fyOptions();
const note = { fontSize: 12.5, color: 'var(--text-muted)' };
const small = { fontSize: 11.5, color: 'var(--text-muted)', marginTop: -6 };
const h4 = { margin: '14px 0 6px', color: 'var(--text-muted)', fontSize: 12, textTransform: 'uppercase', letterSpacing: '.05em' };
const isCnic = v => /^\d{5}-\d{7}-\d{1}$/.test(String(v || '').trim());
const isIban = v => /^PK\d{2}[A-Z0-9]{20}$/.test(String(v || '').trim().toUpperCase());
const F = ({ label, children, end, max }) => <div className="field" style={{ ...(end ? { alignSelf: 'flex-end' } : {}), ...(max ? { maxWidth: max } : {}) }}>{label && <label>{label}</label>}{children}</div>;
const Txt = ({ v, set, ...p }) => <input type="text" value={v} onChange={e => set(e.target.value)} {...p} />;

/* ---------- Budget code + allocation ---------- */
function Allocations({ user, campuses, reloadCampuses }) {
  const { toast, run } = useToast();
  const [a, setA] = useState({ campusId: '', newCampusName: '', headCode: '', headName: '', fy: DEFAULT_FY, amount: '' });
  const [q, setQ] = useState({ campusId: '', fy: '', headQuery: '' });
  const [rows, setRows] = useState(null);
  async function save() {
    if ((!a.campusId && !a.newCampusName.trim()) || !a.headCode.trim() || !a.amount) { toast('Provide a campus, a budget code, and an amount.', 'error'); return; }
    const res = await run(() => gs('saveAllocation', user.username, { ...a, newCampusName: a.newCampusName.trim(), headCode: a.headCode.trim(), headName: a.headName.trim() }), 'Saving allocation...', 'Allocation saved.');
    if (res && res.success) { setA({ ...a, newCampusName: '' }); reloadCampuses(); if (rows) load(); }
  }
  async function load() {
    const res = await run(() => gs('searchAllocations', q), 'Loading...', 'Loaded.');
    if (Array.isArray(res)) setRows(res);
  }
  async function remove(r) {
    if (!window.confirm('Delete this allocation? This cannot be undone.')) return;
    const res = await run(() => gs('deleteAllocation', user.username, r.CampusID, r.HeadID, r.FY), 'Deleting...', 'Allocation deleted.');
    if (res && res.success) load();
  }
  const edit = r => { setA({ campusId: r.CampusID, newCampusName: '', headCode: r.HeadCode, headName: r.HeadName, fy: r.FY, amount: r.AllocatedAmount }); toast('Loaded into the form above - change the amount and click Save to update.', 'success'); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const codeBlur = () => { const c = a.headCode.trim(); if (c) gs('getHeadByCode', c).then(h => { if (h) setA(x => ({ ...x, headName: h.HeadName })); }).catch(() => {}); };
  return (
    <div className="card">
      <h3>Add / Assign Budget Code to Campus (with allocation)</h3>
      <p style={note}>Pick existing campus/code, or type new ones - creating and allocating happens in one Save.</p>
      <div className="row">
        <F label="Existing Campus"><select value={a.campusId} onChange={e => setA({ ...a, campusId: e.target.value })}><option value="">-- select --</option>{campuses.map(c => <option key={c.CampusID} value={c.CampusID}>{c.CampusName}</option>)}</select></F>
        <F label="...or New Campus Name"><Txt v={a.newCampusName} set={v => setA({ ...a, newCampusName: v })} placeholder="Leave blank if selecting above" /></F>
      </div>
      <div className="row">
        <F label="Budget Code"><input type="text" value={a.headCode} onChange={e => setA({ ...a, headCode: e.target.value })} onBlur={codeBlur} placeholder="e.g. B-101" /></F>
        <F label="Budget Head Name"><Txt v={a.headName} set={v => setA({ ...a, headName: v })} placeholder="Auto-fills if code exists" /></F>
        <F label="Financial Year"><select value={a.fy} onChange={e => setA({ ...a, fy: e.target.value })}>{FYS.map(y => <option key={y}>{y}</option>)}</select></F>
        <F label="Allocated Amount"><input type="number" value={a.amount} onChange={e => setA({ ...a, amount: e.target.value })} /></F>
      </div>
      <button className="primary" onClick={save}>Save</button>

      <h3 style={{ marginTop: 18, fontSize: 13 }}>Search Allocations</h3>
      <p style={note}>Doesn't load everything by default - pick filters and click Load.</p>
      <div className="row">
        <F label="Campus"><select value={q.campusId} onChange={e => setQ({ ...q, campusId: e.target.value })}><option value="">All Campuses</option>{campuses.map(c => <option key={c.CampusID} value={c.CampusID}>{c.CampusName}</option>)}</select></F>
        <F label="Financial Year"><FYSelect value={q.fy} onChange={v => setQ({ ...q, fy: v })} options={FYS} /></F>
        <F label="Budget Code/Name contains"><Txt v={q.headQuery} set={v => setQ({ ...q, headQuery: v })} /></F>
        <F end><button className="primary" onClick={load}>Load</button></F>
      </div>
      <div className="table-wrap" style={{ marginTop: 10 }}><table>
        <thead><tr><th>Campus</th><th>Code</th><th>Head</th><th>FY</th><th className="num">Allocated</th><th></th></tr></thead>
        <tbody>
          {rows === null && <EmptyRow cols={6} text="Set filters above and click Load." />}
          {rows && rows.length === 0 && <EmptyRow cols={6} text="Nothing found." />}
          {(rows || []).map((r, i) => <tr key={i}><td>{r.CampusName}</td><td>{r.HeadCode}</td><td>{r.HeadName}</td><td>{r.FY}</td><td className="num">{num(r.AllocatedAmount)}</td>
            <td><button className="secondary" onClick={() => edit(r)}>Edit</button> <button className="secondary" onClick={() => remove(r)}>Delete</button></td></tr>)}
        </tbody></table></div>
    </div>
  );
}

/* ---------- Budget heads ---------- */
function Heads({ user }) {
  const { run } = useToast();
  const [query, setQuery] = useState('');
  const [rows, setRows] = useState(null);
  async function load() { const r = await run(() => gs('searchBudgetHeads', query), 'Loading...', 'Loaded.'); if (Array.isArray(r)) setRows(r); }
  async function edit(h) {
    const code = window.prompt('Budget Code:', h.HeadCode); if (code === null) return;
    const name = window.prompt('Budget Head Name:', h.HeadName); if (name === null) return;
    const r = await run(() => gs('updateBudgetHead', user.username, h.HeadID, code, name), 'Updating...', 'Budget head updated.'); if (r && r.success) load();
  }
  async function off(h) {
    if (!window.confirm('Deactivate this budget head? It will stop appearing in new allocations/bills, but existing records keep working.')) return;
    const r = await run(() => gs('deleteBudgetHead', user.username, h.HeadID), 'Deactivating...', 'Budget head deactivated.'); if (r && r.success) load();
  }
  return (
    <div className="card">
      <h3>Budget Heads</h3>
      <p style={note}>Edit a head's code/name, or deactivate one so it stops appearing in new allocations/bills (existing records referencing it keep working).</p>
      <div className="row"><F label="Search Budget Heads"><Txt v={query} set={setQuery} placeholder="Code or name" /></F><F end><button className="primary" onClick={load}>Load</button></F></div>
      <div className="table-wrap" style={{ marginTop: 10 }}><table>
        <thead><tr><th>Code</th><th>Name</th><th></th></tr></thead>
        <tbody>
          {rows === null && <EmptyRow cols={3} text="Click Load to search." />}
          {rows && rows.length === 0 && <EmptyRow cols={3} text="Nothing found." />}
          {(rows || []).map(h => <tr key={h.HeadID}><td>{h.HeadCode}</td><td>{h.HeadName}{(h.Active === false || h.Active === 'FALSE') ? ' (inactive)' : ''}</td>
            <td><button className="secondary" onClick={() => edit(h)}>Edit</button> <button className="secondary" onClick={() => off(h)}>Deactivate</button></td></tr>)}
        </tbody></table></div>
    </div>
  );
}

/* ---------- Users ---------- */
const ROLES = [['Accounts', 'Accounts (Entry + Paid Bills + Reports)'], ['RA', 'RA (Passing + Reports)'], ['IBFT', 'IBFT User (Payment/IBFT + Paid Bills + Reports)'], ['ReportsOnly', 'Reports Only'],
  ['DiaryClerk', 'Diary Clerk (Diary + Diary Report only)'], ['AllExceptAdmin', 'All Except Admin (every tab except Admin)'], ['Admin', 'Admin (full access)']];
function Users({ user }) {
  const { toast, run } = useToast();
  const [u, setU] = useState({ username: '', password: '', fullName: '', role: 'Accounts' });
  const [list, setList] = useState([]);
  const load = useCallback(() => gs('getUsers', user.username).then(setList).catch(() => {}), [user.username]);
  useEffect(() => { load(); }, [load]);
  async function add() {
    if (!u.username.trim() || !u.password || !u.fullName.trim()) { toast('Fill all fields.', 'error'); return; }
    const r = await run(() => gs('addUser', user.username, u.username.trim(), u.password, u.fullName.trim(), u.role), 'Adding user...', 'User added.');
    if (r && r.success) { setU({ username: '', password: '', fullName: '', role: 'Accounts' }); load(); }
  }
  return (
    <div className="card">
      <h3>Add User</h3>
      <p style={note}><b>Admin</b>: every tab. <b>All Except Admin</b>: every tab except the Admin tab. <b>Accounts</b>: New Entry + Reports. <b>RA</b>: Passing + Reports only. <b>IBFT User</b>: Payment/IBFT + Confirmation + Reconciliation + Reports only. <b>Reports Only</b>: Reports only. <b>Diary Clerk</b>: Diary tab + Diary Report only - logs a bill/letter's physical arrival and assigns it by name. <b>Every role</b> has the Diary tab.</p>
      <div className="row">
        <F label="Username"><Txt v={u.username} set={v => setU({ ...u, username: v })} /></F>
        <F label="Password"><input type="password" value={u.password} onChange={e => setU({ ...u, password: e.target.value })} autoComplete="new-password" /></F>
        <F label="Full Name"><Txt v={u.fullName} set={v => setU({ ...u, fullName: v })} /></F>
        <F label="Role"><select value={u.role} onChange={e => setU({ ...u, role: e.target.value })}>{ROLES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></F>
      </div>
      <button className="primary" onClick={add}>Add User</button>
      <div className="table-wrap" style={{ marginTop: 14 }}><table>
        <thead><tr><th>Username</th><th>Full Name</th><th>Role</th></tr></thead>
        <tbody>{list.length === 0 && <EmptyRow cols={3} text="No users." />}{list.map(x => <tr key={x.Username}><td>{x.Username}</td><td>{x.FullName}</td><td>{x.Role}</td></tr>)}</tbody></table></div>
    </div>
  );
}

/* ---------- Tax settings + Section 149 slabs ---------- */
const pct = v => (Number(v || 0) * 100).toFixed(2);
const TS_FIELDS = [
  ['salesTaxActiveRate', 'Active / Filer Rate (%)', 'h:General Sales Tax (Goods, Section 153)'], ['salesTaxInactiveRate', 'Inactive / Non-Filer Rate (%)'],
  ['pstActiveRate', 'Active / Registered Taxpayer Rate (%)', 'h:Punjab Sales Tax (Services)'], ['pstActiveMode', 'Calculation - Active', 'mode'], ['pstInactiveRate', 'Inactive Taxpayer Rate (%)'], ['pstInactiveMode', 'Calculation - Inactive', 'mode'],
  ['pstContractNewProjectsRate', 'New Projects Rate (%)', 'h:Punjab Sales Tax - Execution of Contract'], ['pstContractNewProjectsMode', 'Calculation - New Projects', 'mode'],
  ['pstContractRepairRate', 'Repair / Renovation Rate (%)'], ['pstContractRepairMode', 'Calculation - Repair/Renovation', 'mode'],
  ['section156Rate', "Section 156 Rate - Honoraria to Statutory Body Meeting's Member (%)", 'h:Income Tax'], ['nonUe1531bActiveRate', 'Section 153(1)(b) - Non-UE, Active/Registered (%)'], ['nonUe1531bInactiveRate', 'Section 153(1)(b) - Non-UE, Inactive (%)']
];
function TaxSettings({ user }) {
  const { run } = useToast();
  const [ts, setTs] = useState(null);
  const [slabs, setSlabs] = useState([]);
  const [s, setS] = useState({ threshold: '', fixedAmount: '', rate: '', label: '' });
  const loadSlabs = useCallback(() => gs('getTaxSlabs').then(setSlabs).catch(() => {}), []);
  useEffect(() => {
    gs('getTaxSettings').then(t => { const o = {}; TS_FIELDS.forEach(([k, , kind]) => { o[k] = kind === 'mode' ? t[k] : pct(t[k]); }); setTs(o); }).catch(() => {});
    loadSlabs();
  }, [loadSlabs]);
  async function save() {
    const o = {}; TS_FIELDS.forEach(([k, , kind]) => { o[k] = kind === 'mode' ? ts[k] : (Number(ts[k]) || 0) / 100; });
    await run(() => gs('saveTaxSettings', user.username, o), 'Saving...', 'Tax settings saved.');
  }
  async function saveSlab() {
    const r = await run(() => gs('saveTaxSlab', user.username, { threshold: s.threshold, fixedAmount: s.fixedAmount, rate: (Number(s.rate) || 0) / 100, label: s.label }), 'Saving...', 'Slab saved.');
    if (r && r.success) { setS({ threshold: '', fixedAmount: '', rate: '', label: '' }); loadSlabs(); }
  }
  async function delSlab(t) {
    if (!window.confirm('Delete this slab row?')) return;
    const r = await run(() => gs('deleteTaxSlab', user.username, t), 'Deleting...', 'Slab deleted.'); if (r && r.success) loadSlabs();
  }
  if (!ts) return <div className="card"><h3>Tax Settings</h3><p>Loading...</p></div>;
  const field = ([k, label, kind]) => (
    <F key={k} label={label}>
      {kind === 'mode'
        ? <select value={ts[k]} onChange={e => setTs({ ...ts, [k]: e.target.value })}><option value="exclusive">Exclusive</option><option value="inclusive">Inclusive</option></select>
        : <input type="number" step="0.01" value={ts[k]} onChange={e => setTs({ ...ts, [k]: e.target.value })} />}
    </F>);
  // group the fields by their heading
  const groups = []; TS_FIELDS.forEach(f => { if (f[2] && f[2].startsWith('h:')) groups.push({ title: f[2].slice(2), fields: [] }); groups[groups.length - 1].fields.push(f); });
  return (
    <div className="card">
      <h3>Tax Settings</h3>
      <p style={note}>Every rate below is yours to change - nothing here is fixed by the system. "Inclusive" treats the Gross Amount as already containing the tax (tax = Gross÷(1+Rate)×Rate, the same approach already used for General Sales Tax's Active/Filer rate); "Exclusive" adds the tax as a straight percentage on top (tax = Gross×Rate).</p>
      {groups.map(g => (
        <div key={g.title}>
          <h4 style={h4}>{g.title}</h4>
          <div className="row">{g.fields.map(field)}</div>
          {g.title.startsWith('General') && <p style={small}>Active/Filer always uses the Inclusive approach with the standard 1/5th-withholding rule; Inactive/Non-Filer is always a straight Exclusive percentage of Gross. Only the rate itself is editable for these two, to avoid accidentally changing that specific FBR compliance rule.</p>}
          {g.title.startsWith('Punjab Sales Tax - Ex') && <p style={small}>Applies only to Vendor bills with Nature of Bill = "Execution of Contract", by category.</p>}
          {g.title === 'Income Tax' && <p style={small}>Section 149 (salary slabs), Section 153(1)(a) Supply, and Section 153(1)(c) Contract Income Tax use fixed Company/Individual x Filer/Non-Filer rate tables built into the system, and Section 149's slabs are edited separately below.</p>}
        </div>
      ))}
      <button className="primary" style={{ marginTop: 10 }} onClick={save}>Save Tax Settings</button>

      <h3 style={{ marginTop: 18, fontSize: 13 }}>Section 149 Salary Tax Slabs</h3>
      <p style={note}>Used for UE/Non-UE Employee bills. Threshold = income where the bracket starts; Fixed Amount = tax already accumulated by that threshold; Rate = marginal % on the amount above it. Edit any row below and click Save, or add a new one - revise these whenever the slabs change.</p>
      <div className="row">
        <F label="Threshold"><input type="number" value={s.threshold} onChange={e => setS({ ...s, threshold: e.target.value })} /></F>
        <F label="Fixed Amount"><input type="number" value={s.fixedAmount} onChange={e => setS({ ...s, fixedAmount: e.target.value })} /></F>
        <F label="Rate %"><input type="number" step="0.01" value={s.rate} onChange={e => setS({ ...s, rate: e.target.value })} /></F>
        <F label="Label"><Txt v={s.label} set={v => setS({ ...s, label: v })} /></F>
        <F end><button className="primary" onClick={saveSlab}>Save Slab</button></F>
      </div>
      <div className="table-wrap" style={{ marginTop: 10 }}><table>
        <thead><tr><th className="num">Threshold</th><th className="num">Fixed Amount</th><th className="num">Rate</th><th>Label</th><th></th></tr></thead>
        <tbody>{slabs.length === 0 && <EmptyRow cols={5} text="No slabs." />}
          {slabs.map(x => <tr key={x.threshold}><td className="num">{num(x.threshold)}</td><td className="num">{num(x.fixedAmount)}</td><td className="num">{(x.rate * 100).toFixed(2)}%</td><td>{x.label || ''}</td>
            <td><button className="secondary" onClick={() => setS({ threshold: x.threshold, fixedAmount: x.fixedAmount, rate: (x.rate * 100).toFixed(2), label: x.label || '' })}>Edit</button> <button className="secondary" onClick={() => delSlab(x.threshold)}>Delete</button></td></tr>)}</tbody></table></div>
    </div>
  );
}

/* ---------- Employees + read-only lists ---------- */
function Employees({ user }) {
  const { toast, run } = useToast();
  const blank = { employeeId: '', name: '', cnic: '', iban: '', bankName: '', department: '', designation: '' };
  const [e, setE] = useState(blank);
  const [income, setIncome] = useState('');
  const [fy, setFy] = useState(DEFAULT_FY);
  const [query, setQuery] = useState('');
  const [rows, setRows] = useState(null);
  const set = k => ev => setE({ ...e, [k]: ev.target.value });
  async function load() { const r = await run(() => gs('searchEmployees', query), 'Loading...', 'Loaded.'); if (Array.isArray(r)) setRows(r); }
  async function save() {
    const emp = Object.fromEntries(Object.entries(e).map(([k, v]) => [k, v.trim()]));
    if (!emp.employeeId || !emp.name) { toast('Employee ID and Name are required.', 'error'); return; }
    if (emp.cnic && !isCnic(emp.cnic)) { toast('CNIC must be in the format 35201-1222334-4.', 'error'); return; }
    if (emp.iban && !isIban(emp.iban)) { toast('IBAN must start with PK and be 24 characters in total (e.g. PK36SCBL0000001123456702).', 'error'); return; }
    const r = await run(() => gs('addEmployee', user.username, emp), 'Saving...', 'Employee saved.');
    if (r && r.success) {
      if (income) await gs('saveIncomeProfile', user.username, { key: emp.employeeId, payeeType: 'Employee', fy: fy || DEFAULT_FY, name: emp.name, annualTaxableIncome: income, affidavitLowIncome: false }).catch(x => toast(x.message, 'error'));
      setE(blank); setIncome(''); load();
    }
  }
  return (
    <div className="card">
      <h3>Employees (UE)</h3>
      <p style={note}>Register UE Employees here so their details auto-fill in New Entry via Employee ID. Only Admin can add a new UE Employee - there is no provision to add one from the Entry form.</p>
      <div className="row">
        <F label="Employee ID"><input value={e.employeeId} onChange={set('employeeId')} /></F><F label="Name"><input value={e.name} onChange={set('name')} /></F>
        <F label="CNIC"><input value={e.cnic} onChange={set('cnic')} maxLength={15} placeholder="35201-1222334-4" /></F><F label="IBAN"><input value={e.iban} onChange={set('iban')} /></F>
        <F label="Bank Name"><input value={e.bankName} onChange={set('bankName')} /></F><F label="Department"><input value={e.department} onChange={set('department')} /></F><F label="Designation"><input value={e.designation} onChange={set('designation')} /></F>
      </div>
      <div className="row">
        <F label="Annual Taxable Income (for Section 149)"><input type="number" value={income} onChange={ev => setIncome(ev.target.value)} /></F>
        <F label="Financial Year"><select value={fy} onChange={ev => setFy(ev.target.value)}>{FYS.map(y => <option key={y}>{y}</option>)}</select></F>
      </div>
      <button className="primary" onClick={save}>Save Employee</button>
      <div className="row" style={{ marginTop: 12 }}><F label="Search Employees"><Txt v={query} set={setQuery} placeholder="Name or ID" /></F><F end><button className="primary" onClick={load}>Load</button></F></div>
      <div className="table-wrap" style={{ marginTop: 10 }}><table>
        <thead><tr><th>ID</th><th>Name</th><th>CNIC</th><th>IBAN</th><th>Bank</th><th>Department</th><th>Designation</th></tr></thead>
        <tbody>{rows === null && <EmptyRow cols={7} text="Click Load to search." />}{rows && rows.length === 0 && <EmptyRow cols={7} text="Nothing found." />}
          {(rows || []).map(x => <tr key={x.EmployeeID}><td>{x.EmployeeID}</td><td>{x.Name}</td><td>{x.CNIC || ''}</td><td>{x.IBAN || ''}</td><td>{x.BankName || ''}</td><td>{x.Department || ''}</td><td>{x.Designation || ''}</td></tr>)}</tbody></table></div>
    </div>
  );
}

function Lookup({ title, fn, label, placeholder, heads, cells }) {
  const { run } = useToast();
  const [q, setQ] = useState('');
  const [rows, setRows] = useState(null);
  async function load() { const r = await run(() => gs(fn, q), 'Loading...'); if (Array.isArray(r)) setRows(r); }
  return (
    <>
      <div className="row" style={{ marginTop: 12 }}><F label={label}><Txt v={q} set={setQ} placeholder={placeholder} /></F><F end><button className="secondary" onClick={load}>Load</button></F></div>
      <div className="table-wrap"><table>
        <thead><tr>{heads.map(h => <th key={h}>{h}</th>)}</tr></thead>
        <tbody>{rows === null && <EmptyRow cols={heads.length} text="Click Load to search." />}{rows && rows.length === 0 && <EmptyRow cols={heads.length} text="Nothing found." />}
          {(rows || []).map((r, i) => <tr key={i}>{cells(r).map((c, j) => <td key={j}>{c}</td>)}</tr>)}</tbody></table></div>
    </>
  );
}
function OtherPayees() {
  return (
    <div className="card">
      <h3>Non-UE Employees, Vendors &amp; Students</h3>
      <p style={note}>These self-register the first time they're billed - this is a read-only search/browse view, doesn't load everything by default.</p>
      <Lookup fn="searchNonUEEmployees" label="Search Non-UE Employees" placeholder="Name or CNIC" heads={['CNIC', 'Name', 'IBAN', 'Bank']} cells={e => [e.CNIC, e.Name, e.IBAN || '', e.BankName || '']} />
      <Lookup fn="searchVendorsAdmin" label="Search Vendors" placeholder="Name or CNIC/NTN" heads={['Vendor Name', 'CNIC/NTN', 'IBAN', 'Bank']} cells={v => [v.VendorName, v.CNIC_NTN || '', v.IBAN || '', v.BankName || '']} />
      <Lookup fn="searchStudents" label="Search Students" placeholder="Name or Student ID" heads={['Student ID', 'Name', 'CNIC', 'IBAN', 'Program', 'Session', 'Shift']} cells={s => [s.StudentID, s.Name, s.CNIC || '', s.IBAN || '', s.Program || '', s.Session || '', s.Shift || '']} />
    </div>
  );
}

/* ---------- Bank accounts and receiving offices ---------- */
function BankAccounts({ user }) {
  const { toast, run } = useToast();
  const [f, setF] = useState({ accountTitle: '', bankName: '', accountNumber: '' });
  const [rows, setRows] = useState(null);
  const load = () => gs('getBankAccounts').then(setRows).catch(e => toast(e.message, 'error'));
  async function add() {
    const r = await run(() => gs('addBankAccount', user.username, f), 'Saving account...', 'Bank account added.');
    if (r && r.success) { setF({ accountTitle: '', bankName: '', accountNumber: '' }); load(); }
  }
  async function off(a) {
    if (!window.confirm('Deactivate this bank account? It will no longer appear as an option on New Entry.')) return;
    const r = await run(() => gs('deactivateBankAccount', user.username, a.AccountID), 'Deactivating...', 'Deactivated.'); if (r && r.success) load();
  }
  return (
    <div className="card">
      <h3>Bank Accounts (Pay From)</h3>
      <p style={note}>These are the organization's own accounts a bill can be paid from - every New Entry must pick one. The list below doesn't load automatically - click Load to view/manage it.</p>
      <div className="row">
        <F label="Account Title"><Txt v={f.accountTitle} set={v => setF({ ...f, accountTitle: v })} /></F><F label="Bank Name"><Txt v={f.bankName} set={v => setF({ ...f, bankName: v })} /></F>
        <F label="Account Number / IBAN"><Txt v={f.accountNumber} set={v => setF({ ...f, accountNumber: v })} /></F>
        <F end><button className="primary" onClick={add}>Add Account</button> <button className="secondary" onClick={load}>Load</button></F>
      </div>
      <div className="table-wrap" style={{ marginTop: 10 }}><table>
        <thead><tr><th>Account Title</th><th>Bank</th><th>Account No.</th><th></th></tr></thead>
        <tbody>{rows === null && <EmptyRow cols={4} text="Click Load to view accounts." />}{rows && rows.length === 0 && <EmptyRow cols={4} text="No accounts." />}
          {(rows || []).map(a => <tr key={a.AccountID}><td>{a.AccountTitle}</td><td>{a.BankName}</td><td>{a.AccountNumber || ''}</td><td><button className="secondary" style={{ color: 'var(--danger)' }} onClick={() => off(a)}>Deactivate</button></td></tr>)}</tbody></table></div>
    </div>
  );
}
function Offices({ user }) {
  const { run } = useToast();
  const [name, setName] = useState('');
  const [rows, setRows] = useState(null);
  const load = () => gs('getReceivingOffices').then(setRows).catch(() => {});
  async function add() { const r = await run(() => gs('addReceivingOffice', user.username, name), 'Saving office...', 'Office added.'); if (r && r.success) { setName(''); load(); } }
  async function off(o) {
    if (!window.confirm('Deactivate this office? It will no longer appear as an option on New Entry.')) return;
    const r = await run(() => gs('deactivateReceivingOffice', user.username, o.OfficeID), 'Deactivating...', 'Deactivated.'); if (r && r.success) load();
  }
  return (
    <div className="card">
      <h3>Receiving Offices</h3>
      <p style={note}>Selected first thing on every New Entry - purely informational, has no effect on budget anywhere, and only reappears on the IBFT Payment Batch CSV download. The list below doesn't load automatically - click Load to view/manage it.</p>
      <div className="row"><F label="Office Name"><Txt v={name} set={setName} /></F><F end><button className="primary" onClick={add}>Add Office</button> <button className="secondary" onClick={load}>Load</button></F></div>
      <div className="table-wrap" style={{ marginTop: 10 }}><table>
        <thead><tr><th>Office</th><th></th></tr></thead>
        <tbody>{rows === null && <EmptyRow cols={2} text="Click Load to view offices." />}{rows && rows.length === 0 && <EmptyRow cols={2} text="No offices." />}
          {(rows || []).map(o => <tr key={o.OfficeID}><td>{o.OfficeName}</td><td><button className="secondary" style={{ color: 'var(--danger)' }} onClick={() => off(o)}>Deactivate</button></td></tr>)}</tbody></table></div>
    </div>
  );
}

/* ---------- Pipeline overview + system check ---------- */
function Pipeline() {
  const [fy, setFy] = useState('');
  const [c, setC] = useState(null);
  useEffect(() => { gs('getPipelineCounts', fy).then(setC).catch(() => {}); }, [fy]);
  return (
    <div className="card">
      <h3>Pipeline Overview</h3>
      <p style={note}>Live count of bills sitting in each stage for the selected year - the fastest way to spot bills that are stuck.</p>
      <div className="row"><F label="Financial Year" max={220}><FYSelect value={fy} onChange={setFy} options={FYS} /></F></div>
      <div className="balance-box">
        {['Received', 'Processed', 'Passed', 'Paid'].map((k, i) => <div key={k} className={i === 0 ? 'bal-allocated' : i === 1 ? 'bal-spent' : 'bal-remaining'}><span className="label">{k}</span><span className="val">{c ? c[k] : '-'}</span></div>)}
      </div>
    </div>
  );
}
function SystemCheck({ user }) {
  const { run } = useToast();
  const [rows, setRows] = useState(null);
  async function go() { const r = await run(() => gs('systemCheck', user.username), 'Checking sheets...', 'Check complete.'); if (Array.isArray(r)) setRows(r); }
  return (
    <div className="card">
      <h3>System Check</h3>
      <p style={note}>Confirms every sheet exists with the right columns, and flags any bill whose Status doesn't cleanly match Received/Processed/Passed/Paid (a common reason bills seem to "disappear" between stages) - run this any time something looks off.</p>
      <button className="secondary" onClick={go}>Run Check</button>
      <div className="table-wrap" style={{ marginTop: 10 }}><table>
        <thead><tr><th>Sheet</th><th>Status</th><th>Rows</th><th>Details</th></tr></thead>
        <tbody>{(rows || []).map((r, i) => <tr key={i}><td>{r.sheet}</td><td>{r.ok ? '✅ OK' : '⚠️ Issue'}</td><td>{r.rowCount ?? ''}</td><td>{r.message}</td></tr>)}</tbody></table></div>
    </div>
  );
}

/* ---------- Manage Entries (Edit / Delete / Cancel) ---------- */
const sameStatus = (a, b) => String(a || '').trim().toLowerCase() === String(b || '').trim().toLowerCase();
function ManageEntries({ user, onEditBill, onOpenBill }) {
  const { toast, run } = useToast();
  const [q, setQ] = useState({ billId: '', fy: '', status: 'Received', vendor: '', description: '' });
  const [rows, setRows] = useState(null);
  const up = k => e => setQ({ ...q, [k]: e.target.value });
  async function load() {
    const list = await run(() => gs('searchEntriesAdmin', q, user.username), 'Loading entries...');
    setRows(Array.isArray(list) ? list : []);
  }
  async function del(id) {
    if (!window.confirm('Delete bill ' + id + '? This cannot be undone and leaves no audit trail. For a bill already past Received, use Cancel instead.')) return;
    const res = await run(() => gs('deleteEntry', id, user.username), 'Deleting bill...', 'Bill deleted.');
    if (res && res.success) load();
  }
  async function cancel(id, status) {
    const paid = sameStatus(status, 'Paid') ? ' This bill has already been PAID - cancelling does NOT reverse the actual money transfer, it only removes it from budget/consumption figures going forward and flags the record.' : '';
    const reason = window.prompt('Cancel bill ' + id + '?' + paid + '\n\nReason for cancelling (kept on the record):');
    if (reason === null) return;
    const res = await run(() => gs('cancelEntry', id, reason, user.username), 'Cancelling bill...', 'Bill cancelled - it no longer counts anywhere.');
    if (res && res.success) load();
  }
  return (
    <div className="card" id="adm-manageentries">
      <h3>Manage Entries (Edit / Delete)</h3>
      <p style={note}>Edit or Delete only work on a bill still at <b>Received</b> status - once it moves to Processed/Passed/Paid, someone downstream has already acted on it. A bill at any later stage (including Paid) can instead be <b>Cancelled</b> - its record stays for audit, but it's excluded from every budget, consumption, and payment calculation from that point on, exactly as if it never happened financially. Deleting is permanent and has no audit trail; Cancelling always keeps one.</p>
      <div className="row">
        <F label="Bill ID contains" max={160}><input type="text" id="me_billid" value={q.billId} onChange={up('billId')} /></F>
        <F label="Financial Year" max={200}><FYSelect id="me_fy" value={q.fy} onChange={v => setQ({ ...q, fy: v })} options={FYS} /></F>
        <F label="Status"><select id="me_status" value={q.status} onChange={up('status')}><option value="Received">Received</option><option value="">All</option><option>Processed</option><option>Passed</option><option>Paid</option><option>Cancelled</option></select></F>
        <F label="Vendor/Name contains"><input type="text" id="me_vendor" value={q.vendor} onChange={up('vendor')} /></F>
        <F label="Description contains"><input type="text" id="me_description" value={q.description} onChange={up('description')} /></F>
        <F end><button className="primary" id="btnLoadManageEntries" onClick={load}>Load</button></F>
      </div>
      <div className="table-wrap" style={{ marginTop: 10 }}>
        <table id="manageEntriesTable">
          <thead><tr><th>Bill ID</th><th>Date</th><th>Campus</th><th>Vendor/Payee</th><th>Description</th><th className="num">Amount</th><th>Status</th><th>Entered By</th><th></th></tr></thead>
          <tbody>{rows === null ? <EmptyRow cols={9} text="Set filters above and click Load." /> : rows.length ? rows.map(e => {
            const editable = sameStatus(e.Status, 'Received'), cancelled = sameStatus(e.Status, 'Cancelled');
            return <tr key={e.EntryID}>
              <td><BillLink id={e.EntryID} onOpen={onOpenBill} /></td><td>{fmtDate(e.EntryDate)}</td><td>{e.CampusName}</td><td>{e.VendorName}</td><td>{e.BillDescription || ''}</td><td className="num">{num(e.Amount)}</td>
              <td><span className={'pill ' + e.Status}>{e.Status}</span></td><td>{e.EnteredBy || ''}</td>
              <td>{editable ? <>
                <button className="secondary" onClick={() => onEditBill(e.EntryID)}>Edit</button>{' '}
                <button className="secondary" style={{ color: 'var(--danger)' }} onClick={() => del(e.EntryID)}>Delete</button>{' '}
                <button className="secondary" onClick={() => cancel(e.EntryID, e.Status)}>Cancel</button></>
                : cancelled ? <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>cancelled{e.StatusBeforeCancellation ? ' (was ' + e.StatusBeforeCancellation + ')' : ''}</span>
                : <button className="secondary" onClick={() => cancel(e.EntryID, e.Status)}>Cancel</button>}</td>
            </tr>;
          }) : <EmptyRow cols={9} text="No entries found." />}</tbody>
        </table>
      </div>
    </div>
  );
}

export default function Admin({ user, onEditBill, onOpenBill, onChanged }) {
  const [view, setView] = useState('setup');
  const [campuses, setCampuses] = useState([]);
  const reloadCampuses = useCallback(() => gs('getCampuses').then(setCampuses).catch(() => {}), []);
  useEffect(() => { reloadCampuses(); }, [reloadCampuses]);
  return (
    <div className="tabpanel active">
      <nav className="subtabs no-print">
        <button className={'sub-btn' + (view === 'setup' ? ' active' : '')} onClick={() => setView('setup')}>Setup &amp; Records</button>
        <button className={'sub-btn' + (view === 'tools' ? ' active' : '')} onClick={() => setView('tools')}>Bill Management &amp; Section 149 Tools</button>
      </nav>
      {view === 'setup' ? (
        <>
          <Allocations user={user} campuses={campuses} reloadCampuses={reloadCampuses} />
          <Heads user={user} /><Users user={user} /><TaxSettings user={user} /><Employees user={user} /><OtherPayees />
          <BankAccounts user={user} /><Offices user={user} /><Pipeline /><SystemCheck user={user} />
        </>
      ) : (
        <>
          <ManageEntries user={user} onEditBill={onEditBill} onOpenBill={onOpenBill} />
          <AdminTools user={user} onOpenBill={onOpenBill} onChanged={onChanged || (() => {})} />
        </>
      )}
    </div>
  );
}
