import React, { useCallback, useEffect, useState } from 'react';
import { gs } from '../api.js';
import { fmtDate, num, todayISO, exportCSV } from '../util.js';
import { useToast, EmptyRow, Modal, BillLink } from '../ui.jsx';

/* Stage 0 - Diary / Receiving. Same rules as the original screen:
   - Diary Clerk (and Admin): log items, browse Pending Diary Items, Returned / On Hold, Sent to Other Offices.
   - Everyone except the Diary Clerk (Admin too): My Diary Position and My Diary Queue. */

const note = { fontSize: 12.5, color: 'var(--text-muted)' };
const h4 = { margin: '14px 0 6px', color: 'var(--text-muted)', fontSize: 12, textTransform: 'uppercase', letterSpacing: '.05em' };
const radioLbl = { display: 'flex', alignItems: 'center', gap: 6, fontWeight: 'normal' };
const bigText = { width: '100%', maxWidth: '100%', resize: 'both' };
const STAGE_COLORS = { 0: 'var(--text-muted)', 1: '#93C5FD', 2: '#FCD34D', 3: '#93C5FD', 4: '#6EE7B7', 5: 'var(--danger)', 6: 'var(--accent)', 7: 'var(--amber)' };
const BOX_CLASS = { 0: 'bal-spent', 1: 'bal-allocated', 2: 'bal-allocated', 3: 'bal-allocated', 4: 'bal-allocated', 5: 'bal-spent', 6: 'bal-remaining', 7: 'bal-spent' };
const ACCEPT = '.pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png';

const typeLabel = r => (r.itemType === 'Bill' && r.billType) ? 'Bill (' + r.billType + ')' : r.itemType;
const F = ({ label, children, end, max, style }) => <div className="field" style={{ ...(end ? { alignSelf: 'flex-end' } : {}), ...(max ? { maxWidth: max } : {}), ...style }}>{label && <label>{label}</label>}{children}</div>;
const Txt = ({ v, set, ...p }) => <input type="text" value={v} onChange={e => set(e.target.value)} {...p} />;
const Sel = ({ v, set, children, ...p }) => <select value={v} onChange={e => set(e.target.value)} {...p}>{children}</select>;

/* A chosen PDF/JPEG file -> {name, mime, base64}; null when nothing was chosen. */
function readAttachment(file) {
  return new Promise((resolve, reject) => {
    if (!file) { resolve(null); return; }
    const ext = file.name.split('.').pop().toLowerCase();
    if (['pdf', 'jpg', 'jpeg', 'png'].indexOf(ext) === -1) { reject(new Error('Only PDF or JPEG/JPG (or PNG) files can be attached.')); return; }
    if (file.size > 5 * 1024 * 1024) { reject(new Error('The file is too large (5 MB maximum).')); return; }
    const fr = new FileReader();
    fr.onload = () => { const s = String(fr.result); resolve({ name: file.name, mime: file.type, base64: s.substring(s.indexOf(',') + 1) }); };
    fr.onerror = () => reject(new Error('Could not read the file.'));
    fr.readAsDataURL(file);
  });
}
function FileInput({ label, onFile, resetKey }) {
  return <F label={label}><input key={resetKey} type="file" accept={ACCEPT} onChange={e => onFile(e.target.files && e.target.files[0] || null)} /></F>;
}

export const MOVEMENT_LABELS = {
  Assigned: 'Assigned', Forwarded: 'Forwarded', ClosedResponse: 'Closed - Response Issued', ClosedFiled: 'Closed - Filed',
  Returned: 'Returned', Reassigned: 'Reassigned', AdminReassigned: 'Reassigned (Admin)', SentToOffice: 'Sent to Another Office',
  ResumedByController: 'Re-assigned & Resumed (Diary Clerk/Admin)', ReturnedForCorrection: 'Returned for Correction',
  BillDeleted: 'Bill Deleted - Back to Diary Pending', CombinedIntoBulkBill: 'Combined into a Bulk Bill',
  OfficeConfirmedArrival: 'Office Confirmed Arrival', Released: 'Released - Resumed',
  AdminEdited: 'Diary Details Edited (Admin)', AdminCancelled: 'Diary Cancelled (Admin)', AdminRestored: 'Diary Restored (Admin)',
  AdminDelinked: 'De-linked from Bill (Admin)', AdminLinked: 'Linked to Bill (Admin)'
};
const ATT_KIND = { Original: 'Original letter', Response: 'Response letter', Objection: 'Objection letter' };

/* ---------- small shared pieces ---------- */
export function StagePill({ stage, children }) { return <span style={{ color: STAGE_COLORS[stage] || 'inherit', fontWeight: 700 }}>{children}</span>; }
function Days({ d }) { return <span style={{ color: d > 10 ? 'var(--danger)' : 'inherit', fontWeight: d > 10 ? 700 : 400 }}>{d}</span>; }
function DiaryLink({ id, onTrail }) { return <a href="#trail" onClick={e => { e.preventDefault(); onTrail(id); }} style={{ color: 'var(--accent)', fontWeight: 600, textDecoration: 'underline' }}>{id}</a>; }
function StageBoxes({ counts }) {
  return <div className="balance-box">{(counts || []).map(s => <div key={s.stage} className={BOX_CLASS[s.stage]}><span className="label">{s.stage} - {s.label}</span><span className="val">{s.count}</span></div>)}</div>;
}

async function openAttachment(id, view, toast) {
  let w = null;
  if (view) w = window.open('', '_blank');   // opened first (inside the click) so the browser does not block it
  const res = await gs('getDiaryAttachmentData', id).catch(e => ({ success: false, message: e.message }));
  if (!res || !res.success) { if (w) w.close(); toast((res && res.message) || 'Could not open the file.', 'error'); return; }
  const bin = atob(res.base64), arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  const url = URL.createObjectURL(new Blob([arr], { type: res.mime }));
  if (view && w) w.location.href = url;
  else { const a = document.createElement('a'); a.href = url; a.download = res.name; document.body.appendChild(a); a.click(); a.remove(); }
  setTimeout(() => URL.revokeObjectURL(url), 120000);
}

/* ---------- the DN trail pop-up (also used by other screens) ---------- */
export function DiaryTrail({ diaryId, onClose }) {
  const { toast } = useToast();
  const [res, setRes] = useState(null);
  useEffect(() => { gs('getDiaryTrail', diaryId).then(setRes).catch(e => setRes({ success: false, message: e.message })); }, [diaryId]);
  const link = { color: 'var(--accent)', textDecoration: 'underline' };
  let body;
  if (!res) body = 'Loading...';
  else if (!res.success) body = <p className="error">{res.message || 'Could not load.'}</p>;
  else {
    const d = res.diary;
    const sender = d.SenderType === 'Employee' ? 'Employee ' + d.EmployeeID : (d.SenderType === 'Office' ? d.SenderOfficeName : d.VendorName);
    const att = {};
    (res.attachments || []).forEach(a => { (att[a.movementId] || (att[a.movementId] = [])).push(a); });
    const wrap = { whiteSpace: 'normal', minWidth: 260, maxWidth: 420, wordBreak: 'break-word' };
    const item = (l, v) => <div className="bav-item"><div className="bav-label">{l}</div><div className="bav-value">{v || '-'}</div></div>;
    body = <>
      <div style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 4 }}>{d.ItemType + (d.ItemType === 'Bill' && d.BillType ? ' (' + d.BillType + ')' : '')} &middot; Logged {fmtDate(d.DateReceived)} by {d.LoggedBy}</div>
      <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 10 }}><StagePill stage={res.currentStage}>{res.currentStage} - {res.currentStageLabel}</StagePill> &middot; {res.daysWaiting} day(s)</div>
      <div className="bav-grid" style={{ marginBottom: 14 }}>
        {item('Sender', sender)}{item("Sender's Reference No.", d.SenderReferenceNo)}{item('Originating Office', d.OriginatingOfficeName || d.OriginatingOfficeOther)}{item('Description', d.RoughDescription)}
        {d.Amount !== '' && d.Amount !== undefined && item('Amount (per Diary)', num(d.Amount))}
      </div>
      <h4 style={{ margin: '10px 0 6px' }}>Movement / Disposal Trail</h4>
      <div className="table-wrap"><table>
        <thead><tr><th>Date</th><th>Action</th><th>From</th><th>To</th><th>Detail</th><th>Files</th></tr></thead>
        <tbody>
          {res.movements.map((m, i) => {
            let detail = m.Details || '';
            if (m.ActionType === 'ClosedResponse') detail = 'Ref: ' + (m.ResponseRefNo || '-') + ', Dated: ' + fmtDate(m.ResponseDate) + (m.Details ? ' - ' + m.Details : '');
            if (m.ActionType === 'Returned') detail = 'Objection: ' + m.ReturnObjection + ' | Return Ref: ' + (m.ReturnRefNo || '-') + ' | Return Date: ' + fmtDate(m.ReturnDate) + ' | Receiver: ' + m.ReturnReceiverName;
            if (m.ActionType === 'ReturnedForCorrection') detail = 'Objection: ' + (m.ReturnObjection || '') + (m.Details ? ' - ' + m.Details : '');
            return <tr key={m.MovementID || i}>
              <td>{fmtDate(m.ActionDate)}</td><td>{MOVEMENT_LABELS[m.ActionType] || m.ActionType}</td><td>{m.FromUser}</td><td>{m.ToUser}</td>
              <td style={wrap}>{detail}</td>
              <td style={{ whiteSpace: 'normal' }}>{(att[m.MovementID] || []).map(a => (
                <div key={a.attachmentId} style={{ margin: '2px 0' }}><b>{ATT_KIND[a.kind] || a.kind}:</b> {a.fileName}{' '}
                  <a href="#v" style={link} onClick={e => { e.preventDefault(); openAttachment(a.attachmentId, true, toast); }}>View</a> |{' '}
                  <a href="#d" style={link} onClick={e => { e.preventDefault(); openAttachment(a.attachmentId, false, toast); }}>Download</a></div>))}</td>
            </tr>;
          })}
          {res.billTrail && res.billTrail.length > 0 && <>
            <tr><td colSpan={6} style={{ background: '#0B1220', fontWeight: 700 }}>Bill Pipeline (Bill {d.LinkedEntryID})</td></tr>
            {res.billTrail.map((b, i) => <tr key={'b' + i}><td>{fmtDate(b.date)}</td><td>{b.event}</td><td>{b.by}</td><td></td><td style={wrap}>{b.note}</td><td></td></tr>)}
          </>}
        </tbody>
      </table></div>
    </>;
  }
  return (
    <Modal id="diaryTrailModal" maxWidth={1000} onClose={onClose} z={110}>
      <h3 style={{ marginTop: 0 }}>Diary Trail <span style={{ color: 'var(--accent)' }}>{diaryId}</span></h3>
      <div id="diaryTrailContent">{body}</div>
      <button className="secondary" style={{ marginTop: 12 }} onClick={onClose}>Close</button>
    </Modal>
  );
}

/* ---------- pop-ups ---------- */
function ResumeModal({ item, user, onClose, onDone }) {
  const { toast, run } = useToast();
  const [users, setUsers] = useState([]);
  const [to, setTo] = useState('');
  const [text, setText] = useState('');
  useEffect(() => { if (item.diaryId) gs('getDiaryEligibleUsers').then(setUsers).catch(() => {}); }, [item.diaryId]);
  async function submit() {
    let res;
    if (item.diaryId) {
      if (!to) { toast('Select who to assign this to.', 'error'); return; }
      res = await run(() => gs('resumeHeldItem', item.diaryId, to, text.trim(), user.username), 'Resuming...', 'Re-assigned and resumed.');
    } else {
      res = await run(() => gs('releaseBillHold', item.entryId, user.username), 'Releasing...', 'Released - resumed at its current stage.');
    }
    if (res && res.success) onDone();
  }
  return (
    <Modal id="resumeModal" maxWidth={640} onClose={onClose} z={106}>
      <h3 style={{ marginTop: 0 }}>Re-assign &amp; Resume <span style={{ color: 'var(--accent)' }}>{item.diaryId || item.entryId}</span></h3>
      <p style={note}>It resumes exactly where it left off, with the person you pick here.</p>
      {item.diaryId && <F label="Assign To"><Sel id="rm_user" v={to} set={setTo}><option value="">-- select --</option>{users.map(u => <option key={u.Username} value={u.Username}>{u.FullName}</option>)}</Sel></F>}
      <F label="Note (optional)"><textarea id="rm_note" rows={4} style={{ ...bigText, minHeight: 90 }} value={text} onChange={e => setText(e.target.value)} /></F>
      <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
        <button className="primary" style={{ flex: 1 }} onClick={submit}>Re-assign &amp; Resume</button>
        <button className="secondary" style={{ flex: 1 }} onClick={onClose}>Cancel</button>
      </div>
    </Modal>
  );
}

function ReassignModal({ item, user, onClose, onDone }) {
  const { toast, run } = useToast();
  const [users, setUsers] = useState([]);
  const [kind, setKind] = useState('user');
  const [to, setTo] = useState('');
  const [office, setOffice] = useState('');
  const [purpose, setPurpose] = useState('');
  useEffect(() => { gs('getDiaryEligibleUsers').then(l => setUsers(l.filter(u => u.Username !== user.username))).catch(() => {}); }, [user.username]);
  const isOffice = kind === 'office';
  async function submit() {
    if (!purpose.trim()) { toast('Enter the purpose/reason.', 'error'); return; }
    const target = isOffice ? { type: 'office', officeName: office.trim() } : { type: 'user', username: to };
    if (isOffice && !target.officeName) { toast('Enter the office name.', 'error'); return; }
    if (!isOffice && !target.username) { toast('Select who to reassign to.', 'error'); return; }
    const res = await run(() => gs('reassignItem', item.id, target, purpose.trim(), user.username), 'Reassigning...',
      isOffice ? 'Sent - the Diary Clerk/Admin will re-assign it when it returns.' : 'Reassigned.');
    if (res && res.success) onDone();
  }
  return (
    <Modal id="reassignModal" maxWidth={640} onClose={onClose} z={106}>
      <h3 style={{ marginTop: 0 }}>Reassign <span style={{ color: 'var(--accent)' }}>{item.id}{item.kind ? ' (' + item.kind + ')' : ''}</span></h3>
      <div className="row" style={{ alignItems: 'center' }}>
        <label style={radioLbl}><input type="radio" style={{ width: 'auto' }} checked={!isOffice} onChange={() => setKind('user')} /> A User</label>
        <label style={radioLbl}><input type="radio" style={{ width: 'auto' }} checked={isOffice} onChange={() => setKind('office')} /> Another Office</label>
      </div>
      {!isOffice && <F label="Reassign To"><Sel id="ra_targetUser" v={to} set={setTo}><option value="">-- select --</option>{users.map(u => <option key={u.Username} value={u.Username}>{u.FullName}</option>)}</Sel></F>}
      {isOffice && <F label="Office Name"><Txt id="ra_targetOffice" v={office} set={setOffice} /></F>}
      {isOffice && <p style={{ fontSize: 12, color: 'var(--amber)' }}>Sending to another office holds the item - you keep a view-only record, and only the Diary Clerk/Admin can re-assign and resume it.</p>}
      <F label="Purpose / Reason"><textarea id="ra_purpose" rows={5} style={{ ...bigText, minHeight: 110 }} value={purpose} onChange={e => setPurpose(e.target.value)} /></F>
      <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
        <button className="primary" style={{ flex: 1 }} onClick={submit}>Reassign</button>
        <button className="secondary" style={{ flex: 1 }} onClick={onClose}>Cancel</button>
      </div>
    </Modal>
  );
}

function BillHoldReturnModal({ entryId, user, onClose, onDone }) {
  const { toast, run } = useToast();
  const [objection, setObjection] = useState('');
  async function submit() {
    if (!objection.trim()) { toast('Enter the objection/reason.', 'error'); return; }
    const res = await run(() => gs('returnBillForCorrection', entryId, objection.trim(), '', user.username), 'Returning...', 'Returned - the Diary Clerk/Admin will re-assign it.');
    if (res && res.success) onDone();
  }
  return (
    <Modal id="billOnHoldReturnModal" maxWidth={640} onClose={onClose} z={106}>
      <h3 style={{ marginTop: 0 }}>Return Bill <span style={{ color: 'var(--accent)' }}>{entryId}</span> for Correction</h3>
      <p style={note}>You keep a view-only record. The Diary Clerk/Admin will re-assign and resume it.</p>
      <F label="Objection / Reason"><textarea id="bor_objection" rows={6} style={{ ...bigText, minHeight: 140 }} value={objection} onChange={e => setObjection(e.target.value)} /></F>
      <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
        <button className="primary" style={{ flex: 1 }} onClick={submit}>Return</button>
        <button className="secondary" style={{ flex: 1 }} onClick={onClose}>Cancel</button>
      </div>
    </Modal>
  );
}

/* Shared "objection letter" fields used when returning a Letter or a Bill still at Diary stage */
function ReturnFields({ v, set, fileKey, idPrefix }) {
  return <>
    <F label="Objection / Reason for Return"><textarea id={idPrefix + 'objection'} rows={9} style={{ ...bigText, minHeight: 220 }} value={v.objection} onChange={e => set({ ...v, objection: e.target.value })} /></F>
    <div className="row">
      <F label="Return Diary No."><Txt id={idPrefix + 'refNo'} v={v.refNo} set={x => set({ ...v, refNo: x })} /></F>
      <F label="Return Date"><input type="date" id={idPrefix + 'date'} value={v.date} onChange={e => set({ ...v, date: e.target.value })} /></F>
      <F label="Receiver's Name"><Txt id={idPrefix + 'receiver'} v={v.receiver} set={x => set({ ...v, receiver: x })} /></F>
    </div>
    <FileInput label="Attach the Objection Letter (PDF or JPEG, max 5 MB - optional)" resetKey={fileKey} onFile={f => set({ ...v, file: f })} />
  </>;
}
const emptyReturn = () => ({ objection: '', refNo: '', date: todayISO(), receiver: '', file: null });

async function sendReturn(run, toast, user, id, v) {
  if (!v.objection.trim()) { toast('Enter the objection/reason.', 'error'); return null; }
  if (!v.receiver.trim()) { toast("Enter the receiver's name.", 'error'); return null; }
  let attachment = null;
  try { attachment = await readAttachment(v.file); } catch (e) { toast(e.message, 'error'); return null; }
  const res = await run(() => gs('returnItem', id, v.objection.trim(), v.refNo.trim(), v.date, v.receiver.trim(), attachment, user.username), 'Returning...', 'Returned - the Diary Clerk/Admin will re-assign it.');
  if (res && res.success && res.attachmentWarning) toast(res.attachmentWarning, 'error');
  return res;
}

function BillReturnModal({ diaryId, user, onClose, onDone }) {
  const { toast, run } = useToast();
  const [v, setV] = useState(emptyReturn());
  async function submit() { const res = await sendReturn(run, toast, user, diaryId, v); if (res && res.success) onDone(); }
  return (
    <Modal id="billReturnModal" maxWidth={820} onClose={onClose}>
      <h3 style={{ marginTop: 0 }}>Return <span style={{ color: 'var(--accent)' }}>{diaryId}</span></h3>
      <p style={note}>You keep a view-only record. The Diary Clerk/Admin will re-assign it.</p>
      <ReturnFields v={v} set={setV} idPrefix="br_" />
      <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
        <button className="primary" style={{ flex: 1 }} onClick={submit}>Submit</button>
        <button className="secondary" style={{ flex: 1 }} onClick={onClose}>Cancel</button>
      </div>
    </Modal>
  );
}

function LetterModal({ diaryId, user, onClose, onDone }) {
  const { toast, run } = useToast();
  const [d, setD] = useState(null);
  const [users, setUsers] = useState([]);
  const [action, setAction] = useState('forward');
  const [fwd, setFwd] = useState({ to: '', notes: '' });
  const [resp, setResp] = useState({ ref: '', date: todayISO(), details: '', file: null });
  const [filed, setFiled] = useState('');
  const [ret, setRet] = useState(emptyReturn());
  useEffect(() => {
    gs('getDiaryById', diaryId).then(x => { if (!x) { toast('Could not load this letter.', 'error'); onClose(); } else setD(x); }).catch(e => { toast(e.message, 'error'); onClose(); });
    gs('getDiaryEligibleUsers').then(l => setUsers(l.filter(u => u.Username !== user.username))).catch(() => {});
  }, [diaryId]);   // eslint-disable-line
  async function submit() {
    let res;
    if (action === 'forward') {
      if (!fwd.to) { toast('Select who to forward to.', 'error'); return; }
      res = await run(() => gs('forwardLetter', diaryId, fwd.to, fwd.notes.trim(), user.username), 'Forwarding...', 'Forwarded.');
    } else if (action === 'closeResponse') {
      let attachment = null;
      try { attachment = await readAttachment(resp.file); } catch (e) { toast(e.message, 'error'); return; }
      res = await run(() => gs('closeLetterWithResponse', diaryId, resp.ref.trim(), resp.date, resp.details.trim(), attachment, user.username), 'Closing...', 'Closed with response.');
    } else if (action === 'closeFiled') {
      res = await run(() => gs('closeLetterFiled', diaryId, filed.trim(), user.username), 'Filing...', 'Filed for information.');
    } else {
      res = await sendReturn(run, toast, user, diaryId, ret);
      if (!res) return;
    }
    if (res && res.success) { if (res.attachmentWarning && action !== 'return') toast(res.attachmentWarning, 'error'); onDone(); }
  }
  const radio = (val, text) => <label style={radioLbl}><input type="radio" name="laAction" value={val} style={{ width: 'auto' }} checked={action === val} onChange={() => setAction(val)} /> {text}</label>;
  const summary = d ? (d.RoughDescription || '(no description)') + ' - from ' + (d.SenderType === 'Employee' ? 'Employee ' + d.EmployeeID : (d.SenderType === 'Office' ? d.SenderOfficeName : d.VendorName)) + ', received ' + fmtDate(d.DateReceived) + '.' : 'Loading...';
  return (
    <Modal id="letterActionModal" maxWidth={920} onClose={onClose}>
      <h3 style={{ marginTop: 0 }}>Process Letter <span style={{ color: 'var(--accent)' }}>{diaryId}</span></h3>
      <div id="la_summary" style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 10 }}>{summary}</div>
      <div className="row" style={{ alignItems: 'center' }}>{radio('forward', 'Forward to Someone')}{radio('closeResponse', 'Close - Response Letter Issued')}</div>
      <div className="row" style={{ alignItems: 'center' }}>{radio('closeFiled', 'Close - File for Information')}{radio('return', 'Return (Objection)')}</div>
      {action === 'forward' && <>
        <F label="Forward To"><Sel id="la_forwardTo" v={fwd.to} set={x => setFwd({ ...fwd, to: x })}><option value="">-- select --</option>{users.map(u => <option key={u.Username} value={u.Username}>{u.FullName}</option>)}</Sel></F>
        <F label="Notes (optional)"><textarea id="la_forwardNotes" rows={5} style={{ ...bigText, minHeight: 120 }} value={fwd.notes} onChange={e => setFwd({ ...fwd, notes: e.target.value })} /></F>
      </>}
      {action === 'closeResponse' && <>
        <div className="row">
          <F label="Response Letter Ref. No."><Txt id="la_responseRef" v={resp.ref} set={x => setResp({ ...resp, ref: x })} /></F>
          <F label="Response Letter Date"><input type="date" id="la_responseDate" value={resp.date} onChange={e => setResp({ ...resp, date: e.target.value })} /></F>
        </div>
        <F label="Details / Response"><textarea id="la_responseDetails" rows={9} style={{ ...bigText, minHeight: 220 }} value={resp.details} onChange={e => setResp({ ...resp, details: e.target.value })} /></F>
        <FileInput label="Attach the Response Letter (PDF or JPEG, max 5 MB - optional)" onFile={f => setResp({ ...resp, file: f })} />
      </>}
      {action === 'closeFiled' && <F label="Filing Detail (folder/reference, for the record)"><textarea id="la_filedDetails" rows={4} style={{ ...bigText, minHeight: 100 }} value={filed} onChange={e => setFiled(e.target.value)} /></F>}
      {action === 'return' && <ReturnFields v={ret} set={setRet} idPrefix="la_return_" />}
      <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
        <button className="primary" style={{ flex: 1 }} onClick={submit}>Submit</button>
        <button className="secondary" style={{ flex: 1 }} onClick={onClose}>Cancel</button>
      </div>
    </Modal>
  );
}

/* ================= Diary Clerk: Log a New Bill or Letter ================= */
const emptyLog = () => ({
  itemType: 'Bill', amount: '', billType: '', dateReceived: todayISO(), senderDate: '', senderType: 'Vendor', vendorName: '', employeeId: '',
  nonueName: '', cnic: '', officeName: '', senderRef: '', office: '', officeOther: '', desc: '', assignee: '', file: null
});

function LogForm({ user, users, offices, onChanged }) {
  const { toast, run } = useToast();
  const [f, setF] = useState(emptyLog());
  const [last, setLast] = useState('');
  const [fileKey, setFileKey] = useState(0);
  const up = k => v => setF(x => ({ ...x, [k]: v }));
  const isBill = f.itemType === 'Bill';

  async function submit() {
    const t = f.senderType;
    const data = {
      itemType: f.itemType, dateReceived: f.dateReceived, senderReferenceDate: f.senderDate, senderType: t,
      vendorName: t === 'NonUEEmployee' ? f.nonueName.trim() : f.vendorName.trim(), cnic: f.cnic.trim(), employeeId: f.employeeId.trim(),
      senderOfficeName: f.officeName.trim(), senderReferenceNo: f.senderRef.trim(), originatingOfficeId: f.office, originatingOfficeOther: f.officeOther.trim(),
      roughDescription: f.desc.trim(), assignedTo: f.assignee, amount: isBill ? f.amount : '', billType: isBill ? f.billType : ''
    };
    const bad = m => { toast(m, 'error'); };
    if (t === 'Vendor' && !data.vendorName) return bad('Enter the Vendor Name.');
    if (t === 'Employee' && !data.employeeId) return bad('Enter the Employee ID.');
    if (t === 'NonUEEmployee' && (!data.vendorName || !data.cnic)) return bad('Enter both the Non-UE Employee Name and CNIC.');
    if (t === 'Office' && !data.senderOfficeName) return bad('Enter the Sender Office Name.');
    if (!data.dateReceived) return bad('Date Received is required.');
    if (!data.senderReferenceDate) return bad("Sender's Diary / Letter Date is required.");
    if (!data.senderReferenceNo) return bad('Reference / Diary No. of the Sender is required.');
    if (!data.roughDescription) return bad('Description is required.');
    if (isBill && !(Number(data.amount) > 0)) return bad('Enter the Amount of the bill.');
    if (isBill && !data.billType) return bad('Select Single bill or Bulk bill.');
    if (!data.originatingOfficeId) return bad('Select the Originating Office (or Others).');
    if (data.originatingOfficeId === '__others__' && !data.originatingOfficeOther) return bad('Enter the Originating Office name.');
    if (!data.assignedTo) return bad('Assign this item to someone.');
    if (!isBill) { try { const att = await readAttachment(f.file); if (att) data.attachment = att; } catch (e) { return bad(e.message); } }

    const res = await run(() => gs('createDiaryEntry', data, user.username), 'Logging...', 'Item logged and assigned.');
    if (res && res.success) {
      setF(x => ({ ...emptyLog(), itemType: x.itemType, dateReceived: x.dateReceived, senderType: x.senderType }));
      setFileKey(k => k + 1);
      setLast('Logged as ' + res.diaryId + ' - write this on the physical item.');
      if (res.attachmentWarning) toast(res.attachmentWarning, 'error');
      onChanged();
    }
  }
  const t = f.senderType;
  return (
    <div className="card" id="dysub-log">
      <h3>Log a New Bill or Letter <span className="pill Received">Stage 0</span></h3>
      <p style={note}>Record that something physically arrived and assign it to whoever should act on it. A Bill then follows the normal Entry &rarr; Processing &rarr; Passing &rarr; Payment pipeline; a Letter instead moves person to person until someone closes or files it.</p>
      <div className="row" style={{ alignItems: 'center' }}>
        <label style={radioLbl}><input type="radio" name="dyItemType" value="Bill" style={{ width: 'auto' }} checked={isBill} onChange={() => up('itemType')('Bill')} /> Bill</label>
        <label style={radioLbl}><input type="radio" name="dyItemType" value="Letter" style={{ width: 'auto' }} checked={!isBill} onChange={() => up('itemType')('Letter')} /> Letter</label>
      </div>
      {isBill && <div className="row">
        <F label="Amount (Gross) *" max={240}><input type="number" id="dy_amount" min="1" placeholder="Amount on the bill" value={f.amount} onChange={e => up('amount')(e.target.value)} /></F>
        <F label="Bill Type *">
          <div style={{ display: 'flex', gap: 18, alignItems: 'center', paddingTop: 8 }}>
            <label style={radioLbl}><input type="radio" name="dyBillType" value="Single" style={{ width: 'auto' }} checked={f.billType === 'Single'} onChange={() => up('billType')('Single')} /> Single bill</label>
            <label style={radioLbl}><input type="radio" name="dyBillType" value="Bulk" style={{ width: 'auto' }} checked={f.billType === 'Bulk'} onChange={() => up('billType')('Bulk')} /> Bulk bill (multiple beneficiaries)</label>
          </div>
        </F>
      </div>}
      {!isBill && <div className="row"><FileInput label="Attach the Letter (PDF or JPEG, max 5 MB - optional)" resetKey={fileKey} onFile={up('file')} /></div>}
      <div className="row">
        <F label="Date Received"><input type="date" id="dy_date" value={f.dateReceived} onChange={e => up('dateReceived')(e.target.value)} /></F>
        <F label="Sender's Diary / Letter Date"><input type="date" id="dy_senderDate" value={f.senderDate} onChange={e => up('senderDate')(e.target.value)} /></F>
        <F label="Sender Is">
          <Sel id="dy_senderType" v={t} set={up('senderType')}>
            <option value="Vendor">Vendor</option><option value="Employee">UE Employee</option><option value="NonUEEmployee">Non-UE Employee</option><option value="Office">Another Office</option>
          </Sel>
        </F>
        {t === 'Vendor' && <F label="Vendor Name"><Txt id="dy_vendorName" v={f.vendorName} set={up('vendorName')} /></F>}
        {t === 'Employee' && <F label="Employee ID"><Txt id="dy_employeeId" v={f.employeeId} set={up('employeeId')} /></F>}
        {t === 'NonUEEmployee' && <F label="Non-UE Employee Name"><Txt id="dy_nonueName" v={f.nonueName} set={up('nonueName')} /></F>}
        {t === 'NonUEEmployee' && <F label="Non-UE Employee CNIC"><Txt id="dy_nonueCnic" v={f.cnic} set={up('cnic')} placeholder="35201-1222334-4" /></F>}
        {t === 'Office' && <F label="Sender Office Name"><Txt id="dy_senderOfficeName" v={f.officeName} set={up('officeName')} /></F>}
      </div>
      <div className="row">
        <F label="Reference / Diary No. of the Sender"><Txt id="dy_senderRef" v={f.senderRef} set={up('senderRef')} placeholder="Their own dispatch/diary number, if any" /></F>
        <F label="Originating Office">
          <Sel id="dy_originatingOffice" v={f.office} set={up('office')}>
            <option value="">-- select --</option>{offices.map(o => <option key={o.OfficeID} value={o.OfficeID}>{o.OfficeName}</option>)}<option value="__others__">Others (type name)</option>
          </Sel>
        </F>
        {f.office === '__others__' && <F label="Originating Office Name"><Txt id="dy_originatingOther" v={f.officeOther} set={up('officeOther')} /></F>}
        <F label="Description"><Txt id="dy_desc" v={f.desc} set={up('desc')} placeholder="e.g. Electricity bill, Request for leave" /></F>
      </div>
      <div className="row">
        <F label="Assign To"><Sel id="dy_assignee" v={f.assignee} set={up('assignee')}><option value="">-- select --</option>{users.map(u => <option key={u.Username} value={u.Username}>{u.FullName}</option>)}</Sel></F>
        <F end><button className="primary" id="btnLogDiary" onClick={submit}>Log &amp; Assign</button></F>
      </div>
      <div id="dy_lastId" style={{ fontSize: 13, color: 'var(--accent)', fontWeight: 700 }}>{last}</div>
    </div>
  );
}

/* ================= Diary Clerk: Pending Diary Items ================= */
const PD_COLUMNS = [
  ['diaryId', 'DN / Bill / Letter No.'], ['dateReceived', 'Date Received'], ['itemType', 'Type'], ['sender', 'Sender'], ['employeeId', 'Employee ID'],
  ['description', 'Description'], ['amount', 'Amount'], ['office', 'Originating Office'], ['assignedTo', 'Assigned To'], ['stage', 'Stage'],
  ['daysAtStage', 'Days at Stage'], ['daysWaiting', 'Days Since Arrival'], ['action', 'Action']
];
const PD_DEFAULT = ['diaryId', 'dateReceived', 'itemType', 'sender', 'description', 'amount', 'office', 'assignedTo', 'stage', 'daysAtStage', 'daysWaiting', 'action'];
const PD_KEY = 'dy_pending_columns_v1';
function savedColumns() {
  try { const s = JSON.parse(localStorage.getItem(PD_KEY) || 'null'); if (Array.isArray(s) && s.length) return s; } catch (e) {}
  return PD_DEFAULT.slice();
}

function Pending({ user, users, offices, onTrail, onOpenBill, onChanged }) {
  const { toast, run } = useToast();
  const [q, setQ] = useState({ user: '', office: '', query: '', empId: '', desc: '', amount: '', only10: true });
  const [rows, setRows] = useState(null);
  const [summary, setSummary] = useState(null);
  const [cols, setCols] = useState(savedColumns);
  const [picker, setPicker] = useState(false);
  const [exportStage, setExportStage] = useState('');
  const up = k => v => setQ(x => ({ ...x, [k]: v }));
  const setColumns = list => { const l = list.length ? list : PD_DEFAULT.slice(); setCols(l); try { localStorage.setItem(PD_KEY, JSON.stringify(l)); } catch (e) {} };

  async function load() {
    const filters = { assignedTo: q.user, originatingOfficeId: q.office, query: q.query.trim(), employeeId: q.empId.trim(), description: q.desc.trim(), amount: q.amount.trim(), minDaysWaiting: q.only10 ? 10 : 0 };
    setRows(null);
    const list = await gs('getPendingDiaryItems', filters, user.username).catch(e => { toast(e.message, 'error'); return []; });
    setRows(list || []);
    if (filters.assignedTo) setSummary(await gs('getUserDiaryStageSummary', filters.assignedTo).catch(() => [])); else setSummary(null);
  }
  async function download() {
    if (!q.user) { toast('Select a user first.', 'error'); return; }
    const list = await gs('getUserDiarySummaryForExport', q.user, exportStage, user.username).catch(e => { toast(e.message, 'error'); return null; });
    if (!list) return;
    if (!list.length) { toast('Nothing to export for this selection.', 'error'); return; }
    exportCSV(list.map(r => ({ ...r, dateReceived: fmtDate(r.dateReceived) })), [['diaryId', 'Diary Number'], ['itemType', 'Type'], ['dateReceived', 'Date Received'], ['senderLabel', 'Sender'],
      ['originatingOffice', 'Originating Office'], ['stageLabel', 'Stage'], ['daysWaiting', 'Days Waiting']], 'Diary_Summary_' + q.user + (exportStage !== '' ? '_stage' + exportStage : '') + '.csv');
  }
  async function adminReassign(diaryId) {
    const names = users.map(u => u.Username + ' (' + u.FullName + ')').join(', ');
    const nu = window.prompt('Reassign ' + diaryId + ' to (type exact username):\n\nAvailable: ' + names);
    if (!nu) return;
    const reason = window.prompt('Reason (kept on the audit trail):') || '';
    const res = await run(() => gs('adminReassignAny', diaryId, nu.trim(), reason, user.username), 'Reassigning...', 'Reassigned.');
    if (res && res.success) { onChanged(); load(); }
  }
  const visible = PD_COLUMNS.filter(c => cols.includes(c[0]));
  const cell = (r, key) => {
    switch (key) {
      case 'diaryId': return <td className="nowrap"><DiaryLink id={r.diaryId} onTrail={onTrail} />{r.linkedEntryId && <> / <BillLink id={r.linkedEntryId} onOpen={onOpenBill} /></>}</td>;
      case 'dateReceived': return <td className="nowrap">{fmtDate(r.dateReceived)}</td>;
      case 'itemType': return <td>{typeLabel(r)}</td>;
      case 'sender': return <td>{r.senderLabel}</td>;
      case 'employeeId': return <td>{r.employeeId || ''}</td>;
      case 'description': return <td style={{ minWidth: 150 }}>{r.roughDescription}</td>;
      case 'amount': return <td className="num">{r.amount != null ? num(r.amount) : ''}</td>;
      case 'office': return <td>{r.originatingOffice || '-'}</td>;
      case 'assignedTo': return <td>{r.assignedTo}</td>;
      case 'stage': return <td><StagePill stage={r.stage}>{r.stage} - {r.stageLabel}</StagePill>{r.isHeld && <span style={{ color: 'var(--amber)', fontSize: 10.5 }}> (resume from Returned / Sent tabs)</span>}</td>;
      case 'daysAtStage': return <td className="num"><Days d={r.daysAtCurrentStage} /></td>;
      case 'daysWaiting': return <td className="num"><Days d={r.daysWaiting} /></td>;
      case 'action': return <td>{(user.role === 'Admin' && !r.isHeld) && <button className="secondary" style={{ padding: '1px 6px', fontSize: 10.5, minHeight: 0 }} onClick={() => adminReassign(r.diaryId)}>Admin Reassign</button>}</td>;
      default: return <td></td>;
    }
  };
  return (
    <div className="card" id="dysub-pending">
      <h3>Pending Diary Items</h3>
      <p style={note}>Shows items still open (not yet paid-and-confirmed / closed), waiting more than 10 days by default - untick below to see everything. Only its current holder can move a Bill/Letter onward, but the "Admin Reassign" button on each row lets Admin re-route any open item with the full trail preserved. Returned / sent-out items are resumed only from the two sections next to this one (Diary Clerk/Admin).</p>
      <div className="row">
        <F label="Select User" max={220}><Sel id="dy_pendingUser" v={q.user} set={up('user')}><option value="">-- All Users --</option>{users.map(u => <option key={u.Username} value={u.Username}>{u.FullName}</option>)}</Sel></F>
        <F label="Originating Office"><Sel id="dy_pendingOffice" v={q.office} set={up('office')}><option value="">All Offices</option>{offices.map(o => <option key={o.OfficeID} value={o.OfficeID}>{o.OfficeName}</option>)}</Sel></F>
        <F label="Vendor/Employee/Diary No. contains"><Txt id="dy_pendingQuery" v={q.query} set={up('query')} /></F>
        <F end><label style={radioLbl}><input type="checkbox" id="dy_only10days" style={{ width: 'auto' }} checked={q.only10} onChange={e => up('only10')(e.target.checked)} /> Only &gt; 10 days waiting</label></F>
        <F end><button className="primary" onClick={load}>Load</button></F>
      </div>
      <div className="row">
        <F label="Employee ID contains"><Txt v={q.empId} set={up('empId')} /></F>
        <F label="Description contains"><Txt v={q.desc} set={up('desc')} /></F>
        <F label="Amount contains"><Txt v={q.amount} set={up('amount')} /></F>
        <F end><button className="secondary" onClick={() => setPicker(p => !p)}>Columns</button> <button className="primary" onClick={load}>Load</button></F>
      </div>
      {picker && <div style={{ marginBottom: 10 }}>
        <label>Columns to show (remembered in this browser)
          <button className="secondary" style={{ padding: '2px 10px', minHeight: 0, marginLeft: 8 }} onClick={() => setColumns(PD_DEFAULT.slice())}>Reset to default</button></label>
        <div className="checklist">{PD_COLUMNS.map(c => <label key={c[0]}><input type="checkbox" checked={cols.includes(c[0])} onChange={e => setColumns(e.target.checked ? PD_COLUMNS.map(x => x[0]).filter(k => cols.includes(k) || k === c[0]) : cols.filter(k => k !== c[0]))} /> {c[1]}</label>)}</div>
      </div>}
      {rows && <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{rows.length} item(s) shown.</div>}
      {summary && <div style={{ marginTop: 10 }}>
        <h4 style={h4}>Selected User's Position (Stages 0-7)</h4>
        <StageBoxes counts={summary} />
        <div className="row" style={{ marginTop: 10 }}>
          <F label="Download Which Stage" max={260}>
            <Sel v={exportStage} set={setExportStage}>
              <option value="">All Stages</option><option value="0">0 - Diary Pending</option><option value="1">1 - Processing</option><option value="2">2 - Passing</option>
              <option value="3">3 - Payment/IBFT</option><option value="4">4 - Confirmation</option><option value="5">5 - Reconciliation</option><option value="6">6 - Paid / Completed</option><option value="7">7 - Returned / On Hold</option>
            </Sel>
          </F>
          <F end><button className="secondary" onClick={download}>Download CSV</button> <button className="secondary" onClick={() => window.print()}>Print / Save as PDF</button></F>
        </div>
      </div>}
      <div className="table-wrap" style={{ marginTop: 10 }}>
        <table id="pendingDiaryTable">
          <thead><tr>{visible.map(c => <th key={c[0]}>{c[1]}</th>)}</tr></thead>
          <tbody>
            {rows === null ? <EmptyRow cols={visible.length} text="Set filters above and click Load." />
              : rows.length ? rows.map(r => <tr key={r.diaryId}>{visible.map(c => React.cloneElement(cell(r, c[0]), { key: c[0] }))}</tr>)
              : <EmptyRow cols={visible.length} text="No items found." />}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ================= Diary Clerk: Returned / On Hold  +  Sent to Other Offices ================= */
function Held({ which, user, onTrail, onOpenBill, onChanged }) {
  const { toast } = useToast();
  const [res, setRes] = useState(null);
  const [resume, setResume] = useState(null);
  const load = useCallback(async () => {
    setRes(await gs('getHeldItemsForController', user.username).catch(e => { toast(e.message, 'error'); return null; }));
  }, [user.username]);   // eslint-disable-line
  useEffect(() => { load(); }, [load]);
  const idCell = r => <>{r.diaryId && <DiaryLink id={r.diaryId} onTrail={onTrail} />}{r.linkedEntryId && <>{r.diaryId ? ' / ' : ''}<BillLink id={r.linkedEntryId} onOpen={onOpenBill} /></>}</>;
  const btn = r => <button className="primary" onClick={() => setResume({ diaryId: r.diaryId || '', entryId: r.linkedEntryId || '' })}>Re-assign &amp; Resume</button>;
  const returned = which === 'held';
  return (
    <div className="card" id={'dysub-' + which}>
      {returned ? <>
        <h3>Returned / On Hold Bills <span className="pill Cancelled">Needs Correction Before Resuming</span></h3>
        <p style={note}>Everything a user has returned - before a Bill ID exists (Diary stage) or at Processing/Passing stage. Whoever returned it keeps a view-only record. Only you (Diary Clerk/Admin) can re-assign it to the relevant person and resume it: a bill continues exactly at the stage it left, nothing is re-entered.</p>
      </> : <>
        <h3>Items Sent to Other Offices <span className="pill Received">Awaiting Re-assignment</span></h3>
        <p style={note}>Items a user sent to another office. Whoever sent it keeps a view-only record (a sent bill is held out of Processing/Passing). When it comes back, re-assign it here to the relevant person to resume it.</p>
      </>}
      <button className="secondary" onClick={load}>Reload</button>
      <div className="table-wrap" style={{ marginTop: 10 }}>
        {returned ? (
          <table id="onHoldTable">
            <thead><tr><th>DN / Bill ID</th><th>Type</th><th>Stage</th><th>Reason</th><th>Returned By</th><th>Date</th><th>Sender / Description</th><th></th></tr></thead>
            <tbody>{!res ? <EmptyRow cols={8} text="Loading..." /> : (res.returned || []).length ? res.returned.map((r, i) => <tr key={i}>
              <td>{idCell(r)}</td><td>{typeLabel(r)}</td><td>{r.stageLabel}</td><td>{r.reason}</td><td>{r.heldBy}</td><td>{fmtDate(r.heldDate)}</td>
              <td>{r.sender}{r.description ? ' - ' + r.description : ''}{r.amount != null ? ' (' + num(r.amount) + ')' : ''}</td><td>{btn(r)}</td></tr>) : <EmptyRow cols={8} text="Nothing is on hold." />}</tbody>
          </table>
        ) : (
          <table id="sentOfficeTable">
            <thead><tr><th>DN / Bill ID</th><th>Type</th><th>Sender</th><th>Sent To Office</th><th>Purpose</th><th>Sent By</th><th>Date</th><th></th></tr></thead>
            <tbody>{!res ? <EmptyRow cols={8} text="Loading..." /> : (res.sent || []).length ? res.sent.map((r, i) => <tr key={i}>
              <td>{idCell(r)}</td><td>{typeLabel(r)}</td><td>{r.sender}</td><td>{r.officeName}</td><td>{r.reason}</td><td>{r.heldBy}</td><td>{fmtDate(r.heldDate)}</td><td>{btn(r)}</td></tr>) : <EmptyRow cols={8} text="Nothing has been sent to another office." />}</tbody>
          </table>
        )}
      </div>
      {resume && <ResumeModal item={resume} user={user} onClose={() => setResume(null)} onDone={() => { setResume(null); load(); onChanged(); }} />}
    </div>
  );
}

/* ================= User workspace ================= */
function MyPosition({ user }) {
  const [s, setS] = useState(null);
  useEffect(() => { gs('getUserDiaryStageSummary', user.username).then(setS).catch(() => setS([])); }, [user.username]);
  return (
    <div className="card" id="dysub-mypos">
      <h3>My Diary Position</h3>
      <p style={note}>Everything currently assigned to you, stage by stage.</p>
      <div id="dy_myStageBoxes">{s ? <StageBoxes counts={s} /> : 'Loading...'}</div>
    </div>
  );
}

function MyQueue({ user, offices, canEnter, onTrail, onOpenBill, onEnterBill, onChanged }) {
  const { toast } = useToast();
  const [f, setF] = useState({ office: '', query: '' });
  const [list, setList] = useState(null);
  const [modal, setModal] = useState(null);
  const load = useCallback(async (filters) => {
    const x = filters || f;
    setList(await gs('getUserDiaryQueue', user.username, { originatingOfficeId: x.office, query: x.query.trim() }).catch(e => { toast(e.message, 'error'); return []; }));
  }, [user.username, f]);   // eslint-disable-line
  useEffect(() => { load(); }, []);   // eslint-disable-line
  const done = () => { setModal(null); load(); onChanged(); };
  function actions(r) {
    const bl = r.linkedEntryId ? <><BillLink id={r.linkedEntryId} onOpen={onOpenBill} />{' '}</> : null;
    const sec = (text, fn) => <button className="secondary" onClick={fn}>{text}</button>;
    if (r.isHeld) return <>{bl}<span style={{ color: 'var(--amber)', fontSize: 12 }}>View only - Diary Clerk/Admin will re-assign</span></>;
    if (r.itemType === 'Bill' && r.status === 'Pending' && !r.linkedEntryId) return <>
      {canEnter && <button className="primary" onClick={() => onEnterBill(r.diaryId)}>Enter This Bill</button>}{' '}
      {sec('Return', () => setModal({ k: 'billReturn', id: r.diaryId }))}{' '}{sec('Reassign', () => setModal({ k: 'reassign', id: r.diaryId, kind: 'Bill' }))}</>;
    if (r.itemType === 'Letter' && r.status === 'Pending') return <>
      <button className="primary" onClick={() => setModal({ k: 'letter', id: r.diaryId })}>Process Letter</button>{' '}{sec('Reassign', () => setModal({ k: 'reassign', id: r.diaryId, kind: 'Letter' }))}</>;
    if (r.linkedEntryId && r.stage >= 1 && r.stage <= 2) return <>{bl}{sec('Return', () => setModal({ k: 'holdReturn', id: r.linkedEntryId }))}{' '}{sec('Reassign', () => setModal({ k: 'reassign', id: r.linkedEntryId, kind: 'Bill' }))}</>;
    return bl;
  }
  return (
    <div className="card" id="dysub-myqueue">
      <h3>My Diary Queue <button className="secondary" onClick={() => load()}>Refresh</button></h3>
      <p style={note}>Items you returned or sent to another office stay here as view-only until the Diary Clerk/Admin re-assigns them.</p>
      <div className="row">
        <F label="Originating Office"><Sel id="dy_myOffice" v={f.office} set={v => setF({ ...f, office: v })}><option value="">All Offices</option>{offices.map(o => <option key={o.OfficeID} value={o.OfficeID}>{o.OfficeName}</option>)}</Sel></F>
        <F label="Vendor/Employee/Diary No. contains"><Txt id="dy_myQuery" v={f.query} set={v => setF({ ...f, query: v })} /></F>
        <F end><button className="secondary" onClick={() => load()}>Filter</button></F>
      </div>
      <div className="table-wrap" style={{ marginTop: 10 }}>
        <table id="myDiaryQueueTable">
          <thead><tr><th>DN / Bill / Letter No.</th><th>Type</th><th>Date Received</th><th>Days at Stage</th><th>Days Since Arrival</th><th>Sender</th><th>Description</th><th>Amount</th><th>Originating Office</th><th>Stage</th><th></th></tr></thead>
          <tbody>
            {list === null ? <EmptyRow cols={11} text="Loading..." /> : list.length ? list.map(r => <tr key={r.diaryId}>
              <td><DiaryLink id={r.diaryId} onTrail={onTrail} /></td><td>{typeLabel(r)}</td><td>{fmtDate(r.dateReceived)}</td>
              <td><Days d={r.daysAtCurrentStage} /></td><td><Days d={r.daysWaiting} /></td><td>{r.senderLabel}</td><td>{r.roughDescription}</td>
              <td>{r.amount != null ? num(r.amount) : ''}</td><td>{r.originatingOffice || '-'}</td><td><StagePill stage={r.stage}>{r.stageLabel}</StagePill></td><td>{actions(r)}</td></tr>)
              : <EmptyRow cols={11} text="Nothing is assigned to you right now." />}
          </tbody>
        </table>
      </div>
      {modal && modal.k === 'billReturn' && <BillReturnModal diaryId={modal.id} user={user} onClose={() => setModal(null)} onDone={done} />}
      {modal && modal.k === 'holdReturn' && <BillHoldReturnModal entryId={modal.id} user={user} onClose={() => setModal(null)} onDone={done} />}
      {modal && modal.k === 'reassign' && <ReassignModal item={modal} user={user} onClose={() => setModal(null)} onDone={done} />}
      {modal && modal.k === 'letter' && <LetterModal diaryId={modal.id} user={user} onClose={() => setModal(null)} onDone={done} />}
    </div>
  );
}

/* ================= the Diary tab ================= */
export default function Diary({ user, canEnter, onOpenBill, onEnterBill, onChanged }) {
  const isClerk = user.role === 'DiaryClerk' || user.role === 'Admin';
  const isUser = user.role !== 'DiaryClerk';
  const items = [];
  if (isClerk) items.push(['log', 'Log New Bill / Letter'], ['pending', 'Pending Diary Items'], ['held', 'Returned / On Hold'], ['sent', 'Sent to Other Offices']);
  if (isUser) items.push(['mypos', 'My Diary Position'], ['myqueue', 'My Diary Queue']);
  const [sub, setSub] = useState(items[0][0]);
  const [users, setUsers] = useState([]);
  const [offices, setOffices] = useState([]);
  const [trail, setTrail] = useState(null);
  useEffect(() => {
    gs('getReceivingOffices').then(setOffices).catch(() => {});
    if (isClerk) gs('getDiaryEligibleUsers').then(setUsers).catch(() => {});
  }, [isClerk]);

  const common = { user, onTrail: setTrail, onOpenBill, onChanged };
  return (
    <div id="tab-diary" className="tabpanel active">
      <nav className="subtabs no-print" id="dy_subnav">
        {items.map(i => <button key={i[0]} className={'sub-btn' + (sub === i[0] ? ' active' : '')} data-sub={i[0]} onClick={() => setSub(i[0])}>{i[1]}</button>)}
      </nav>
      {sub === 'log' && <LogForm user={user} users={users} offices={offices} onChanged={onChanged} />}
      {sub === 'pending' && <Pending {...common} users={users} offices={offices} />}
      {(sub === 'held' || sub === 'sent') && <Held key={sub} which={sub} {...common} />}
      {sub === 'mypos' && <MyPosition user={user} />}
      {sub === 'myqueue' && <MyQueue {...common} offices={offices} canEnter={canEnter} onEnterBill={onEnterBill} />}
      {trail && <DiaryTrail diaryId={trail} onClose={() => setTrail(null)} />}
    </div>
  );
}
