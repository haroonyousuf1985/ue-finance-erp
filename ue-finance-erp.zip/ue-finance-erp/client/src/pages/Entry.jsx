import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { gs } from '../api.js';
import { DEFAULT_FY, fmtDate, fyOptions, num, exportCSV } from '../util.js';
import { useToast, EmptyRow, Modal } from '../ui.jsx';
import {
  VENDOR_BILL_NATURES, UE_EMPLOYEE_BILL_NATURES, NONUE_EMPLOYEE_BILL_NATURES, STUDENT_BILL_NATURES, VENDOR_SERVICE_CATEGORIES,
  REFUND_CATEGORIES, BENEVOLENT_SUBS, VISITING_NATURES, natureFlags, applyNature, blankForm, taxParams, payeeName, incomeKey,
  formFromBill, parseCSV, parseBulkRows, BULK_HINTS, BULK_TEMPLATES, isValidCnic, isValidCnicOrNtn, isValidIban
} from '../entryData.js';

/* 1. New Entry - single bill (all four payee types, multi-head, live tax preview, edit mode) and bulk CSV upload. */
const FYS = fyOptions();
const note = { fontSize: 12.5, color: 'var(--text-muted)' };
const radioLbl = { display: 'flex', alignItems: 'center', gap: 6, fontWeight: 'normal' };
const R = { width: 'auto' };
const F = ({ label, children, end, max, wide, rel, hidden }) => hidden ? null : (
  <div className={'field' + (wide ? ' field-wide' : '')} style={{ ...(end ? { alignSelf: 'flex-end' } : {}), ...(max ? { maxWidth: max } : {}), ...(rel ? { position: 'relative' } : {}) }}>{label && <label>{label}</label>}{children}</div>
);
const pct = r => r ? (r * 100).toFixed(2) + '%' : '-';

function NatureOptions({ groups }) {
  return <>
    <option value="">-- Select --</option>
    {groups.map((g, i) => g.group
      ? <optgroup key={i} label={g.group}>{g.options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</optgroup>
      : g.options.map(([v, l]) => <option key={v} value={v}>{l}</option>))}
  </>;
}

/* One deduction line: tick box, optional text boxes, "By %" / "By Amount", then the rate or the amount. */
function Ded({ label, d, set, onToggle, texts = [] }) {
  const isAmt = d.mode === 'amount';
  return (
    <div className="row" style={{ alignItems: 'center' }}>
      <label style={{ ...radioLbl, ...(label.flex ? { flex: 1 } : {}) }}><input type="checkbox" style={R} checked={d.on} onChange={e => onToggle(e.target.checked)} /> {label.text}</label>
      {texts.map(([k, l]) => <F key={k} label={l}><input type="text" disabled={!d.on} value={d[k] || ''} onChange={e => set({ [k]: e.target.value })} /></F>)}
      <F label="Mode" max={110}><select disabled={!d.on} value={d.mode} onChange={e => set({ mode: e.target.value })}><option value="rate">By %</option><option value="amount">By Amount</option></select></F>
      {!isAmt && <F label="Rate %"><input type="number" step="0.01" disabled={!d.on} value={d.rate} onChange={e => set({ rate: e.target.value })} /></F>}
      {isAmt && <F label="Amount"><input type="number" disabled={!d.on} value={d.amount} onChange={e => set({ amount: e.target.value })} /></F>}
    </div>
  );
}

export default function Entry({ user, request, onSaved, onOpenDiaryTrail }) {
  const { toast, run } = useToast();
  const [f, setF] = useState(blankForm);
  const [campuses, setCampuses] = useState([]);
  const [offices, setOffices] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [heads, setHeads] = useState([]);
  const [headsLoaded, setHeadsLoaded] = useState(false);
  const [budget, setBudget] = useState(null);
  const [budgetTick, setBudgetTick] = useState(0);
  const [tax, setTax] = useState(null);
  const [sugg, setSugg] = useState([]);
  const [held, setHeld] = useState(0);
  const [diary, setDiary] = useState(null);           // { id, banner }
  const [bypass, setBypass] = useState({ on: false, reason: '' });
  const [editId, setEditId] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [candidates, setCandidates] = useState([]);
  const [picked, setPicked] = useState(() => new Set());
  const [bulk, setBulk] = useState({ type: 'Vendor', desc: '', pstNo: '', pstDate: '', items: [], errors: [] });
  const [fileKey, setFileKey] = useState(0);
  const timers = useRef({});
  const up = k => v => setF(x => ({ ...x, [k]: v }));
  const upSub = k => patch => setF(x => ({ ...x, [k]: { ...x[k], ...patch } }));
  const debounce = (name, ms, fn) => { clearTimeout(timers.current[name]); timers.current[name] = setTimeout(fn, ms); };

  const n = natureFlags(f.payeeType, f.nature, f.nonueMethod);
  const isBulk = f.entryMode === 'bulk';
  const isAdmin = user.role === 'Admin';

  /* ----- dropdown lists ----- */
  useEffect(() => {
    gs('getCampuses').then(setCampuses).catch(() => {});
    gs('getReceivingOffices').then(setOffices).catch(() => {});
    gs('getBankAccounts').then(setAccounts).catch(() => {});
  }, []);

  /* budget heads of the chosen campus + year */
  useEffect(() => {
    setHeadsLoaded(false);
    if (!f.campus) { setHeads([]); return; }
    let dead = false;
    gs('getHeadsForCampus', f.campus, f.fy || DEFAULT_FY).then(list => {
      if (dead) return;
      setHeads(list); setHeadsLoaded(true);
      setF(x => ({ ...x, headId: list.some(h => h.HeadID === x.headId) ? x.headId : '', splits: x.splits.map(s => list.some(h => h.HeadID === s.headId) ? s : { ...s, headId: '' }) }));
    }).catch(() => {});
    return () => { dead = true; };
  }, [f.campus, f.fy]);

  /* allocated / spent / remaining for the chosen head */
  useEffect(() => {
    if (!f.campus || !f.headId) { setBudget(null); return; }
    let dead = false;
    gs('getBudgetStatus', f.campus, f.headId, f.fy || DEFAULT_FY).then(s => { if (!dead) setBudget(s); }).catch(() => {});
    return () => { dead = true; };
  }, [f.campus, f.headId, f.fy, budgetTick]);

  /* live tax preview */
  const paramsKey = JSON.stringify(taxParams(f));
  useEffect(() => {
    const t = setTimeout(() => { gs('previewTaxCalculation', JSON.parse(paramsKey)).then(setTax).catch(() => {}); }, 200);
    return () => clearTimeout(t);
  }, [paramsKey]);

  /* UE employee: look the ID up */
  useEffect(() => {
    if (f.payeeType !== 'Employee') return;
    const id = f.employeeId.trim();
    if (!id) { setF(x => ({ ...x, empName: '', empDesignation: '', empCnic: '', empIban: '', empBank: '', empNotFound: false })); return; }
    const t = setTimeout(() => {
      gs('getEmployeeById', id).then(emp => setF(x => x.employeeId.trim() !== id ? x : (emp
        ? { ...x, empName: emp.Name || '', empDesignation: emp.Designation || '', empCnic: emp.CNIC || '', empIban: emp.IBAN || '', empBank: emp.BankName || '', empNotFound: false }
        : { ...x, empName: '', empDesignation: '', empCnic: '', empIban: '', empBank: '', empNotFound: true }))).catch(() => {});
    }, 250);
    return () => clearTimeout(t);
  }, [f.payeeType, f.employeeId]);

  /* Section 149: annual income already on file */
  const ikey = incomeKey(f);
  useEffect(() => {
    if (!n.is149) return;
    const target = f.payeeType === 'Employee' ? 'annualIncomeUE' : 'annualIncome';
    if (!ikey) { setF(x => ({ ...x, [target]: '' })); return; }
    const t = setTimeout(() => {
      gs('getIncomeProfile', ikey, f.payeeType, f.fy || DEFAULT_FY).then(p => setF(x => ({ ...x, [target]: p ? p.AnnualTaxableIncome : '' }))).catch(() => {});
    }, 300);
    return () => clearTimeout(t);
  }, [n.is149, ikey, f.payeeType, f.fy]);

  /* Release of Security: how much is held for this payee */
  const pname = payeeName(f);
  useEffect(() => {
    if (!n.isRelease) return;
    if (!pname) { setHeld(0); return; }
    const t = setTimeout(() => { gs('getVendorSecurityBalance', pname).then(r => setHeld(Number(r.held) || 0)).catch(() => {}); }, 250);
    return () => clearTimeout(t);
  }, [n.isRelease, pname]);

  /* bulk: Diary bills assigned to this user that could be covered by the same bulk bill */
  const loadCandidates = useCallback(async () => {
    const list = await gs('getUserDiaryQueue', user.username, {}).catch(() => []);
    setCandidates((list || []).filter(r => r.itemType === 'Bill' && r.status === 'Pending' && !r.linkedEntryId && !r.isHeld));
  }, [user.username]);
  useEffect(() => { if (isBulk) loadCandidates(); }, [isBulk, loadCandidates]);

  /* ----- coming from the Diary tab ("Enter This Bill") or from Admin > Manage Entries (Edit) ----- */
  useEffect(() => {
    if (!request || !request.n) return;
    if (request.editId) loadForEdit(request.editId);
    else if (request.diaryId) enterDiaryBill(request.diaryId);
  }, [request && request.n]);   // eslint-disable-line

  async function enterDiaryBill(id) {
    const d = await gs('getDiaryById', id).catch(() => null);
    if (!d) { toast('Could not load this diary item.', 'error'); return; }
    setEditId(null);
    setF(x => {
      let y = { ...x };
      if (d.SenderType === 'Employee') y = applyNature({ ...y, payeeType: 'Employee', nature: '', employeeId: d.EmployeeID || '' });
      else y = applyNature({ ...y, payeeType: 'Vendor', nature: '', vendor: d.SenderType === 'Office' ? (d.SenderOfficeName || '') : (d.VendorName || '') });
      y.billDesc = String(d.RoughDescription || '').slice(0, 40);
      if (d.BillType) {
        y.entryMode = d.BillType === 'Bulk' ? 'bulk' : 'single';
        if (y.entryMode === 'single' && d.Amount) y.amount = d.Amount;
      }
      return y;
    });
    if (d.BillType === 'Bulk') setBulk(b => ({ ...b, desc: String(d.RoughDescription || '').slice(0, 40) }));
    setBypass({ on: false, reason: '' });
    setDiary({ id, banner: 'Entering ' + id + ' - logged ' + fmtDate(d.DateReceived) + ' by ' + d.LoggedBy + '. Diary says: ' + (d.BillType || 'type not stated') + (d.Amount ? ', amount ' + num(d.Amount) : '') + '. Sender/description are pre-filled and can be changed.' });
    toast('Pre-filled from ' + id + ' - review and complete the rest of the form, then Save.', 'success');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function loadForEdit(entryId) {
    const res = await gs('getBillDetail', entryId).catch(e => ({ success: false, message: e.message }));
    if (!res || res.success === false) { toast('Could not load this bill for editing.', 'error'); return; }
    const e = res.bill;
    if (e.PayeeType === 'Bulk') { toast('Bulk bills cannot be edited here - Delete (if still Received) or Cancel it instead, then re-upload.', 'error'); return; }
    try {
      setEditId(entryId);
      setDiary(null); setBypass({ on: false, reason: '' });
      setF(x => formFromBill(e, res, { ...blankForm(), shift: 'Morning', receivingOffice: x.receivingOffice, payFrom: x.payFrom }));
      toast('Editing ' + entryId + ' - change what you need and click Update Entry.', 'success');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      toast('This bill loaded only partially (' + (err.message || err) + ') - please review every field carefully before clicking Update Entry.', 'error');
    }
  }

  /* ----- handlers for choices that change other things ----- */
  const setPayeeType = t => setF(x => applyNature({ ...x, payeeType: t, nature: '' }));
  const setNature = v => setF(x => applyNature({ ...x, nature: v }));
  const setNonueMethod = v => setF(x => applyNature({ ...x, nonueMethod: v }));
  const toggle = key => on => setF(x => ({ ...x, [key]: { ...x[key], on, ...(on && (key === 'penalty' || key === 'other') ? { mode: 'amount' } : {}) } }));
  const setApplyST = on => setF(x => ({ ...x, applyST: on, manualST: on ? x.manualST : { ...x.manualST, on: false } }));
  const setApplyPST = on => setF(x => ({ ...x, applyPST: on, manualPST: on ? x.manualPST : { ...x.manualPST, on: false } }));

  function onVendorInput(v) {
    up('vendor')(v);
    if (v.length < 2) { setSugg([]); return; }
    debounce('vendor', 250, () => gs('searchVendors', v).then(setSugg).catch(() => {}));
  }
  function pickVendor(v) { setF(x => ({ ...x, vendor: v.VendorName, cnic: v.CNIC_NTN || '', iban: v.IBAN || '', bank: v.BankName || '' })); setSugg([]); }
  function onCnicBlur() {
    const c = f.cnic.trim(); if (!c) return;
    gs('getVendorByCNIC', c).then(v => { if (v) setF(x => ({ ...x, vendor: v.VendorName, iban: v.IBAN || '', bank: v.BankName || '' })); }).catch(() => {});
  }
  function onNonueCnic(v) {
    up('nonueCnic')(v);
    if (!v.trim()) return;
    debounce('nonue', 300, () => gs('getNonUEEmployeeByCNIC', v.trim()).then(rec => { if (rec) setF(x => ({ ...x, nonueName: rec.Name || '', nonueIban: rec.IBAN || '', nonueBank: rec.BankName || '' })); }).catch(() => {}));
  }
  function onStudentId(v) {
    up('studentId')(v);
    if (!v.trim()) return;
    debounce('student', 300, () => gs('getStudentById', v.trim()).then(rec => {
      if (rec) setF(x => ({ ...x, benTitle: rec.Name || '', studentCnic: rec.CNIC || '', benIban: rec.IBAN || '', program: rec.Program || '', session: rec.Session || '', shift: rec.Shift || x.shift }));
    }).catch(() => {}));
  }
  async function saveIncomeProfile() {
    if (!ikey) { toast('Enter the Employee ID / CNIC first.', 'error'); return; }
    const profile = { key: ikey, payeeType: f.payeeType, fy: f.fy || DEFAULT_FY, name: pname, annualTaxableIncome: f.annualIncome, affidavitLowIncome: f.affidavit };
    const res = await run(() => gs('saveIncomeProfile', user.username, profile), 'Saving income profile...', 'Income profile saved.');
    if (res && res.success) setF(x => ({ ...x }));
  }

  /* head splits */
  const splitList = f.splits.map(s => { const h = heads.find(x => x.HeadID === s.headId); return { headId: s.headId, headCode: h ? h.HeadCode : '', headName: h ? h.HeadName : '', amount: Number(s.amount) || 0 }; }).filter(s => s.headId && s.amount > 0);
  const splitTotal = splitList.reduce((s, x) => s + x.amount, 0);
  const billAmt = Number(f.amount) || 0;
  const setSplit = (i, patch) => setF(x => ({ ...x, splits: x.splits.map((s, j) => j === i ? { ...s, ...patch } : s) }));

  const campusName = (campuses.find(c => c.CampusID === f.campus) || {}).CampusName || '';
  const headSel = heads.find(h => h.HeadID === f.headId);
  const diaryNeeded = () => !(diary && diary.id) && !(bypass.on && bypass.reason.trim());

  /* ----- clear the form after a successful save ----- */
  function resetAfterSave() {
    setEditId(null); setDiary(null); setBypass({ on: false, reason: '' });
    setF(x => applyNature({ ...blankForm(), receivingOffice: x.receivingOffice, payFrom: x.payFrom, date: x.date, fy: x.fy, campus: x.campus, headId: x.headId, payeeType: x.payeeType, nature: x.nature, entryMode: x.entryMode }));
    setBudgetTick(t => t + 1); onSaved && onSaved();
  }

  async function submitSingle() {
    const multi = f.headMode === 'multi';
    const entry = {
      entryDate: f.date, fy: f.fy || DEFAULT_FY, billNo: f.billNo, campusId: f.campus, campusName,
      headId: multi ? '' : f.headId, headCode: multi ? '' : (headSel ? headSel.HeadCode : ''), headName: multi ? '' : (headSel ? headSel.HeadName : ''),
      headSplits: multi ? splitList : [], payeeType: f.payeeType, employeeId: f.employeeId,
      vendorName: f.payeeType === 'NonUEEmployee' ? f.nonueName : f.vendor,
      cnic: f.payeeType === 'NonUEEmployee' ? f.nonueCnic : f.cnic,
      iban: f.payeeType === 'NonUEEmployee' ? f.nonueIban : f.iban,
      bankName: f.payeeType === 'NonUEEmployee' ? f.nonueBank : f.bank,
      studentId: f.studentId, studentCnic: f.studentCnic, program: f.program, session: f.session, shift: f.shift,
      beneficiaryAccountTitle: f.benTitle, beneficiaryIban: f.benIban, amount: f.amount, billDescription: f.billDesc,
      payFromAccountId: f.payFrom, receivingOfficeId: f.receivingOffice, pstInvoiceNo: f.pstInvoiceNo, vendorInvoiceDate: f.vendorInvoiceDate,
      diaryId: (diary && diary.id) || '', diaryBypassReason: bypass.on ? bypass.reason.trim() : '',
      ...taxParams(f)
    };
    const bad = m => { toast(m, 'error'); };
    const pt = f.payeeType;
    if (!entry.receivingOfficeId) return bad('Select the office this bill was received from.');
    if (!entry.payFromAccountId) return bad('Select the bank account this bill is to be paid from.');
    if (!editId && !entry.diaryId && !entry.diaryBypassReason) return bad('A Diary Number is required - go to the Diary tab and click "Enter This Bill" on an item assigned to you (Admin can bypass with a reason).');
    if (pt === 'Vendor' && entry.applyPST && (!entry.pstInvoiceNo || !entry.vendorInvoiceDate)) return bad("Invoice Number and Vendor's Invoice Date are required when Punjab Sales Tax is deducted.");
    if (!entry.campusId || !entry.amount) return bad('Please fill campus and amount.');
    if (!entry.billDescription || !entry.billDescription.trim()) return bad('Bill Description is required.');
    if (!entry.billNature) return bad('Select a Nature of Bill.');
    if (!multi && !entry.headId) return bad('Please select a budget code.');
    if (multi) {
      if (splitList.length < 2) return bad('Add at least two budget heads, each with an amount, for a multi-head bill.');
      if (Math.abs(splitTotal - Number(entry.amount)) > 0.01) return bad('The budget head splits must add up to the bill amount.');
    }
    if (pt === 'Vendor' && !entry.vendorName) return bad('Vendor name is required.');
    if (pt === 'Employee' && !entry.employeeId) return bad('Employee ID is required.');
    if (pt === 'NonUEEmployee' && (!entry.cnic || !entry.vendorName)) return bad('CNIC and Name are required for a Non-UE Employee.');
    if (pt === 'Student' && (!entry.studentId || !entry.beneficiaryAccountTitle)) return bad('Student ID and Beneficiary Account Title are required.');
    if (pt === 'Student' && entry.billNature === 'Refund of Fee' && !entry.refundCategory) return bad(f.refundCat === '__other__' ? 'Enter the Refund Category.' : 'Select a Refund category.');
    const emp = pt === 'Employee' || pt === 'NonUEEmployee';
    if (emp && entry.billNature === 'Conduct of Exam' && !entry.examSubCategory) return bad('Enter the Conduct of Exam sub-category.');
    if (emp && entry.billNature === 'Thesis Evaluation' && (!entry.thesisClass || !entry.thesisStudentName)) return bad('Enter the Class and Student Name for Thesis Evaluation.');
    if (emp && VISITING_NATURES.includes(entry.billNature) && (!entry.visitingProgram || !entry.visitingSubject || !entry.visitingCrHrs || !entry.visitingRate || !entry.visitingLectures)) return bad('Enter Program, Subject, Cr. Hrs., Rate, and Lectures.');
    if (pt === 'Vendor' && entry.cnic && !isValidCnicOrNtn(entry.cnic)) return bad('CNIC/NTN must be a CNIC (35201-1222334-4) or an NTN (12345678).');
    if (pt === 'NonUEEmployee' && !isValidCnic(entry.cnic)) return bad('CNIC must be in the format 35201-1222334-4.');
    if (pt === 'Student' && entry.studentCnic && !isValidCnic(entry.studentCnic)) return bad("Beneficiary's CNIC must be in the format 35201-1222334-4.");
    const ibanToCheck = pt === 'Vendor' ? f.iban : pt === 'NonUEEmployee' ? f.nonueIban : pt === 'Student' ? f.benIban : '';
    if (ibanToCheck && !isValidIban(ibanToCheck)) return bad('IBAN must start with PK and be 24 characters in total (e.g. PK36SCBL0000001123456702).');
    if (pt === 'NonUEEmployee' && !entry.affidavitLowIncome && !f.annualIncome) return bad('Enter the Annual Taxable Income, or check the Affidavit of Low Income box.');

    const res = editId
      ? await run(() => gs('updateEntry', editId, entry, user.username), 'Updating entry...', 'Bill updated.')
      : await run(() => gs('submitEntry', entry, user.username), 'Saving entry...', 'Bill saved with status Received - it is now waiting in the Processing tab.');
    if (res && res.success) { resetAfterSave(); setConfirm(res); }
  }

  /* ----- bulk upload ----- */
  const pickedIds = () => {
    const ids = [];
    if (diary && diary.id) ids.push(diary.id);
    candidates.forEach(r => { if (picked.has(r.diaryId) && !ids.includes(r.diaryId)) ids.push(r.diaryId); });
    return ids;
  };
  function changeBulkType(t) { setBulk(b => ({ ...b, type: t, items: [], errors: [] })); setFileKey(k => k + 1); }
  async function onBulkFile(file) {
    if (!file) return;
    setBulk(b => ({ ...b, items: [], errors: [] }));
    const text = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(new Error('Could not read the file.')); r.readAsText(file); }).catch(e => { toast(e.message, 'error'); return null; });
    if (text === null) return;
    const rows = parseCSV(text);
    if (rows.length < 2) { setBulk(b => ({ ...b, errors: ['CSV has no data rows.'] })); return; }
    const toMap = (list, key) => { const m = {}; (list || []).forEach(x => { if (x[key]) m[String(x[key]).toLowerCase()] = x; }); return m; };
    const t = bulk.type;
    const lookups = { employees: {}, nonue: {}, vendors: {}, students: {}, offices, accounts };
    try {
      if (t === 'Employee') { lookups.employees = toMap(await gs('getAllEmployees'), 'EmployeeID'); lookups.nonue = toMap(await gs('getAllNonUEEmployees'), 'CNIC'); }
      if (t === 'Vendor') lookups.vendors = toMap(await gs('getAllVendors'), 'CNIC_NTN');
      if (t === 'Student') lookups.students = toMap(await gs('getAllStudents'), 'StudentID');
    } catch (e) { toast(e.message, 'error'); return; }
    const { items, errors } = parseBulkRows(rows, t, lookups);
    setBulk(b => ({ ...b, items, errors }));
  }
  const bulkGross = bulk.items.reduce((s, r) => s + r.amount, 0);
  const bulkNet = bulk.items.reduce((s, r) => s + (r.net || 0), 0);
  const diaryTotals = (() => {
    const ids = pickedIds(); let total = 0, any = false;
    ids.forEach(id => { const r = candidates.find(x => x.diaryId === id); if (r && r.amount != null) { total += Number(r.amount); any = true; } });
    return { count: ids.length, total, any };
  })();

  async function submitBulk() {
    if (!bulk.items.length) { toast('Upload a CSV with at least one row first.', 'error'); return; }
    const ids = pickedIds();
    const meta = {
      entryDate: f.date, fy: f.fy || DEFAULT_FY, billNo: f.billNo, campusId: f.campus, campusName,
      headId: f.headId, headCode: headSel ? headSel.HeadCode : '', headName: headSel ? headSel.HeadName : '',
      billDescription: bulk.desc, payFromAccountId: f.payFrom, receivingOfficeId: f.receivingOffice,
      pstInvoiceNo: bulk.pstNo, vendorInvoiceDate: bulk.pstDate,
      diaryId: (diary && diary.id) || '', diaryBypassReason: bypass.on ? bypass.reason.trim() : ''
    };
    if (!meta.diaryBypassReason) {
      if (!meta.diaryId && ids.length) meta.diaryId = ids[0];
      meta.extraDiaryIds = ids.filter(x => x !== meta.diaryId);
    }
    const bad = m => { toast(m, 'error'); };
    if (!meta.diaryId && !meta.diaryBypassReason) return bad('A Diary Number is required - go to the Diary tab and click "Enter This Bill" (Admin can bypass with a reason).');
    if (!meta.campusId || !meta.headId) return bad('Please select campus and budget code (in the fields above).');
    if (!meta.billDescription || !meta.billDescription.trim()) return bad('Bill Description (whole bill) is required.');
    if (bulk.type === 'Vendor') {
      if (!meta.payFromAccountId) return bad('Select the bank account this bill is to be paid from.');
      if (!meta.receivingOfficeId) return bad('Select the office this bill was received from.');
    } else {
      if (!meta.receivingOfficeId && bulk.items.some(li => !li.receivingOfficeId)) return bad('Select a default Receiving Office above, or fill in ReceivingOffice for every row in the CSV.');
      if (!meta.payFromAccountId && bulk.items.some(li => !li.payFromAccountId)) return bad('Select a default Pay From Account above, or fill in PayFromAccount for every row in the CSV.');
    }
    if (bulk.items.some(li => Number(li.pstAmount) > 0) && (!meta.pstInvoiceNo || !meta.vendorInvoiceDate)) return bad("Invoice Number and Vendor's Invoice Date are required - at least one row in this file has Punjab Sales Tax deducted.");
    const over = bulk.items.filter(li => li.__existingMismatch);
    if (over.length && !window.confirm(over.length + ' beneficiary/ies in this file have different Name/IBAN/Bank details than what is already saved (' + over.map(li => li.name).slice(0, 5).join(', ') + (over.length > 5 ? ', ...' : '') + '). Continuing will overwrite the saved details with what is in this file. Continue?')) return;
    const res = await run(() => gs('submitBulkEntry', meta, bulk.items, user.username), 'Uploading bulk bill...', 'Bulk bill saved as one consolidated entry, now waiting in Processing.');
    if (res && res.success) {
      if (res.diaryWarnings && res.diaryWarnings.length) window.alert('Bulk bill saved as ' + res.entryId + '.\n\nDiary check (warning only):\n- ' + res.diaryWarnings.join('\n- '));
      setDiary(null); setPicked(new Set());
      setBulk(b => ({ ...b, items: [], errors: [], desc: '', pstNo: '', pstDate: '' })); setFileKey(k => k + 1);
      loadCandidates(); setBudgetTick(t => t + 1); onSaved && onSaved();
    }
  }

  function cancelEdit() {
    setEditId(null);
    setF(x => applyNature({ ...blankForm(), receivingOffice: x.receivingOffice, payFrom: x.payFrom, date: x.date, fy: x.fy, campus: x.campus }));
    toast('Editing cancelled - the form is empty again.', 'success');
  }

  const natureGroups = n.isStudent ? STUDENT_BILL_NATURES : n.isEmployee ? UE_EMPLOYEE_BILL_NATURES : n.isNonUE ? NONUE_EMPLOYEE_BILL_NATURES : VENDOR_BILL_NATURES;
  const showTaxStatus = !(n.noTax || (n.is149 && !n.nonue153) || n.isSection156);
  const spentAfter = budget ? budget.spent + billAmt : null, remainAfter = budget ? budget.remaining - billAmt : null;
  const relAfter = held - billAmt;

  return (
    <div id="tab-entry" className="tabpanel active">
      <div className="card">
        <h3>New Bill Entry <span className="pill Received">{editId ? 'Editing ' + editId : 'Received'}</span></h3>
        <div className="row" style={{ alignItems: 'center' }}>
          <label style={radioLbl}><input type="radio" name="entryMode" value="single" style={R} checked={!isBulk} onChange={() => up('entryMode')('single')} /> Single Entry</label>
          <label style={radioLbl}><input type="radio" name="entryMode" value="bulk" style={R} checked={isBulk} disabled={!!editId} onChange={() => up('entryMode')('bulk')} /> Bulk Upload (CSV) - multiple beneficiaries under one bill</label>
          {editId && <button className="secondary" onClick={cancelEdit}>Cancel editing</button>}
        </div>

        {diary && <div id="dy_activeBanner" className="success" style={{ display: 'block', marginBottom: 10 }}>{diary.banner}</div>}
        {!editId && diaryNeeded() && <div className="row" style={{ alignItems: 'center' }}><div className="error" style={{ margin: 0 }}>No Diary Number attached yet - go to the Diary tab and click "Enter This Bill" on an item assigned to you.</div></div>}
        {isAdmin && !editId && (
          <div className="row" style={{ alignItems: 'center' }}>
            <label style={radioLbl}><input type="checkbox" id="e_diaryBypass" style={R} checked={bypass.on} onChange={e => { setBypass({ ...bypass, on: e.target.checked }); if (e.target.checked) setDiary(null); }} /> Admin bypass - enter this bill without a Diary Number</label>
            {bypass.on && <F label="Reason (required, kept on the bill's audit record)"><input type="text" id="e_diaryBypassReason" value={bypass.reason} onChange={e => setBypass({ ...bypass, reason: e.target.value })} /></F>}
          </div>
        )}

        <div className="row">
          <F label="Received From (Office)"><select id="e_receivingOffice" value={f.receivingOffice} onChange={e => up('receivingOffice')(e.target.value)}><option value="">-- select --</option>{offices.map(o => <option key={o.OfficeID} value={o.OfficeID}>{o.OfficeName}</option>)}</select></F>
          <F label="Pay From Account"><select id="e_payFromAccount" value={f.payFrom} onChange={e => up('payFrom')(e.target.value)}><option value="">-- select --</option>{accounts.map(a => <option key={a.AccountID} value={a.AccountID}>{a.AccountTitle + ' - ' + a.BankName}</option>)}</select></F>
        </div>
        <div className="row">
          <F label="Entry Date"><input type="date" id="e_date" value={f.date} onChange={e => up('date')(e.target.value)} /></F>
          <F label="Financial Year"><select id="e_fy" value={f.fy} onChange={e => up('fy')(e.target.value)}>{FYS.map(y => <option key={y} value={y}>{y}</option>)}</select></F>
          <F label="Bill / Invoice No."><input type="text" id="e_billno" value={f.billNo} onChange={e => up('billNo')(e.target.value)} /></F>
        </div>
        <div className="row"><F label="Campus / Cost Centre"><select id="e_campus" value={f.campus} onChange={e => up('campus')(e.target.value)}><option value="">-- select --</option>{campuses.map(c => <option key={c.CampusID} value={c.CampusID}>{c.CampusName}</option>)}</select></F></div>

        {!isBulk && <div className="row" style={{ alignItems: 'center' }}>
          <label style={radioLbl}><input type="radio" name="headMode" value="single" style={R} checked={f.headMode === 'single'} onChange={() => up('headMode')('single')} /> Single Budget Head</label>
          <label style={radioLbl}><input type="radio" name="headMode" value="multi" style={R} checked={f.headMode === 'multi'} onChange={() => up('headMode')('multi')} /> Multiple Budget Heads (one bill, several heads)</label>
        </div>}

        {(isBulk || f.headMode === 'single') && <>
          <div className="row">
            <F label="Budget Code"><select id="e_headcode" value={f.headId} onChange={e => up('headId')(e.target.value)}><option value="">-- select --</option>{heads.map(h => <option key={h.HeadID} value={h.HeadID}>{h.HeadCode + ' - ' + h.HeadName}</option>)}</select></F>
            <F label="Budget Head Name (auto)"><input type="text" id="e_headname" readOnly value={headSel ? headSel.HeadName : ''} /></F>
          </div>
          {budget && !isBulk && (
            <div className="balance-box" id="balanceBox">
              <div className="bal-allocated"><span className="label">Allocated</span><span className="val" id="bal_alloc">{budget.allocated.toLocaleString()}</span></div>
              <div className="bal-spent"><span className="label">Spent So Far</span><span className="val" id="bal_spent">{budget.spent.toLocaleString()}</span></div>
              <div className="bal-remaining"><span className="label">Remaining</span><span className="val" id="bal_remain">{budget.remaining.toLocaleString()}</span></div>
              <div className="bal-spent"><span className="label">Spent After This Bill</span><span className="val">{spentAfter.toLocaleString()}</span></div>
              <div className="bal-remaining"><span className="label">Balance After This Bill</span><span className="val" style={{ color: remainAfter < 0 ? 'var(--danger)' : '' }}>{remainAfter.toLocaleString()}</span></div>
            </div>)}
          {budget && !budget.hasAllocation && <div className="error" id="noAllocMsg">No budget allocation set for this campus/budget code/year yet. Ask your Admin to set it up.</div>}
        </>}
        {!isBulk && f.headMode === 'multi' && (
          <div id="multiHeadSection">
            <p style={note}>Split this one bill's amount across several Budget Heads - it still moves through Processing, Passing and Payment as a single bill.</p>
            <div className="table-wrap"><table id="headSplitsTable">
              <thead><tr><th>Budget Head</th><th>Amount</th><th></th></tr></thead>
              <tbody>{f.splits.map((s, i) => (
                <tr key={i}>
                  <td><select className="headSplitHeadSelect" value={s.headId} onChange={e => setSplit(i, { headId: e.target.value })}><option value="">-- select --</option>{heads.map(h => <option key={h.HeadID} value={h.HeadID}>{h.HeadCode + ' - ' + h.HeadName}</option>)}</select></td>
                  <td><input type="number" className="headSplitAmount" value={s.amount} onChange={e => setSplit(i, { amount: e.target.value })} /></td>
                  <td><button type="button" className="secondary" onClick={() => setF(x => ({ ...x, splits: x.splits.filter((_, j) => j !== i) }))}>Remove</button></td>
                </tr>))}</tbody>
            </table></div>
            <button type="button" className="secondary" onClick={() => setF(x => ({ ...x, splits: x.splits.concat({ headId: '', amount: '' }) }))}>+ Add Head</button>
            <div className="balance-box">
              <div className="bal-allocated"><span className="label">Bill Amount</span><span className="val">{num(billAmt)}</span></div>
              <div className="bal-spent"><span className="label">Splits Total</span><span className="val">{num(splitTotal)}</span></div>
              <div className="bal-remaining"><span className="label">Difference</span><span className="val" style={{ color: Math.abs(billAmt - splitTotal) > 0.01 ? 'var(--danger)' : '' }}>{num(billAmt - splitTotal)}</span></div>
            </div>
          </div>
        )}
        {f.campus && headsLoaded && !heads.length && <div className="error" id="noHeadsMsg">This campus has no budget codes allocated for the selected Financial Year. Pick another year, or ask your Admin to add allocations for this one.</div>}

        {/* ================= SINGLE ENTRY ================= */}
        {!isBulk && <div id="singleEntrySection">
          <hr />
          <h3 style={{ marginBottom: 4 }}>Payee</h3>
          <div className="row" style={{ alignItems: 'center' }}>
            {[['Vendor', 'Vendor'], ['Employee', 'UE Employee'], ['NonUEEmployee', 'Non-UE Employee'], ['Student', 'Student']].map(([v, l]) => (
              <label key={v} style={radioLbl}><input type="radio" name="payeeType" value={v} style={R} checked={f.payeeType === v} onChange={() => setPayeeType(v)} /> {l}</label>))}
          </div>

          {f.payeeType === 'Vendor' && <div id="vendorFields" className="row">
            <F label="Vendor Name" rel>
              <input type="text" id="e_vendor" autoComplete="off" value={f.vendor} onChange={e => onVendorInput(e.target.value)} />
              {sugg.length > 0 && <div id="vendorSuggestions" className="vendor-suggestions" style={{ position: 'absolute', width: '100%', zIndex: 10 }}>
                {sugg.map((v, i) => <div key={i} onClick={() => pickVendor(v)}>{v.VendorName} ({v.CNIC_NTN || ''})</div>)}</div>}
            </F>
            <F label="CNIC / NTN"><input type="text" id="e_cnic" maxLength={15} placeholder="35201-1222334-4 or 12345678" value={f.cnic} onChange={e => up('cnic')(e.target.value)} onBlur={onCnicBlur} /></F>
            <F label="IBAN"><input type="text" id="e_iban" value={f.iban} onChange={e => up('iban')(e.target.value)} /></F>
            <F label="Bank Name"><input type="text" id="e_bank" value={f.bank} onChange={e => up('bank')(e.target.value)} /></F>
          </div>}

          {f.payeeType === 'Employee' && <div id="employeeFields">
            <div className="row">
              <F label="Employee ID"><input type="text" id="e_employeeid" autoComplete="off" value={f.employeeId} onChange={e => up('employeeId')(e.target.value)} /></F>
              <F label="Name (auto)"><input type="text" id="e_empname" readOnly value={f.empName} /></F>
              <F label="Designation (auto)"><input type="text" readOnly value={f.empDesignation} /></F>
              <F label="CNIC (auto)"><input type="text" readOnly value={f.empCnic} /></F>
              <F label="IBAN (auto)"><input type="text" readOnly value={f.empIban} /></F>
              <F label="Bank (auto)"><input type="text" readOnly value={f.empBank} /></F>
            </div>
            {f.empNotFound && <div id="employeeNotFound" className="error">Employee ID not found - ask your Admin to add this employee (Admin &gt; Employees).</div>}
          </div>}

          {f.payeeType === 'NonUEEmployee' && <div id="nonUEFields" className="row">
            <F label="CNIC"><input type="text" id="e_nonue_cnic" autoComplete="off" maxLength={15} placeholder="35201-1222334-4" value={f.nonueCnic} onChange={e => onNonueCnic(e.target.value)} /></F>
            <F label="Name"><input type="text" id="e_nonue_name" value={f.nonueName} onChange={e => up('nonueName')(e.target.value)} /></F>
            <F label="IBAN"><input type="text" id="e_nonue_iban" value={f.nonueIban} onChange={e => up('nonueIban')(e.target.value)} /></F>
            <F label="Bank Name"><input type="text" id="e_nonue_bank" value={f.nonueBank} onChange={e => up('nonueBank')(e.target.value)} /></F>
          </div>}

          {f.payeeType === 'Student' && <div id="studentFields">
            <div className="row">
              <F label="Student ID / Form Number"><input type="text" id="e_studentid" autoComplete="off" value={f.studentId} onChange={e => onStudentId(e.target.value)} /></F>
              <F label="Program"><input type="text" id="e_program" value={f.program} onChange={e => up('program')(e.target.value)} /></F>
              <F label="Session"><input type="text" id="e_session" placeholder="e.g. 2023-2027" value={f.session} onChange={e => up('session')(e.target.value)} /></F>
              <F label="Shift"><select id="e_shift" value={f.shift} onChange={e => up('shift')(e.target.value)}><option value="Morning">Morning</option><option value="Evening">Evening</option></select></F>
            </div>
            <div className="row">
              <F label="Beneficiary's CNIC"><input type="text" id="e_studentcnic" maxLength={15} placeholder="35201-1222334-4" value={f.studentCnic} onChange={e => up('studentCnic')(e.target.value)} /></F>
              <F label="Beneficiary's Account Title"><input type="text" id="e_beneficiaryTitle" value={f.benTitle} onChange={e => up('benTitle')(e.target.value)} /></F>
              <F label="Beneficiary's IBAN"><input type="text" id="e_beneficiaryIban" value={f.benIban} onChange={e => up('benIban')(e.target.value)} /></F>
            </div>
          </div>}

          {n.is149 && (
            <div id="incomeProfileSection" className="card" style={{ background: '#0B1220' }}>
              <h3 style={{ fontSize: 13, marginTop: 0 }}>Annual Taxable Income (for Section 149)</h3>
              {n.isNonUE && <div className="row" style={{ alignItems: 'center' }}>
                <label style={radioLbl}><input type="checkbox" id="e_affidavit" style={R} checked={f.affidavit} onChange={e => up('affidavit')(e.target.checked)} /> Affidavit of Low Income provided (Zero Tax under Section 149)</label>
              </div>}
              {n.isEmployee && <div className="row"><F label="Annual Taxable Income on file (set by Admin)"><input type="number" id="e_annualIncomeUE" readOnly value={f.annualIncomeUE} /></F></div>}
              {n.isNonUE && !f.affidavit && <div className="row">
                <F label="Annual Taxable Income (FY, reported once)"><input type="number" id="e_annualIncome" value={f.annualIncome} onChange={e => up('annualIncome')(e.target.value)} /></F>
                <F end><button type="button" className="secondary" onClick={saveIncomeProfile}>Save Income Profile</button></F>
              </div>}
              <div className="balance-box">
                <div className="bal-allocated"><span className="label">Already Claimed This Year</span><span className="val" id="ip_claimed">{tax && tax.section149 ? num(tax.section149.claimedBefore) : '-'}</span></div>
                <div className="bal-spent"><span className="label">Income Before This Bill</span><span className="val" id="ip_before">{tax && tax.section149 ? num(tax.section149.incomeBefore) : '-'}</span></div>
                <div className="bal-remaining"><span className="label">Income After This Bill</span><span className="val" id="ip_after">{tax && tax.section149 ? num(tax.section149.incomeAfter) : '-'}</span></div>
              </div>
            </div>)}

          <div className="row">
            <F label="Amount (Gross)"><input type="number" id="e_amount" value={f.amount} onChange={e => up('amount')(e.target.value)} /></F>
            <F wide label="Bill Description * (max 40 characters)"><input type="text" id="e_billdesc" maxLength={40} value={f.billDesc} onChange={e => up('billDesc')(e.target.value)} /></F>
          </div>

          {n.isRelease && (
            <div id="releaseSecurityInfo" className="balance-box">
              <div className="bal-allocated"><span className="label">Security Currently Held</span><span className="val" id="rs_held">{pname ? num(held) : '-'}</span></div>
              <div className="bal-spent"><span className="label">Release Amount (Gross above)</span><span className="val" id="rs_release">{num(billAmt)}</span></div>
              <div className="bal-remaining"><span className="label">Balance After Release</span><span className="val" id="rs_after" style={{ color: relAfter < 0 ? 'var(--danger)' : '' }}>{num(relAfter)}</span></div>
            </div>)}

          <hr />
          <h3 style={{ marginBottom: 4 }}>Deductions</h3>
          <div className="row">
            <F label="Nature of Bill"><select id="e_billnature" value={f.nature} onChange={e => setNature(e.target.value)}><NatureOptions groups={natureGroups} /></select></F>
            {n.isStudent && f.nature === 'Refund of Fee' && <F label="Refund Category">
              <select id="e_refundcategory" value={f.refundCat} onChange={e => up('refundCat')(e.target.value)}>
                {REFUND_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}<option value="__other__">Other (Manually Enter)</option></select></F>}
            {n.isStudent && f.nature === 'Refund of Fee' && f.refundCat === '__other__' && <F label="Enter Refund Category"><input type="text" id="e_refundcategory_other" placeholder="Type the category" value={f.refundOther} onChange={e => up('refundOther')(e.target.value)} /></F>}
            {f.nature === 'Thesis Evaluation' && <F label="Class"><input type="text" id="e_thesisClass" value={f.thesisClass} onChange={e => up('thesisClass')(e.target.value)} /></F>}
            {f.nature === 'Thesis Evaluation' && <F label="Student Name"><input type="text" id="e_thesisStudentName" value={f.thesisStudent} onChange={e => up('thesisStudent')(e.target.value)} /></F>}
          </div>
          {(n.isEmployee || n.isNonUE) && VISITING_NATURES.includes(f.nature) && (
            <div className="row" id="e_visitingFieldsWrap">
              <F label="Program"><input type="text" id="e_visitingProgram" value={f.visProgram} onChange={e => up('visProgram')(e.target.value)} /></F>
              <F label="Subject"><input type="text" id="e_visitingSubject" value={f.visSubject} onChange={e => up('visSubject')(e.target.value)} /></F>
              <F label="Cr. Hrs."><input type="number" step="0.5" id="e_visitingCrHrs" value={f.visCrHrs} onChange={e => up('visCrHrs')(e.target.value)} /></F>
              <F label="Rate"><input type="number" id="e_visitingRate" value={f.visRate} onChange={e => up('visRate')(e.target.value)} /></F>
              <F label="Lectures"><input type="number" id="e_visitingLectures" value={f.visLectures} onChange={e => up('visLectures')(e.target.value)} /></F>
            </div>)}
          <div className="row">
            <F hidden={!(n.isEmployee && f.nature === 'Benevolent Fund')} label="Benevolent Fund - Sub-category"><select id="e_benevolentSub" value={f.benevSub} onChange={e => up('benevSub')(e.target.value)}>{BENEVOLENT_SUBS.map(s => <option key={s} value={s}>{s}</option>)}</select></F>
            <F hidden={!(n.isNonUE && n.is149)} label="Non-UE Tax Deduction Method">
              <select id="e_nonueTaxMethod" value={f.nonueMethod} onChange={e => setNonueMethod(e.target.value)}>
                <option value="Section149">Section 149 (Slab, per Income Profile)</option>
                <option value="Section153_1b">Section 153(1)(b) - Services (Individual/AOP) - 15%/30%</option></select></F>
            <F hidden={!(n.isVendor && !n.noTax && f.nature !== 'Service')} label="Taxpayer Type"><select id="e_taxpayertype" value={f.taxpayerType} onChange={e => up('taxpayerType')(e.target.value)}><option value="Individual/AOP">Individual / AOP</option><option value="Company">Company</option></select></F>
            <F hidden={!(n.isVendor && !n.noTax && f.nature === 'Service')} label="Service Category"><select id="e_servicecategory" value={f.serviceCat} onChange={e => up('serviceCat')(e.target.value)}>{VENDOR_SERVICE_CATEGORIES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></F>
            <F hidden={!(n.is149 && f.nature === 'Conduct of Exam')} label="Conduct of Exam - Sub-category"><input type="text" id="e_examSubCategory" placeholder="Enter the specific exam/duty" value={f.examSub} onChange={e => up('examSub')(e.target.value)} /></F>
          </div>
          {showTaxStatus && <div id="taxStatusRow" className="row">
            <F label="FBR Status (Income Tax / Sales Tax)"><select id="e_fbrstatus" value={f.fbrStatus} onChange={e => up('fbrStatus')(e.target.value)}><option value="Filer">Active Taxpayer / Filer</option><option value="NonFiler">Inactive / Non-Filer</option></select></F>
            <F hidden={n.isEmployee || n.isNonUE} label="PRA Status (Punjab Sales Tax)"><select id="e_prastatus" value={f.praStatus} onChange={e => up('praStatus')(e.target.value)}><option value="Active">Active Taxpayer</option><option value="Inactive">Inactive Taxpayer</option></select></F>
          </div>}
          {!n.noTax && <div id="taxCheckRow" className="row" style={{ alignItems: 'center' }}>
            <label style={{ ...radioLbl, flex: 1 }}><input type="checkbox" id="e_applyIT" style={R} checked={f.applyIT} onChange={e => up('applyIT')(e.target.checked)} /> Deduct Income Tax</label>
            {n.isVendor && <label id="stCheckLabel" style={{ ...radioLbl, flex: 1 }}><input type="checkbox" id="e_applyST" style={R} checked={f.applyST} onChange={e => setApplyST(e.target.checked)} /> Deduct Sales Tax (Goods)</label>}
            {n.isVendor && <label id="pstCheckLabel" style={{ ...radioLbl, flex: 1 }}><input type="checkbox" id="e_applyPST" style={R} checked={f.applyPST} onChange={e => setApplyPST(e.target.checked)} /> Deduct Punjab Sales Tax (Services)</label>}
          </div>}
          {n.isVendor && f.applyPST && <div className="row" id="pstInvoiceRow">
            <F label="Invoice Number"><input type="text" id="e_pstInvoiceNo" value={f.pstInvoiceNo} onChange={e => up('pstInvoiceNo')(e.target.value)} /></F>
            <F label="Vendor's Invoice Date"><input type="date" id="e_vendorInvoiceDate" value={f.vendorInvoiceDate} onChange={e => up('vendorInvoiceDate')(e.target.value)} /></F>
          </div>}
          {n.isVendor && f.nature === 'Contract' && <div className="row" id="contractRateRow">
            <F label="Contract Category (Punjab Sales Tax rate)">
              <select id="e_contractCategory" value={f.contractCat} onChange={e => up('contractCat')(e.target.value)}><option value="NewProjects">New Projects</option><option value="RepairRenovation">Repair / Renovation</option></select>
              <small style={{ color: 'var(--text-muted)' }}>Rate for each is set in Admin &gt; Tax Settings.</small></F>
          </div>}

          <Ded label={{ text: 'Manually Enter Income Tax' }} d={f.manualTax} set={upSub('manualTax')} onToggle={toggle('manualTax')} texts={[['section', 'Section']]} />
          {f.applyST && <Ded label={{ text: 'Manually Enter Sales Tax' }} d={f.manualST} set={upSub('manualST')} onToggle={toggle('manualST')} />}
          {f.applyPST && <Ded label={{ text: 'Manually Enter Punjab Sales Tax' }} d={f.manualPST} set={upSub('manualPST')} onToggle={toggle('manualPST')} />}

          {n.isVendor && !n.noTax && <div id="otherDeductionsSection">
            <Ded label={{ text: 'Security' }} d={f.security} set={upSub('security')} onToggle={toggle('security')} texts={[['basis', 'Basis / Section']]} />
            <Ded label={{ text: 'Penalty' }} d={f.penalty} set={upSub('penalty')} onToggle={toggle('penalty')} texts={[['basis', 'Basis / Section']]} />
            <Ded label={{ text: 'Other Deduction' }} d={f.other} set={upSub('other')} onToggle={toggle('other')} texts={[['category', 'Category'], ['basis', 'Basis']]} />
          </div>}

          {n.isStudent && <div id="studentDeductionSection">
            <div className="row" style={{ alignItems: 'center' }}>
              <label style={radioLbl}><input type="checkbox" id="e_applyStudentDeduction" style={R} checked={f.studDed.on} onChange={e => upSub('studDed')({ on: e.target.checked })} /> Deduction</label>
              <F label="Category"><input type="text" disabled={!f.studDed.on} value={f.studDed.category} onChange={e => upSub('studDed')({ category: e.target.value })} /></F>
              <F label="Basis"><input type="text" disabled={!f.studDed.on} value={f.studDed.basis} onChange={e => upSub('studDed')({ basis: e.target.value })} /></F>
              <F label="Amount"><input type="number" id="e_studentDeductionAmount" disabled={!f.studDed.on} value={f.studDed.amount} onChange={e => upSub('studDed')({ amount: e.target.value })} /></F>
            </div>
          </div>}

          <div className="table-wrap" style={{ marginTop: 10 }}>
            <table id="taxPreviewTable">
              <thead><tr><th></th><th>Section / Basis</th><th>Rate</th><th>Amount</th></tr></thead>
              <tbody>
                <tr><td>Income Tax</td><td id="tp_itsection">{(tax && tax.incomeTaxSection) || '-'}</td><td id="tp_itrate">{pct(tax && tax.incomeTaxRate)}</td><td id="tp_itamt">{num(tax && tax.incomeTaxAmount)}</td></tr>
                <tr><td>Sales Tax</td><td>-</td><td>{pct(tax && tax.salesTaxRate)}</td><td id="tp_stamt">{num(tax && tax.salesTaxAmount)}</td></tr>
                <tr><td>Punjab Sales Tax<span style={{ color: 'var(--text-muted)', fontWeight: 'normal' }}>{tax && tax.pstCategory ? ' (' + tax.pstCategory + ')' : ''}</span></td><td>-</td><td>{pct(tax && tax.pstRate)}</td><td id="tp_pstamt">{num(tax && tax.pstAmount)}</td></tr>
                <tr><td>Security</td><td>-</td><td>{pct(tax && tax.securityRate)}</td><td id="tp_secamt">{num(tax && tax.securityAmount)}</td></tr>
                <tr><td>Penalty</td><td>-</td><td>{pct(tax && tax.penaltyRate)}</td><td id="tp_penamt">{num(tax && tax.penaltyAmount)}</td></tr>
                <tr><td>Other Deduction</td><td>-</td><td>{pct(tax && tax.otherDeductionRate)}</td><td id="tp_othamt">{num(tax && tax.otherDeductionAmount)}</td></tr>
                <tr><td>Student Deduction</td><td>-</td><td>-</td><td id="tp_studamt">{num(tax && tax.studentDeductionAmount)}</td></tr>
              </tbody>
              <tfoot><tr><td colSpan={3}>Net Payable</td><td id="tp_net">{num(tax && tax.netAmount)}</td></tr></tfoot>
            </table>
          </div>

          <button className="primary" id="btnSubmitEntry" onClick={submitSingle} style={{ marginTop: 12 }}>{editId ? 'Update Entry (' + editId + ')' : 'Save Entry'}</button>
        </div>}

        {/* ================= BULK UPLOAD ================= */}
        {isBulk && <div id="bulkEntrySection">
          <hr />
          <h3 style={{ marginBottom: 4 }}>Bulk Upload - Multiple Beneficiaries Under One Bill</h3>
          <p style={note}>Use this when one bill covers many people at once (e.g. a salary/scholarship voucher). This becomes <b>one single bill</b> through Processing, Passing and Payment with the total consolidated amount - the IBFT report, when generated, pays every beneficiary listed below individually.</p>
          <div className="row" style={{ alignItems: 'center' }}>
            {[['Vendor', 'Vendor Bulk'], ['Student', 'Student Bulk'], ['Employee', 'Employee Bulk (UE + Non-UE)']].map(([v, l]) => (
              <label key={v} style={radioLbl}><input type="radio" name="bulkType" value={v} style={R} checked={bulk.type === v} onChange={() => changeBulkType(v)} /> {l}</label>))}
          </div>
          <p id="bulkTypeHint" style={note}>{BULK_HINTS[bulk.type]}</p>
          <div className="row">
            <F label="Bill Description (whole bill) * (max 40 characters)"><input type="text" id="bulk_billdesc" maxLength={40} value={bulk.desc} onChange={e => setBulk({ ...bulk, desc: e.target.value })} /></F>
            <F end><button className="secondary" onClick={() => { const t = BULK_TEMPLATES[bulk.type]; exportCSV(t.examples, t.columns.map(c => [c, c]), bulk.type + '_Bulk_Upload_Template.csv'); }}>Download CSV Template</button></F>
          </div>
          <div className="card" id="bulkDiaryPicker" style={{ margin: '10px 0' }}>
            <h3 style={{ fontSize: 13, marginTop: 0 }}>Diary Numbers covered by this bulk bill</h3>
            <p style={note}>One bulk bill (one Bill ID) can cover several Diary numbers - they share this cost centre and budget head. Tick every Diary bill assigned to you that belongs in this upload. The one you opened with "Enter This Bill" is always included.</p>
            <div id="bulkDiaryTotals" style={{ fontSize: 13, marginBottom: 8 }}>
              <b>{diaryTotals.count}</b> Diary number(s) selected{diaryTotals.any ? <> - Diary total <b>{num(diaryTotals.total)}</b></> : null}{bulkGross ? <> - CSV gross total <b>{num(bulkGross)}</b></> : null}.
              {diaryTotals.any && bulkGross && Math.round(diaryTotals.total) !== Math.round(bulkGross) && <span style={{ color: 'var(--amber)' }}> The totals differ - you can still save (warning only).</span>}
            </div>
            <div className="table-wrap" style={{ maxHeight: 240, overflowY: 'auto' }}>
              <table id="bulkDiaryTable">
                <thead><tr><th></th><th>Diary No.</th><th>Type</th><th>Sender</th><th>Description</th><th className="num">Diary Amount</th></tr></thead>
                <tbody>{candidates.length ? candidates.map(r => {
                  const locked = diary && diary.id === r.diaryId;
                  return <tr key={r.diaryId}>
                    <td><input type="checkbox" className="chk-bulkDiary" disabled={!!locked} checked={!!locked || picked.has(r.diaryId)} onChange={e => setPicked(p => { const s = new Set(p); e.target.checked ? s.add(r.diaryId) : s.delete(r.diaryId); return s; })} /></td>
                    <td>{onOpenDiaryTrail ? <a href="#trail" onClick={e => { e.preventDefault(); onOpenDiaryTrail(r.diaryId); }} style={{ color: 'var(--accent)', fontWeight: 600, textDecoration: 'underline' }}>{r.diaryId}</a> : r.diaryId}</td>
                    <td>{r.billType ? 'Bill (' + r.billType + ')' : r.itemType}</td><td>{r.senderLabel}</td><td>{r.roughDescription}</td><td className="num">{r.amount != null ? num(r.amount) : ''}</td></tr>;
                }) : <EmptyRow cols={6} text="No other pending Diary bills are assigned to you." />}</tbody>
              </table>
            </div>
          </div>
          {bulk.type === 'Vendor' && <div className="row" id="bulkPstInvoiceRow">
            <F label="PST Invoice Number (required if any row has Punjab Sales Tax)"><input type="text" id="bulk_pstInvoiceNo" value={bulk.pstNo} onChange={e => setBulk({ ...bulk, pstNo: e.target.value })} /></F>
            <F label="Vendor's Invoice Date"><input type="date" id="bulk_vendorInvoiceDate" value={bulk.pstDate} onChange={e => setBulk({ ...bulk, pstDate: e.target.value })} /></F>
          </div>}
          <div className="row"><F label="Upload CSV"><input key={fileKey} type="file" id="bulk_file" accept=".csv" onChange={e => onBulkFile(e.target.files && e.target.files[0])} /></F></div>
          {bulk.errors.length > 0 && <div id="bulkErrors" className="error">{bulk.errors.map((e, i) => <div key={i}>&bull; {e}</div>)}</div>}

          {bulk.items.length > 0 && <div id="bulkPreviewWrap">
            <div className="balance-box">
              <div className="bal-allocated"><span className="label">Beneficiaries</span><span className="val" id="bulk_count">{bulk.items.length}</span></div>
              <div className="bal-spent"><span className="label">Gross Total</span><span className="val" id="bulk_gross">{num(bulkGross)}</span></div>
              <div className="bal-remaining"><span className="label">Net Total</span><span className="val" id="bulk_net">{num(bulkNet)}</span></div>
              <div className="bal-spent"><span className="label">Spent After This Bill</span><span className="val">{budget ? num(budget.spent + bulkGross) : '-'}</span></div>
              <div className="bal-remaining"><span className="label">Balance After This Bill</span><span className="val" style={{ color: budget && budget.remaining - bulkGross < 0 ? 'var(--danger)' : '' }}>{budget ? num(budget.remaining - bulkGross) : '-'}</span></div>
            </div>
            <div className="table-wrap">
              <table id="bulkPreviewTable">
                <thead><tr><th>#</th><th>Payee Type</th><th>ID</th><th>Name</th><th>CNIC</th><th>IBAN</th><th>Amount</th><th>Income Tax</th><th>Sales Tax</th><th>PST</th><th>Security</th><th>Penalty</th><th>Other</th><th>Net</th><th>Description</th><th>Office / Account</th></tr></thead>
                <tbody>{bulk.items.map((r, i) => (
                  <tr key={i} style={r.__existingMismatch ? { background: 'rgba(245,158,11,0.15)' } : undefined} title={r.__existingMismatch ? 'Differs from the record already on file - will overwrite it (with confirmation) on submit' : undefined}>
                    <td>{i + 1}</td><td>{r.payeeType}</td><td>{r.employeeId || r.studentId || ''}</td><td>{r.name}{r.__existingMismatch && <span style={{ color: 'var(--amber)' }}> ⚠</span>}</td><td>{r.cnic || ''}</td>
                    <td>{r.iban || ''}</td><td>{num(r.amount)}</td><td>{r.incomeTaxAmount === null ? <i style={{ color: 'var(--text-muted)' }}>at submit</i> : num(r.incomeTaxAmount)}</td><td>{num(r.salesTaxAmount)}</td>
                    <td>{num(r.pstAmount)}</td><td>{num(r.securityAmount)}</td><td>{num(r.penaltyAmount)}</td><td>{num(r.otherDeductionAmount)}</td>
                    <td>{r.net === null ? <i style={{ color: 'var(--text-muted)' }}>at submit</i> : num(r.net)}</td><td>{r.description || ''}</td>
                    <td>{bulk.type !== 'Vendor' && (r.receivingOfficeName || r.payFromAccountName) ? (r.receivingOfficeName || '-') + ' / ' + (r.payFromAccountName || '-') : <span style={{ color: 'var(--text-muted)' }}>(bill default)</span>}</td></tr>))}</tbody>
              </table>
            </div>
            <button className="primary" id="btnSubmitBulk" onClick={submitBulk} style={{ marginTop: 12 }}>Submit Bulk Bill</button>
          </div>}
        </div>}
      </div>

      {confirm && (
        <Modal id="confirmModal" maxWidth={560} z={110}>
          <h3 style={{ marginTop: 0 }}>Bill Saved - Please Confirm</h3>
          <div id="confirmContent" style={{ fontSize: 19, lineHeight: 1.9 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '2px solid var(--border)', marginBottom: 8 }}><span>Bill ID</span><b>{confirm.entryId}</b></div>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '2px solid var(--border)', marginBottom: 10 }}><span>Campus</span><b>{confirm.campusName || ''}</b></div>
            {(confirm.budgetSummary || []).map((b, i) => (
              <div key={i} style={{ border: '1px solid var(--border)', borderRadius: 8, padding: 12, marginBottom: 10 }}>
                <div style={{ fontWeight: 700, color: 'var(--accent)', marginBottom: 6 }}>{b.headCode || ''} {b.headName || ''}</div>
                {[['Allocation', b.allocated], ['Bill Amount', b.billAmount], ['Already Consumed', b.alreadyConsumed], ['New Total', b.newTotal]].map(([l, v]) => <div key={l} style={{ display: 'flex', justifyContent: 'space-between' }}><span>{l}</span><b>{num(v)}</b></div>)}
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Remaining Balance</span><b style={{ color: b.remainingBalance < 0 ? 'var(--danger)' : 'inherit' }}>{num(b.remainingBalance)}</b></div>
              </div>))}
            {confirm.diaryWarnings && confirm.diaryWarnings.length > 0 && (
              <div style={{ border: '1px solid var(--amber)', background: 'rgba(245,158,11,0.12)', borderRadius: 8, padding: 12, marginTop: 6, fontSize: 14, lineHeight: 1.5 }}>
                <b style={{ color: 'var(--amber)' }}>Diary check (warning only):</b><br />{confirm.diaryWarnings.map((w, i) => <div key={i}>&bull; {w}</div>)}</div>)}
          </div>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 14 }}>Check the figures above against your paper record. Validate if correct, or Update to change anything on this same bill.</p>
          <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
            <button className="primary" id="btnValidate" style={{ flex: 1, fontSize: 16, padding: 14 }} onClick={() => setConfirm(null)}>Validate</button>
            <button className="secondary" id="btnUpdateSaved" style={{ flex: 1, fontSize: 16, padding: 14 }} onClick={() => { const id = confirm.entryId; setConfirm(null); loadForEdit(id); }}>Update</button>
          </div>
        </Modal>)}
    </div>
  );
}
