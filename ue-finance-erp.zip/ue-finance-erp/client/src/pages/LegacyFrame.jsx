import React from 'react';

/* The screens that have not been rewritten yet (New Entry, Diary, Reports, Admin) run unchanged inside this frame.
   They share this browser tab's login, so nobody logs in twice. */
export default function LegacyFrame({ tab, sub, diary }) {
  return (
    <iframe key={tab + (sub || '') + (diary || '')} title={'screen-' + tab + (sub || '')} src={'/legacy.html?tab=' + tab + (sub ? '&sub=' + sub : '') + (diary ? '&diary=' + encodeURIComponent(diary) : '')}
      style={{ width: '100%', height: sub ? 'calc(100vh - 160px)' : 'calc(100vh - 104px)', border: 0, display: 'block', background: 'transparent' }} />
  );
}
