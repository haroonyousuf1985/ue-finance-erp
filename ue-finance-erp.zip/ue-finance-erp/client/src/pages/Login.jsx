import React, { useState } from 'react';
import { login, session } from '../api.js';

export default function Login({ onLoggedIn }) {
  const [u, setU] = useState('');
  const [p, setP] = useState('');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  async function go(e) {
    e && e.preventDefault();
    setMsg(''); setBusy(true);
    try {
      const res = await login(u.trim(), p);
      if (!res || !res.success) { setMsg((res && res.message) || 'Login failed.'); return; }
      const user = { success: true, username: res.username, fullName: res.fullName, role: res.role };
      session.save(user, res.token);
      onLoggedIn(user, !!res.weakPassword);
    } catch (err) { setMsg(err.message); }
    finally { setBusy(false); }
  }
  return (
    <form id="loginScreen" onSubmit={go} style={{ display: 'block' }}>
      <h2>ERP &amp; Budget Utilization Module - UE Finance</h2>
      <div className="field"><label>Username</label><input type="text" autoComplete="username" value={u} onChange={e => setU(e.target.value)} autoFocus /></div>
      <div className="field"><label>Password</label><input type="password" autoComplete="current-password" value={p} onChange={e => setP(e.target.value)} /></div>
      <button className="primary" type="submit" disabled={busy} style={{ width: '100%' }}>Login</button>
      <div className="error">{msg}</div>
    </form>
  );
}
