import React, { useCallback, useEffect, useState } from 'react';
import { gs } from '../api.js';
import { fmtDate, num, netOf } from '../util.js';
import { useToast, EmptyRow, BillLink, Modal } from '../ui.jsx';

/* Stage 6: fix whatever bounced, then send it back for a new IBFT attempt. Also the FBR tax adjustments. */
export default function Reconciliation({ user, onOpenBill, onChanged }) {
  const { toast, run } = useToast();
  const [bills, setBills] = useState(null);
  const [lines, setLines] = useState(null);
  const [fbr, setFbr] = useState(null);
  const [edit, setEdit] = useState(null);   // { id, isLine, name, iban, cnic }

  const loadBills = useCallback(() => gs('getNeedsCorrectionBills', '').then(setBills).catch(() => setBills([])), []);
  const loadLines = useCallback(() => gs('getLineLevelConfirmationQueue', '', true).then(setLines).catch(() => setLines([])), []);
  useEffect(() => { loadBills(); loadLines(); }, [loadBills, loadLines]);
  const reload = isLine => { (isLine ? loadLines() : loadBills()); onChanged && onChanged(); };

  async function resubmit(id, isLine) {
    const ok = window.confirm(isLine
      ? 'Resubmit beneficiary ' + id + ' for a fresh IBFT attempt? Make sure their bank details have already been corrected. Every other beneficiary in the same bulk bill is untouched.'
      : 'Send Bill ' + id + " back to the Passed queue for a fresh IBFT attempt? Make sure the beneficiary's bank details have already been corrected.");
    if (!ok) return;
    const res = await run(() => gs(isLine ? 'resubmitFailedBulkLine' : 'resubmitFailedPayment', id, user.username), 'Resubmitting...',
      isLine ? 'Resubmitted - will appear in a new IBFT batch for just this beneficiary.' : 'Sent back to Passed - it will appear in a new IBFT batch, with a retry marker on its Bill ID.');
    if (res && res.success) reload(isLine);
  }
  const editInfo = (e, isLine) => setEdit({ id: e.EntryID, isLine, name: e.VendorName || '', iban: e.IBAN || '', cnic: e.CNIC_NTN || '' });
  const saveFn = isLine => isLine ? 'updateFailedBulkLineBeneficiary' : 'updateFailedPaymentBeneficiary';
  const payload = () => ({ name: edit.name.trim(), iban: edit.iban.trim(), cnic: edit.cnic.trim() });

  async function saveOnly() {
    const res = await run(() => gs(saveFn(edit.isLine), edit.id, payload(), user.username), 'Saving...', 'Beneficiary detail updated.');
    if (res && res.success) { const l = edit.isLine; setEdit(null); reload(l); }
  }
  async function saveAndResubmit() {
    const r1 = await run(() => gs(saveFn(edit.isLine), edit.id, payload(), user.username), 'Saving...');
    if (!r1 || !r1.success) return;
    const r2 = await run(() => gs(edit.isLine ? 'resubmitFailedBulkLine' : 'resubmitFailedPayment', edit.id, user.username), 'Resubmitting...', 'Updated and sent back for a fresh IBFT attempt.');
    if (r2 && r2.success) { const l = edit.isLine; setEdit(null); reload(l); }
  }

  async function loadFbr() {
    setFbr(null);
    const list = await gs('getFBRTaxAdjustments', {}, user.username).catch(e => { toast(e.message, 'error'); return []; });
    setFbr(list || []);
  }
  async function recordFbr(a) {
    const s = window.prompt('How much have you reconciled with FBR for this item? (remaining: ' + num(a.remaining) + ')');
    if (s === null) return;
    const amount = Number(s);
    if (!amount || amount <= 0) { toast('Enter a valid amount.', 'error'); return; }
    const notes = window.prompt('Notes (optional):') || '';
    const res = await run(() => gs('recordFBRTaxAdjustment', a.adjustmentId, amount, notes, user.username), 'Recording...', 'Adjustment recorded.');
    if (res && res.success) loadFbr();
  }

  const note = { fontSize: 12.5, color: 'var(--text-muted)' };
  return (
    <div className="tabpanel active">
      <div className="card">
        <h3>Needs Correction <span className="pill Cancelled">Payment Failed</span></h3>
        <p style={note}>Bills whose transfer bounced - including beneficiaries separated out of a bulk bill (shown as E123-A, E123-B ... with "Isolated From" naming the original bulk bill). Edit the beneficiary's IBAN/Name/CNIC if that was the problem, then Resubmit to send just this bill back for a fresh IBFT attempt. The exported Bill ID gets a retry marker (e.g. E123-A-1).</p>
        <div className="table-wrap"><table>
          <thead><tr><th>Bill ID</th><th>Isolated From</th><th>Failed On</th><th>Reason</th><th>Beneficiary</th><th>FBR Section</th><th>IBAN</th><th className="num">Net Amount</th><th></th></tr></thead>
          <tbody>
            {bills === null && <EmptyRow cols={9} text="Loading..." />}
            {bills && bills.length === 0 && <EmptyRow cols={9} />}
            {(bills || []).map(e => (
              <tr key={e.EntryID}>
                <td><BillLink id={e.EntryID} onOpen={onOpenBill} /></td>
                <td>{e.SplitFromEntryID ? <><BillLink id={e.SplitFromEntryID} onOpen={onOpenBill} /> (line {e.SplitFromLineNo})</> : '-'}</td>
                <td>{fmtDate(e.PaymentFailureDate)}</td><td>{e.PaymentFailureReason}</td><td>{e.VendorName}</td><td>{e.IncomeTaxSection || '-'}</td><td>{e.IBAN}</td><td className="num">{num(netOf(e))}</td>
                <td><button className="secondary" onClick={() => editInfo(e, false)}>Edit</button> <button className="primary" onClick={() => resubmit(e.EntryID, false)}>Resubmit</button></td>
              </tr>
            ))}
          </tbody></table></div>
      </div>

      <div className="card">
        <h3>Older Failed Bulk Lines <span className="pill Cancelled">Legacy</span></h3>
        <p style={note}>Only beneficiaries marked Failed before isolation existed appear here. Resubmitting one of these is per-line as before; new failures are isolated into their own bill above instead.</p>
        <div className="table-wrap"><table>
          <thead><tr><th>Line ID</th><th>Parent Bill</th><th>Failed On</th><th>Reason</th><th>Beneficiary</th><th>FBR Section</th><th>IBAN</th><th className="num">Net Amount</th><th></th></tr></thead>
          <tbody>
            {lines === null && <EmptyRow cols={9} text="Loading..." />}
            {lines && lines.length === 0 && <EmptyRow cols={9} />}
            {(lines || []).map(li => (
              <tr key={li.EntryID}>
                <td><BillLink id={li.EntryID} onOpen={onOpenBill} /></td><td><BillLink id={li.ParentBillID} onOpen={onOpenBill} /></td>
                <td>{fmtDate(li.LinePaymentFailureDate)}</td><td>{li.LinePaymentFailureReason}</td><td>{li.VendorName}</td><td>{li.IncomeTaxSection || '-'}</td><td>{li.IBAN}</td><td className="num">{num(netOf(li))}</td>
                <td><button className="secondary" onClick={() => editInfo(li, true)}>Edit</button> <button className="primary" onClick={() => resubmit(li.EntryID, true)}>Resubmit</button></td>
              </tr>
            ))}
          </tbody></table></div>
      </div>

      <div className="card">
        <h3>FBR Tax Adjustments <span className="pill Processed">from Redirected Bills</span></h3>
        <p style={note}>When a Paid bill is redirected to the correct beneficiary (Admin &gt; Redirect a Paid Bill), the Income Tax already withheld/deposited under the WRONG beneficiary's name is tracked here instead of being credited to them. "Not Yet Deposited" - adjust the amount you actually deposit under that name with FBR. "Deposited" - adjust it against that beneficiary's own upcoming bills. Record however much you've reconciled each time; partial amounts are fine.</p>
        <button className="secondary" onClick={loadFbr}>Load</button>
        <div className="table-wrap" style={{ marginTop: 10 }}><table>
          <thead><tr><th>Wrong Beneficiary</th><th>Original Bill</th><th>Redirected To</th><th className="num">Tax Amount</th><th className="num">Adjusted So Far</th><th className="num">Remaining</th><th>Deposit Status</th><th></th></tr></thead>
          <tbody>
            {fbr === null && <EmptyRow cols={8} text="Click Load." />}
            {fbr && fbr.length === 0 && <EmptyRow cols={8} text="Nothing to adjust." />}
            {(fbr || []).map(a => (
              <tr key={a.adjustmentId}>
                <td>{a.wrongBeneficiaryName} ({a.payeeType === 'Employee' ? 'UE' : 'Non-UE'})</td>
                <td><BillLink id={a.originalEntryId} onOpen={onOpenBill} /></td><td><BillLink id={a.redirectedToEntryId} onOpen={onOpenBill} /></td>
                <td className="num">{num(a.taxAmount)}</td><td className="num">{num(a.amountAdjusted)}</td><td className="num">{num(a.remaining)}</td>
                <td>{a.depositStatus === 'Deposited' ? 'Deposited - adjust in upcoming bills' : 'Not Yet Deposited'}</td>
                <td><button className="primary" onClick={() => recordFbr(a)}>Record Adjustment</button></td>
              </tr>
            ))}
          </tbody></table></div>
      </div>

      {edit && (
        <Modal maxWidth={480} onClose={() => setEdit(null)}>
          <h3 style={{ marginTop: 0 }}>Edit Beneficiary - <span style={{ color: 'var(--accent)' }}>{edit.id}</span></h3>
          <div className="field"><label>Name</label><input type="text" value={edit.name} onChange={e => setEdit({ ...edit, name: e.target.value })} /></div>
          <div className="field"><label>IBAN</label><input type="text" value={edit.iban} onChange={e => setEdit({ ...edit, iban: e.target.value })} /></div>
          <div className="field"><label>CNIC / NTN</label><input type="text" value={edit.cnic} onChange={e => setEdit({ ...edit, cnic: e.target.value })} /></div>
          <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
            <button className="primary" style={{ flex: 1 }} onClick={saveAndResubmit}>Save &amp; Resubmit</button>
            <button className="secondary" style={{ flex: 1 }} onClick={saveOnly}>Save Only</button>
            <button className="secondary" style={{ flex: 1 }} onClick={() => setEdit(null)}>Cancel</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
