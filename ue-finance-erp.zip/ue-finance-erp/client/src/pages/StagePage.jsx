import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { gs } from '../api.js';
import { fmtDate, num, netOf, fyOptions, todayISO, IBFT_COLUMNS, IBFT_NUMERIC, exportCSV } from '../util.js';
import { useToast, EmptyRow, FYSelect, BillLink } from '../ui.jsx';

/* One page for the three bill stages: Processing (Received -> Processed), Passing (Processed -> Passed),
   Payment/IBFT (Passed -> Paid + bank transfer file). */
const STAGES = {
  processing: {
    title: 'Stage 2 - Mark as Processed', pill: 'Received', pillText: 'from Received', from: 'Received',
    button: 'Mark Selected as Processed', busy: 'Marking as Processed...',
    done: n => n + ' bill(s) marked Processed - now waiting in the Passing tab.', fn: 'markProcessed', filters: ['id', 'name', 'desc', 'amt'], kind: 'full'
  },
  passing: {
    title: 'Stage 3 - Mark as Passed', pill: 'Processed', pillText: 'from Processed', from: 'Processed',
    button: 'Mark Selected as Passed', busy: 'Marking as Passed...',
    done: n => n + ' bill(s) marked Passed - now waiting in the Payment tab.', fn: 'markPassed', filters: ['id', 'name', 'desc', 'amt'], kind: 'passing'
  },
  payment: {
    title: 'Stage 4 - Mark Paid & Generate IBFT', pill: 'Passed', pillText: 'from Passed', from: 'Passed',
    button: 'Mark Paid & Generate IBFT Report', busy: 'Marking Paid & building IBFT report...', done: () => 'Payment batch created.',
    fn: 'markPaidAndGenerateIBFT', filters: ['id', 'name', 'amt'], kind: 'payment'
  }
};

function Cols({ kind, e, onOpen }) {
  if (kind === 'payment') {
    return (<>
      <td><BillLink id={e.EntryID} onOpen={onOpen} /></td><td>{fmtDate(e.EntryDate)}</td><td>{e.CampusName}</td><td>{e.VendorName}</td>
      <td>{e.CNIC_NTN || ''}</td><td>{e.IBAN || ''}</td><td>{e.BillNo || ''}</td><td className="num">{num(e.Amount)}</td>
    </>);
  }
  return (<>
    <td><BillLink id={e.EntryID} onOpen={onOpen} /></td><td>{fmtDate(e.EntryDate)}</td><td>{e.CampusName}</td><td>{e.BillDescription || ''}</td>
    <td className="num">{num(e.Amount)}</td><td className="num">{num(e.IncomeTaxAmount)}</td><td className="num">{num(e.SalesTaxAmount)}</td><td className="num">{num(e.PSTAmount)}</td>
    <td className="num">{num(e.SecurityAmount)}</td><td className="num">{num(e.PenaltyAmount)}</td><td className="num">{num(e.OtherDeductionAmount)}</td>
    <td className="num">{num(netOf(e))}</td><td>{e.VendorName}</td>
    {kind === 'passing' && <><td>{e.ProcessedBy || ''}</td><td>{fmtDate(e.ProcessedDate)}</td></>}
  </>);
}

export default function StagePage({ stage, user, onOpenBill, onChanged }) {
  const cfg = STAGES[stage];
  const { toast, run } = useToast();
  const [fy, setFy] = useState('');
  const [list, setList] = useState(null);
  const [error, setError] = useState('');
  const [sel, setSel] = useState(() => new Set());
  const [f, setF] = useState({ id: '', name: '', desc: '', amt: '' });
  const [payDate, setPayDate] = useState(todayISO());
  const [report, setReport] = useState(null);
  const [batches, setBatches] = useState([]);

  const load = useCallback(() => {
    setList(null); setError('');
    gs('getBillsByStatus', cfg.from, fy).then(l => { setList(l || []); setSel(new Set()); onChanged && onChanged(); })
      .catch(e => { setError('Could not load bills: ' + e.message); setList([]); toast('Could not load bills: ' + e.message, 'error'); });
  }, [cfg.from, fy]);   // eslint-disable-line
  const loadBatches = useCallback(() => {
    if (stage !== 'payment') return;
    gs('getPaymentBatches').then(b => setBatches(b || [])).catch(e => toast('Could not load batch history: ' + e.message, 'error'));
  }, [stage]);   // eslint-disable-line
  useEffect(() => { load(); }, [load]);
  useEffect(() => { loadBatches(); }, [loadBatches]);

  const shown = useMemo(() => {
    const has = (v, q) => !q.trim() || String(v || '').toLowerCase().includes(q.trim().toLowerCase());
    return (list || []).filter(e => has(e.EntryID, f.id) && has(e.VendorName, f.name) && has(e.BillDescription, f.desc) && (has(e.Amount, f.amt) || has(e.NetAmount, f.amt)));
  }, [list, f]);

  const toggle = (id, on) => setSel(s => { const n = new Set(s); on ? n.add(id) : n.delete(id); return n; });
  const allShownOn = shown.length > 0 && shown.every(e => sel.has(e.EntryID));
  const toggleAll = on => setSel(s => { const n = new Set(s); shown.forEach(e => on ? n.add(e.EntryID) : n.delete(e.EntryID)); return n; });

  async function act() {
    const ids = Array.from(sel);
    if (!ids.length) { toast('Select at least one bill.', 'error'); return; }
    if (stage === 'payment') {
      if (!payDate) { toast('Select a payment date.', 'error'); return; }
      const res = await run(() => gs(cfg.fn, ids, payDate, user.username), cfg.busy, cfg.done(ids.length));
      if (res && res.success) {
        setReport(res); load(); loadBatches();
        try { exportCSV(res.items, IBFT_COLUMNS, 'IBFT_' + res.batchId + '.csv'); } catch (e) { /* the button in the report is the reliable path */ }
        setTimeout(() => { const el = document.getElementById('ibftReport'); el && el.scrollIntoView({ behavior: 'smooth' }); }, 50);
      }
    } else {
      const res = await run(() => gs(cfg.fn, ids, user.username), cfg.busy, cfg.done(ids.length));
      if (res && res.success) load();
    }
  }

  async function downloadBatch(id) {
    try {
      const items = await gs('getBatchDetails', id);
      if (!items || !items.length) { toast('No bills found for this batch.', 'error'); return; }
      exportCSV(items, IBFT_COLUMNS, 'IBFT_' + id + '.csv');
    } catch (e) { toast('Could not download batch: ' + e.message, 'error'); }
  }

  const heads = cfg.kind === 'payment'
    ? ['Bill ID', 'Date', 'Campus', 'Vendor', 'CNIC/NTN', 'IBAN', 'Bill No.', 'Amount']
    : ['Bill ID', 'Date', 'Campus', 'Bill Description', 'Gross', 'Income Tax', 'Sales Tax', 'Punjab Sales Tax', 'Security', 'Penalty', 'Other Deduction', 'Net Amount', 'Vendor'].concat(cfg.kind === 'passing' ? ['Processed By', 'Processed Date'] : []);
  const numeric = new Set(['Gross', 'Income Tax', 'Sales Tax', 'Punjab Sales Tax', 'Security', 'Penalty', 'Other Deduction', 'Net Amount', 'Amount']);
  const colCount = heads.length + 1;
  const flt = (key, label) => cfg.filters.includes(key) && (
    <div className="field" key={key}><label>{label}</label><input type="text" value={f[key]} onChange={e => setF({ ...f, [key]: e.target.value })} /></div>);

  return (
    <div className="tabpanel active">
      <div className="card no-print">
        <h3>{cfg.title} <span className={'pill ' + cfg.pill}>{cfg.pillText}</span></h3>
        <div className="row">
          <div className="field" style={{ maxWidth: 220 }}><label>Financial Year</label><FYSelect value={fy} onChange={setFy} options={fyOptions()} /></div>
          {stage === 'payment' && <div className="field"><label>Payment Date</label><input type="date" value={payDate} onChange={e => setPayDate(e.target.value)} /></div>}
          <div className="field" style={{ alignSelf: 'flex-end', flex: 2 }}>
            <button className="secondary" onClick={load}>Refresh</button>{' '}
            <button className="primary" onClick={act}>{cfg.button}</button>
            <span style={{ marginLeft: 12, fontSize: 12.5, color: 'var(--text-muted)' }}>{sel.size} selected</span>
          </div>
        </div>
        <div className="row">
          {flt('id', 'Bill ID contains')}{flt('name', 'Vendor/Name contains')}{flt('desc', 'Description contains')}{flt('amt', 'Amount contains')}
        </div>
        <div className="table-wrap" style={{ marginTop: 10 }}>
          <table>
            <thead><tr>
              <th><input type="checkbox" title="Select all shown" checked={allShownOn} onChange={e => toggleAll(e.target.checked)} /></th>
              {heads.map(h => <th key={h} className={numeric.has(h) ? 'num' : undefined}>{h}</th>)}
            </tr></thead>
            <tbody>
              {list === null && <EmptyRow cols={colCount} text="Loading..." />}
              {list !== null && error && <EmptyRow cols={colCount} text={error} error />}
              {list !== null && !error && shown.length === 0 && <EmptyRow cols={colCount} />}
              {shown.map(e => (
                <tr key={e.EntryID}>
                  <td><input type="checkbox" checked={sel.has(e.EntryID)} onChange={ev => toggle(e.EntryID, ev.target.checked)} /></td>
                  <Cols kind={cfg.kind} e={e} onOpen={onOpenBill} />
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {stage === 'payment' && report && (
        <div className="card" id="ibftReport">
          <h3>IBFT Transfer Request <button className="secondary no-print" onClick={() => window.print()}>Print</button></h3>
          <p><b>Batch:</b> {report.batchId} &nbsp; <b>Date:</b> {report.date} &nbsp; <b>Total (Gross):</b> {num(report.total)} &nbsp;
            <button className="secondary no-print" onClick={() => exportCSV(report.items, IBFT_COLUMNS, 'IBFT_' + report.batchId + '.csv')}>Download CSV</button></p>
          <div className="table-wrap">
            <table>
              <thead><tr>{IBFT_COLUMNS.map(([, label]) => <th key={label}>{label}</th>)}</tr></thead>
              <tbody>{report.items.map((it, i) => <tr key={i}>{IBFT_COLUMNS.map(([k]) => <td key={k}>{IBFT_NUMERIC.has(k) ? num(it[k]) : (it[k] ?? '')}</td>)}</tr>)}</tbody>
            </table>
          </div>
        </div>
      )}

      {stage === 'payment' && (
        <div className="card no-print">
          <h3>Past IBFT Batches <button className="secondary" onClick={loadBatches}>Refresh</button></h3>
          <p style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>If a CSV download didn't appear when a batch was generated (browsers sometimes block automatic downloads), download it again here at any time.</p>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Batch ID</th><th>Date</th><th>Generated By</th><th className="num">Bills</th><th className="num">Total Amount</th><th></th></tr></thead>
              <tbody>
                {batches.length === 0 && <EmptyRow cols={6} text="No batches yet." />}
                {batches.map(b => (
                  <tr key={b.BatchID}><td>{b.BatchID}</td><td>{fmtDate(b.Date)}</td><td>{b.GeneratedBy}</td>
                    <td className="num">{String(b.EntryIDs || '').split(',').filter(Boolean).length}</td><td className="num">{num(b.TotalAmount)}</td>
                    <td><button className="secondary" onClick={() => downloadBatch(b.BatchID)}>Download CSV</button></td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
