import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { gs } from '../api.js';
import { fmtDate, num, netOf, payeeTypeLabel } from '../util.js';
import { Modal } from '../ui.jsx';

/* The Bill Audit View: everything known about one bill. */
function Item({ label, value, cls }) {
  if (value === undefined || value === null || value === '') return null;
  return <div className="bav-item"><div className="bav-label">{label}</div><div className={'bav-value' + (cls ? ' ' + cls : '')}>{value}</div></div>;
}
function FinRow({ label, sub, amount, net, gross, negative }) {
  return (
    <div className={'bav-finrow ' + (net ? 'bav-net ' : '') + (gross ? 'bav-gross' : '')}>
      <div><div className="bav-fin-label">{label}</div>{sub ? <div className="bav-fin-sub">{sub}</div> : null}</div>
      <div className={'bav-fin-value ' + (negative ? 'negative' : '')}>{negative ? '-' : ''}{num(amount)} PKR</div>
    </div>
  );
}
function Link({ id, onOpen, color }) {
  return <a href="#bill" onClick={ev => { ev.preventDefault(); onOpen(id); }} style={{ color: color || 'var(--accent)', textDecoration: 'underline' }}>{id}</a>;
}

function CategoryBox({ e, headSplits }) {
  const lines = [];
  let title = (e.BillNature || 'Bill') + ' Details';
  const L = (k, v) => lines.push(<span key={lines.length}><b>{k}:</b> {v}</span>);
  if (e.BillNature === 'Thesis Evaluation') { title = 'Thesis Evaluation Details'; if (e.ThesisClass) L('Class', e.ThesisClass); if (e.ThesisStudentName) L('Student Name', e.ThesisStudentName); }
  else if (e.BillNature === 'Benevolent Fund') { title = 'Benevolent Fund Details'; if (e.BenevolentFundSubCategory) L('Sub-category', e.BenevolentFundSubCategory); }
  else if (e.BillNature === 'Conduct of Exam') { title = 'Conduct of Exam Details'; if (e.ExamSubCategory) L('Sub-category', e.ExamSubCategory); }
  else if (e.BillNature === 'Refund of Fee') { title = 'Refund of Fee Details'; if (e.RefundCategory) L('Category', e.RefundCategory); }
  else if (e.BillNature === 'Contract' && e.ContractCategory) { title = 'Execution of Contract Details'; L('Contract Category', (e.ContractCategory === 'RepairRenovation' ? 'Repair / Renovation' : 'New Projects') + ' (Punjab Sales Tax rate)'); }
  else if (e.BillNature === 'UE Visiting Faculty' || e.BillNature === 'Paper Setting/Marking') {
    title = e.BillNature + ' Details';
    if (e.VisitingProgram) L('Program', e.VisitingProgram); if (e.VisitingSubject) L('Subject', e.VisitingSubject);
    if (e.VisitingCrHrs) L('Cr. Hrs.', e.VisitingCrHrs); if (e.VisitingRate) L('Rate', e.VisitingRate); if (e.VisitingLectures) L('Lectures', e.VisitingLectures);
  }
  if (e.NonUETaxMethod === 'Section153_1b') L('Tax Method', 'Section 153(1)(b) - Services (Individual/AOP)');
  if (e.AffidavitLowIncome) L('Affidavit of Low Income', 'Submitted - Section 149 tax is zero');
  if (e.ManualTaxOverride) L('Income Tax', 'Manually entered' + (e.ManualTaxSection ? ' (' + e.ManualTaxSection + ')' : ''));
  if (headSplits && headSplits.length) {
    title = 'Multi-Head Split Details';
    lines.push(<span key="splits">{headSplits.map((sp, i) => <span key={i}>{(sp.HeadCode || '') + ' - ' + (sp.HeadName || '') + ': ' + num(sp.Amount) + ' PKR'}<br /></span>)}</span>);
  }
  if (!lines.length) return null;
  return <div className="bav-section"><div className="bav-section-title">{title}</div>{lines.map((l, i) => <div key={i} className="bav-section-line">{l}</div>)}</div>;
}

function BillBody({ res, onOpen }) {
  const e = res.bill;
  const headText = (res.headSplits && res.headSplits.length) ? 'Multiple Heads (' + res.headSplits.length + ')' : ((e.HeadCode || '') + ' - ' + (e.HeadName || ''));
  const bp = res.budgetPosition || [];
  const anyLocked = bp.some(x => x.locked), anyLive = bp.some(x => !x.locked);
  const box = (bg, border) => ({ background: bg, borderColor: border });
  return (
    <>
      <div className="bav-caption">Bill Audit View</div>
      <div className="bav-billid">Bill ID: {e.EntryID}</div>
      <div className="bav-grid">
        <Item label="Status" value={e.Status} cls={'status-' + e.Status} /><Item label="Entry Date" value={fmtDate(e.EntryDate)} />
        <Item label="Originating Office" value={e.ReceivingOffice} /><Item label="Paying Bank Account" value={e.PayFromAccountLabel} />
        <Item label="Campus" value={e.CampusName} /><Item label="Budget Head" value={headText} />
      </div>

      {bp.length > 0 && (
        <>
          <div className="bav-section-title" style={{ margin: '4px 0 8px', color: 'var(--text-muted)', fontSize: 12, textTransform: 'uppercase', letterSpacing: '.05em' }}>
            Budget Position {anyLocked && <span style={{ color: 'var(--accent)', textTransform: 'none' }}>&#128274; locked as of entry</span>}{' '}
            {anyLive && <span style={{ color: 'var(--amber)', textTransform: 'none' }}>(no snapshot on file for this older bill - showing live figures instead)</span>}
          </div>
          {bp.map((x, i) => (
            <div key={i} className="bav-section" style={box('rgba(59,130,246,0.08)', 'rgba(59,130,246,0.3)')}>
              {bp.length > 1 && <div style={{ fontWeight: 700, marginBottom: 6 }}>{x.headCode} - {x.headName}</div>}
              {!x.hasAllocation && <div style={{ color: 'var(--amber)', fontSize: 12, marginBottom: 6 }}>No allocation on file for this head/FY.</div>}
              <FinRow label="Current Bill" amount={x.currentBill} />
              <FinRow label="Expenses So Far" sub="Before this bill" amount={x.expensesSoFar} />
              <FinRow label="After This Bill" amount={x.afterThisBill} />
              <FinRow label="Balance" sub={'Allocated: ' + num(x.allocated)} amount={x.balance} negative={x.balance < 0} />
            </div>
          ))}
        </>
      )}

      <div className="bav-grid" style={{ marginTop: bp.length ? 18 : 0 }}>
        {e.PayeeType === 'Bulk'
          ? <><Item label="Bill Type" value={'Bulk Bill - ' + (res.bulkItems || []).length + ' beneficiaries'} /><Item label="Description" value={e.BillDescription} /></>
          : <><Item label="Beneficiary Type" value={payeeTypeLabel(e.PayeeType)} /><Item label="FBR Section" value={e.IncomeTaxSection || '-'} />
            <Item label="Beneficiary Name" value={e.VendorName} /><Item label="CNIC / NTN" value={e.CNIC_NTN} /><Item label="IBAN" value={e.IBAN} /><Item label="Description" value={e.BillDescription} /></>}
      </div>

      {e.Status === 'Cancelled' && (
        <div className="bav-section" style={box('rgba(239,68,68,0.10)', 'rgba(239,68,68,0.35)')}>
          <div className="bav-section-title" style={{ color: 'var(--danger)' }}>Cancelled</div>
          {e.StatusBeforeCancellation && <div className="bav-section-line"><b>Was at:</b> {e.StatusBeforeCancellation}</div>}
          {e.CancelledBy && <div className="bav-section-line"><b>Cancelled By:</b> {e.CancelledBy}{e.CancelledDate ? ' on ' + fmtDate(e.CancelledDate) : ''}</div>}
          {e.CancellationReason && <div className="bav-section-line"><b>Reason:</b> {e.CancellationReason}</div>}
          <div className="bav-section-line" style={{ color: 'var(--text-muted)' }}>Excluded from all budget, consumption, and payment figures.</div>
        </div>
      )}
      {(e.RedirectedToEntryID || e.RedirectedFromEntryID) && (
        <div className="bav-section" style={box('rgba(59,130,246,0.10)', 'rgba(59,130,246,0.35)')}>
          <div className="bav-section-title" style={{ color: '#93C5FD' }}>Redirected Bill</div>
          {e.RedirectedToEntryID && <div className="bav-section-line">This bill was paid to the wrong beneficiary and redirected - the corrected payment is <Link id={e.RedirectedToEntryID} onOpen={onOpen} color="#93C5FD" />.</div>}
          {e.RedirectedFromEntryID && <div className="bav-section-line">This bill was created to correct <Link id={e.RedirectedFromEntryID} onOpen={onOpen} color="#93C5FD" />, which had been paid to the wrong beneficiary.</div>}
        </div>
      )}
      {e.SplitFromEntryID && (
        <div className="bav-section" style={box('rgba(245,158,11,0.10)', 'rgba(245,158,11,0.35)')}>
          <div className="bav-section-title" style={{ color: 'var(--amber)' }}>Isolated Beneficiary Bill</div>
          <div className="bav-section-line">This bill was separated from bulk bill <Link id={e.SplitFromEntryID} onOpen={onOpen} color="var(--amber)" /> (line {e.SplitFromLineNo}) after that beneficiary's payment failed. It is NOT charged to the budget again - the amount is already charged through the parent bulk bill. Its full history, from Diary to Reconciliation, is shown below and in the original bill's trail.</div>
        </div>
      )}

      {e.PayeeType !== 'Bulk' && <CategoryBox e={e} headSplits={res.headSplits} />}

      {(e.PSTInvoiceNo || e.VendorInvoiceDate) && (
        <div className="bav-section"><div className="bav-section-title">Punjab Sales Tax Invoice</div>
          {e.PSTInvoiceNo && <div className="bav-section-line"><b>Invoice No.:</b> {e.PSTInvoiceNo}</div>}
          {e.VendorInvoiceDate && <div className="bav-section-line"><b>Vendor's Invoice Date:</b> {fmtDate(e.VendorInvoiceDate)}</div>}
        </div>
      )}

      {e.PayeeType === 'Bulk' && res.bulkItems && res.bulkItems.length ? <BulkTable e={e} items={res.bulkItems} onOpen={onOpen} /> : (
        <div className="bav-fin">
          <FinRow label="Gross Amount" amount={e.Amount} gross />
          {(e.IncomeTaxAmount || e.IncomeTaxSection) ? <FinRow label="Income Tax" sub={e.IncomeTaxSection} amount={e.IncomeTaxAmount} negative={!!e.IncomeTaxAmount} /> : null}
          {e.SalesTaxAmount ? <FinRow label="Sales Tax" amount={e.SalesTaxAmount} negative /> : null}
          {e.PayeeType === 'Vendor' ? <FinRow label="Punjab Sales Tax (PST)" amount={e.PSTAmount || 0} negative={!!e.PSTAmount} /> : null}
          {e.SecurityAmount ? <FinRow label="Security" sub={e.SecurityBasis} amount={e.SecurityAmount} negative /> : null}
          {e.PenaltyAmount ? <FinRow label="Penalty" sub={e.PenaltyBasis} amount={e.PenaltyAmount} negative /> : null}
          {e.OtherDeductionAmount ? <FinRow label={'Other Deduction' + (e.OtherDeductionCategory ? ' (' + e.OtherDeductionCategory + ')' : '')} sub={e.OtherDeductionBasis} amount={e.OtherDeductionAmount} negative /> : null}
          {e.StudentDeductionAmount ? <FinRow label={'Student Deduction' + (e.StudentDeductionCategory ? ' (' + e.StudentDeductionCategory + ')' : '')} sub={e.StudentDeductionBasis} amount={e.StudentDeductionAmount} negative /> : null}
          <FinRow label="NET AMOUNT PAID" amount={netOf(e)} net />
        </div>
      )}

      <div className="bav-grid" style={{ marginTop: 18 }}>
        <Item label="Entered By" value={e.EnteredBy} /><Item label="Bill / Invoice No." value={e.BillNo} />
        <Item label="Processed" value={e.ProcessedBy ? fmtDate(e.ProcessedDate) + ' by ' + e.ProcessedBy : ''} />
        <Item label="Passed" value={e.PassedBy ? fmtDate(e.PassedDate) + ' by ' + e.PassedBy : ''} />
        <Item label="Paid" value={e.PaidBy ? fmtDate(e.PaidDate) + ' by ' + e.PaidBy + (e.BatchID ? ' (Batch ' + e.BatchID + ')' : '') : ''} />
      </div>
    </>
  );
}

function BulkTable({ e, items, onOpen }) {
  let g = 0, t = 0, n = 0;
  const rows = items.map(li => {
    const tax = Number(li.IncomeTaxAmount || 0) + Number(li.SalesTaxAmount || 0) + Number(li.PSTAmount || 0) + Number(li.SecurityAmount || 0) + Number(li.PenaltyAmount || 0) + Number(li.OtherDeductionAmount || 0);
    g += Number(li.Amount || 0); t += tax; n += Number(li.NetAmount || 0);
    return (
      <tr key={li.LineNo} style={(li.RedirectedToEntryID || li.SplitToEntryID) ? { opacity: 0.6 } : undefined}>
        <td>{e.EntryID + '-' + li.LineNo}</td><td>{payeeTypeLabel(li.PayeeType)}</td><td>{li.CNIC_NTN || ''}</td>
        <td>{li.VendorName || ''}
          {li.RedirectedToEntryID && <span style={{ color: '#93C5FD', fontSize: 11 }}> &#8617; Redirected to <Link id={li.RedirectedToEntryID} onOpen={onOpen} color="#93C5FD" /></span>}
          {li.SplitToEntryID && <span style={{ color: 'var(--amber)', fontSize: 11 }}> &#9986; Payment failed - isolated as <Link id={li.SplitToEntryID} onOpen={onOpen} color="var(--amber)" /></span>}
        </td>
        <td>{li.IBAN || ''}</td><td>{li.IncomeTaxSection || '-'}</td><td className="num">{num(li.Amount)}</td><td className="num">{num(tax)}</td><td className="num">{num(li.NetAmount)}</td>
      </tr>
    );
  });
  return (
    <>
      <div className="table-wrap bav-beneficiaries-table" style={{ marginBottom: 18 }}>
        <table>
          <thead><tr><th>Line ID</th><th>Type</th><th>CNIC</th><th>Beneficiary</th><th>IBAN</th><th>FBR Section</th><th className="num">Gross</th><th className="num">Tax Deductions</th><th className="num">Net</th></tr></thead>
          <tbody>{rows}<tr><td colSpan={6}><b>Total</b></td><td className="num"><b>{num(g)}</b></td><td className="num"><b>{num(t)}</b></td><td className="num"><b>{num(n)}</b></td></tr></tbody>
        </table>
      </div>
      <div className="bav-fin"><FinRow label="NET AMOUNT PAID" amount={n} net /></div>
    </>
  );
}

export default function BillDetail({ entryId, onOpen, onClose }) {
  const [res, setRes] = useState(null);
  const [err, setErr] = useState('');
  const [trail, setTrail] = useState([]);

  useEffect(() => {
    let live = true;
    setRes(null); setErr(''); setTrail([]);
    gs('getBillDetail', entryId).then(r => {
      if (!live) return;
      if (!r || r.success === false) setErr((r && r.message) || 'Could not load this bill.'); else setRes(r);
    }).catch(e => live && setErr('Could not load this bill: ' + e.message));
    gs('getPaymentHistory', entryId).then(ev => live && setTrail(ev || [])).catch(() => {});
    return () => { live = false; };
  }, [entryId]);

  const print = () => {
    document.body.classList.add('printing-audit');
    window.onafterprint = () => { document.body.classList.remove('printing-audit'); window.onafterprint = null; };
    window.print();
  };

  return createPortal(
    <Modal id="billDetailModal" maxWidth={680} z={100} onClose={onClose}>
      <div className="no-print" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
        <h3 style={{ margin: 0 }}>Bill Audit View</h3>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="secondary" onClick={print} title="In the print window choose 'Save as PDF' to keep a PDF copy">Print / Save as PDF</button>
          <button className="secondary" onClick={onClose}>Close</button>
        </div>
      </div>
      {!res && !err && <p>Loading...</p>}
      {err && <p className="error">{err}</p>}
      {res && <BillBody res={res} onOpen={onOpen} />}
      {res && trail.length > 0 && (
        <div className="bav-section" style={{ marginTop: 18 }}>
          <div className="bav-section-title">Payment / Reconciliation Trail</div>
          <div className="table-wrap" style={{ marginTop: 6 }}>
            <table>
              <thead><tr><th>Date</th><th>Event</th><th>By</th><th>Notes</th></tr></thead>
              <tbody>{trail.map((ev, i) => (
                <tr key={i}><td>{fmtDate(ev.EventDate)}</td><td>{ev.EventType}{String(ev.EntryID) !== String(entryId) ? ' (' + ev.EntryID + ')' : ''}</td><td>{ev.LoggedBy || ''}</td><td>{ev.Notes || ''}</td></tr>
              ))}</tbody>
            </table>
          </div>
        </div>
      )}
    </Modal>,
    document.body
  );
}
