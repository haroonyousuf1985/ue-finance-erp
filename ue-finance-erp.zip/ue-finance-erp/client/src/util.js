/* util.js - small helpers shared by the screens */
export const DEFAULT_FY = '2026-27';
export function fyOptions() {
  const out = [];
  for (let i = 0; i < 8; i++) { const y = 2023 + i; out.push(y + '-' + String(y + 1).slice(-2)); }
  return out;
}
export function fmtDate(d) { if (!d) return ''; const dt = new Date(d); return isNaN(dt) ? String(d) : dt.toLocaleDateString(); }
export function num(n) { return Math.round(Number(n || 0)).toLocaleString(); }
/* Net amount: a real 0 stays 0; only a blank falls back to Gross. */
export function netOf(r) { const n = r.NetAmount; return (n === '' || n === undefined || n === null) ? Number(r.Amount || 0) : Number(n); }
export function payeeTypeLabel(t) { return { Vendor: 'Vendor', Employee: 'UE Employee', NonUEEmployee: 'Non-UE Employee', Student: 'Student', Bulk: 'Bulk' }[t] || (t || '-'); }
export function todayISO() { const d = new Date(); const p = n => String(n).padStart(2, '0'); return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()); }

export const IBFT_COLUMNS = [
  ['bankAccountNo', 'Bank Account No'], ['taxpayerStatus', 'TaxPayer Status (Active/Inactive)'], ['cnicNtn', 'CNIC/NTN'],
  ['billPassedDate', 'Bill Passed Date'], ['receivingOffice', 'Office From Where it is received'], ['description', 'Description'],
  ['billId', 'Bill ID'], ['invoiceNo', 'Invoice No.'], ['invoiceDate', 'Invoice Date'], ['billNature', 'Bill Nature'],
  ['beneficiary', 'Beneficiary'], ['iban', 'IBAN'], ['bankShortName', 'Bank Short Name (5th, 6th, 7th and 8th Digit of IBAN)'],
  ['grossAmount', 'Gross Amount'], ['fbrSection', 'FBR Withholding Section'], ['incomeTax', 'Income Tax'], ['salesTax', 'Sales Tax'],
  ['punjabSalesTax', 'Punjab Sales Tax'], ['security', 'Security'], ['penalty', 'Penalty'], ['otherDeduction', 'Other Deduction'], ['netPayment', 'Net Payment']
];
export const IBFT_NUMERIC = new Set(['grossAmount', 'incomeTax', 'salesTax', 'punjabSalesTax', 'security', 'penalty', 'otherDeduction', 'netPayment']);

/* Excel-friendly CSV download. Returns false if there was nothing to export. */
export function exportCSV(rows, columns, filename) {
  if (!rows || !rows.length) return false;
  const header = columns.map(([, label]) => '"' + label.replace(/"/g, '""') + '"').join(',');
  const body = rows.map(row => columns.map(([key]) => '"' + String(row[key] ?? '').replace(/"/g, '""').replace(/\s+/g, ' ').trim() + '"').join(',')).join('\r\n');
  const blob = new Blob(['﻿' + header + '\r\n' + body], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  return true;
}

/* Download a rendered <table> as an Excel-friendly CSV (every row, header and footer included). */
export function tableToCSV(table, filename) {
  if (!table) return false;
  const lines = [];
  table.querySelectorAll('tr').forEach(tr => {
    const cells = [];
    tr.querySelectorAll('th,td').forEach(c => {
      const text = '"' + c.innerText.replace(/\s+/g, ' ').trim().replace(/"/g, '""') + '"';
      cells.push(text);
      for (let i = 1; i < (c.colSpan || 1); i++) cells.push('""');
    });
    if (cells.length) lines.push(cells.join(','));
  });
  if (lines.length < 2) return false;
  const blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  return true;
}
export function campusLabel(ids, all) {
  if (!ids || !ids.length || ids.length === all.length) return 'All Cost Centres';
  const names = all.filter(c => ids.includes(c.CampusID)).map(c => c.CampusName);
  return names.length <= 3 ? names.join(', ') : names.slice(0, 3).join(', ') + ' + ' + (names.length - 3) + ' more';
}
export function oneCampusLabel(id, all) { if (!id) return 'All Cost Centres'; const c = all.find(x => x.CampusID === id); return c ? c.CampusName : id; }
/* does any value of this row contain the typed text? (the "Search loaded results" box) */
export function rowMatches(row, q) {
  q = String(q || '').trim().toLowerCase();
  return !q || Object.values(row).some(v => String(v ?? '').toLowerCase().includes(q));
}
