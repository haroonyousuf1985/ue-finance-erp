import React, { useCallback, useEffect, useState } from 'react';
import { gs, session, logout as apiLogout } from './api.js';
import { ToastProvider } from './ui.jsx';
import Login from './pages/Login.jsx';
import StagePage from './pages/StagePage.jsx';
import Confirmation from './pages/Confirmation.jsx';
import Reconciliation from './pages/Reconciliation.jsx';
import BillDetail from './pages/BillDetail.jsx';
import PasswordModal from './pages/PasswordModal.jsx';
import Admin from './pages/Admin.jsx';
import Reports from './pages/Reports.jsx';
import Diary, { DiaryTrail } from './pages/Diary.jsx';
import Entry from './pages/Entry.jsx';

/* UI-level convenience only - the real enforcement is on the server. */
const ROLE_TABS = {
  Admin: ['diary', 'entry', 'processing', 'passing', 'payment', 'paymentconfirm', 'reconciliation', 'reports', 'admin'],
  AllExceptAdmin: ['diary', 'entry', 'processing', 'passing', 'payment', 'paymentconfirm', 'reports'],
  Accounts: ['diary', 'entry', 'reports'],
  Entry: ['diary', 'entry', 'reports'],
  RA: ['passing', 'diary', 'reports'],
  IBFT: ['payment', 'paymentconfirm', 'reconciliation', 'diary', 'reports'],
  ReportsOnly: ['reports', 'diary'],
  DiaryClerk: ['diary', 'reports']
};
const TAB_LABELS = {
  diary: '0. Diary', entry: '1. New Entry', processing: '2. Processing', passing: '3. Passing', payment: '4. Payment/IBFT',
  paymentconfirm: '5. Confirmation', reconciliation: '6. Reconciliation', reports: 'Reports', admin: 'Admin'
};
const ORDER = ['diary', 'entry', 'processing', 'passing', 'payment', 'paymentconfirm', 'reconciliation', 'reports', 'admin'];

function useTheme() {
  const [light, setLight] = useState(() => { try { return localStorage.getItem('themePreference') !== 'dark'; } catch (e) { return true; } });
  useEffect(() => { document.body.classList.toggle('light', light); }, [light]);
  const toggle = () => setLight(v => { const n = !v; try { localStorage.setItem('themePreference', n ? 'light' : 'dark'); } catch (e) {} return n; });
  return [light, toggle];
}

function Shell({ user, weak, onLogout }) {
  const [light, toggleTheme] = useTheme();
  const tabs = ORDER.filter(t => (ROLE_TABS[user.role] || ['reports']).includes(t));
  const [tab, setTab] = useState(tabs[0]);
  const [bill, setBill] = useState(null);
  const [showPw, setShowPw] = useState(weak);
  const [badges, setBadges] = useState({});
  const [entryReq, setEntryReq] = useState({ n: 0 });   // asks New Entry to open a Diary item or to edit a bill
  const [trail, setTrail] = useState(null);
  const [seenEntry, setSeenEntry] = useState(false);

  const refreshBadges = useCallback(() => {
    const has = t => tabs.includes(t), set = (k, v) => setBadges(b => ({ ...b, [k]: v }));
    if (has('processing') || has('passing') || has('payment')) {
      gs('getPipelineCounts', '').then(c => { set('processing', c.Received); set('passing', c.Processed); set('payment', c.Passed); }).catch(() => {});
    }
    if (has('diary')) {
      (user.role === 'DiaryClerk'
        ? gs('getPendingDiaryItems', { minDaysWaiting: 10 }, user.username)
        : gs('getUserDiaryQueue', user.username, {})).then(l => set('diary', l.length)).catch(() => {});
    }
    if (has('paymentconfirm')) gs('getPaymentConfirmCount', '').then(n => set('paymentconfirm', n)).catch(() => {});
    if (has('reconciliation')) {
      Promise.all([gs('getNeedsCorrectionBills', '').catch(() => []), gs('getLineLevelConfirmationQueue', '', true).catch(() => [])])
        .then(([a, b]) => set('reconciliation', (a || []).length + (b || []).length));
    }
  }, [user.username, user.role]);   // eslint-disable-line
  useEffect(() => { refreshBadges(); }, [refreshBadges, tab]);

  // messages from the not-yet-converted screens
  useEffect(() => {
    const h = e => {
      if (!e.data) return;
      if (e.data.type === 'session-ended') onLogout(true);
      if (e.data.type === 'change-password') setShowPw(true);
    };
    window.addEventListener('message', h);
    return () => window.removeEventListener('message', h);
  }, [onLogout]);

  const common = { user, onOpenBill: setBill, onChanged: refreshBadges };
  let page = null;
  if (tab === 'diary') page = <Diary user={user} canEnter={tabs.includes('entry')} onOpenBill={setBill} onChanged={refreshBadges} onEnterBill={id => { setEntryReq(r => ({ n: r.n + 1, diaryId: id })); setSeenEntry(true); setTab('entry'); }} />;
  else if (tab === 'processing' || tab === 'passing' || tab === 'payment') page = <StagePage key={tab} stage={tab} {...common} />;
  else if (tab === 'admin') page = <Admin user={user} onOpenBill={setBill} onChanged={refreshBadges} onEditBill={id => { setEntryReq(r => ({ n: r.n + 1, editId: id })); setSeenEntry(true); setTab('entry'); }} />;
  else if (tab === 'reports') page = <Reports user={user} onOpenBill={setBill} onOpenDiaryTrail={setTrail} />;
  else if (tab === 'paymentconfirm') page = <Confirmation {...common} />;
  else if (tab === 'reconciliation') page = <Reconciliation {...common} />;

  return (
    <div id="appScreen" style={{ display: 'block' }}>
      <header className="no-print">
        <h1>ERP &amp; Budget Utilization Module - UE Finance</h1>
        <div className="user-info">
          <span>{user.fullName} ({user.role})</span>
          <button className="theme-toggle-btn" onClick={toggleTheme} title="Switch between dark and light mode">{light ? '☀️ Light' : '🌙 Dark'}</button>
          <button onClick={() => setShowPw(true)}>Password</button>
          <button onClick={() => onLogout(false)}>Logout</button>
        </div>
      </header>
      <nav className="tabs no-print">
        {tabs.map(t => (
          <button key={t} className={'tab-btn' + (t === tab ? ' active' : '')} onClick={() => { if (t === 'entry') setSeenEntry(true); setTab(t); }}>
            {TAB_LABELS[t]}{badges[t] > 0 && <span className="badge" style={{ display: 'inline-block' }}>{badges[t]}</span>}
          </button>
        ))}
      </nav>
      {page}
      {seenEntry && tabs.includes('entry') && <div style={{ display: tab === 'entry' ? 'block' : 'none' }}><Entry user={user} request={entryReq} onSaved={refreshBadges} onOpenDiaryTrail={setTrail} /></div>}
      {trail && <DiaryTrail diaryId={trail} onClose={() => setTrail(null)} />}
      {bill && <BillDetail entryId={bill} onOpen={setBill} onClose={() => setBill(null)} />}
      {showPw && <PasswordModal user={user} forced={weak && showPw} onClose={() => setShowPw(false)} />}
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(() => (session.token() ? session.user() : null));
  const [weak, setWeak] = useState(false);
  useTheme();

  const out = useCallback(async expired => {
    if (!expired) await apiLogout();
    session.clear(); setUser(null); setWeak(false);
    if (expired) window.alert('Your session has ended or is no longer valid. Please log in again.');
  }, []);
  useEffect(() => { session.onExpired(() => out(true)); }, [out]);

  return (
    <ToastProvider>
      {user
        ? <Shell key={user.username} user={user} weak={weak} onLogout={out} />
        : <Login onLoggedIn={(u, w) => { setUser(u); setWeak(w); }} />}
    </ToastProvider>
  );
}
