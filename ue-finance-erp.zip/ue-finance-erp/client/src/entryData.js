/* entryData.js - the fixed lists and the pure helper functions behind the New Entry screen
   (nature-of-bill lists, CSV reading, checks for CNIC / NTN / IBAN, the bulk CSV templates, and the
   tax-parameter builder). Nothing here touches the screen. */
import { DEFAULT_FY, todayISO } from './util.js';

export const VENDOR_BILL_NATURES = [
  { group: 'Taxable', options: [['Supply', 'Supply / Sale of Goods'], ['Service', 'Rendering of Services'], ['Contract', 'Execution of Contract']] },
  { group: 'Not Taxable', options: [['Release of Security', 'Release of Security']] }
];
export const EMPLOYEE_149_OPTIONS = [
  ['UE Visiting Faculty', 'UE Visiting Faculty'], ['Non-Teaching', 'Non-Teaching'], ['Additional Duty', 'Additional Duty'],
  ['Paper Setting/Marking', 'Paper Setting/Marking'], ['Conduct of Exam', 'Conduct of Exam'], ['Examiners', 'Examiners'],
  ['Thesis Evaluation', 'Thesis Evaluation'], ['Honorarium', 'Honorarium'], ['Contingency', 'Contingency']
];
export const UE_ONLY_TAXABLE_OPTIONS = [['Overtime', 'Overtime']];
export const UE_EMPLOYEE_BILL_NATURES = [
  { group: 'Taxable (Section 149)', options: EMPLOYEE_149_OPTIONS.concat(UE_ONLY_TAXABLE_OPTIONS) },
  { group: 'Not Taxable', options: [
    ['Reimbursement of Fee', 'Reimbursement of Fee'], ['Medical', 'Medical'], ['Advance', 'Advance'],
    ['TADA', 'TADA'], ['Release of Security', 'Release of Security'], ['GPF Advance', 'GPF Advance'],
    ['Benevolent Fund', 'Benevolent Fund'], ['Mobile Bill', 'Mobile Bill'], ['Refreshment', 'Refreshment'], ['POL', 'POL'],
    ['Contingency (Non-Taxable)', 'Contingency (Non-Taxable)']] }
];
export const UE_NON_TAXABLE_NATURES_BULK = UE_EMPLOYEE_BILL_NATURES[1].options.map(o => o[0]);
export const SECTION_156_NATURE = "Honoraria to Statutory Body Meeting's Member";
export const NONUE_EMPLOYEE_BILL_NATURES = [
  { group: 'Taxable (Section 149)', options: EMPLOYEE_149_OPTIONS },
  { group: 'Taxable (Section 156)', options: [[SECTION_156_NATURE, SECTION_156_NATURE]] }
];
export const STUDENT_BILL_NATURES = [{ group: null, options: [['Scholarship', 'Scholarship'], ['Refund of Fee', 'Refund of Fee']] }];
export const VENDOR_TAXABLE_NATURES = ['Supply', 'Service', 'Contract'];
export const EMPLOYEE_149_NATURES = EMPLOYEE_149_OPTIONS.map(o => o[0]);
export const UE_ONLY_TAXABLE_NATURES = UE_ONLY_TAXABLE_OPTIONS.map(o => o[0]);
export const VENDOR_SERVICE_CATEGORIES = [
  ['Specified Corporate Services', 'Specified Corporate Services (Transport, Courier, Hotel, Security, Software Dev, etc.)'],
  ['IT & IT-Enabled Services (ITeS)', 'IT & IT-Enabled Services (ITeS)'],
  ['Print & Electronic Media Advertisement', 'Print & Electronic Media Advertisement (Final Tax)'],
  ['General Services - Company', 'General Services - Company'],
  ['General Services - Individual/AOP', 'General Services - Individual/AOP']
];
export const REFUND_CATEGORIES = ['Library Security', 'Subject Repeat Fee', 'Dropped Student', 'Extra Deposited', 'Admission Withdrawal', 'Admission to Other Campus', 'Discontinued Program'];
export const BENEVOLENT_SUBS = ['Marriage Grant', 'Funeral Grant', 'Education Scholarship', 'Employees Fee Reimbursement', 'Farewell Grant', 'Monthly Grant'];
export const VISITING_NATURES = ['UE Visiting Faculty', 'Paper Setting/Marking'];

/* CNIC: 35201-1222334-4. NTN: 12345678. IBAN: PK + 22 letters/digits (24 in all). */
export const isValidCnic = v => /^\d{5}-\d{7}-\d{1}$/.test(String(v || '').trim());
export const isValidNtn = v => /^\d{8}$/.test(String(v || '').trim());
export const isValidCnicOrNtn = v => { const s = String(v || '').trim(); return !!s && (isValidCnic(s) || isValidNtn(s)); };
export const isValidIban = v => /^PK\d{2}[A-Z0-9]{20}$/.test(String(v || '').trim().toUpperCase());
export const isTruthyCsv = v => ['yes', 'true', '1', 'y'].includes(String(v || '').trim().toLowerCase());

/* The part of a payee/nature choice that decides which tax rows are relevant. */
export function natureFlags(payeeType, nature, nonueMethod) {
  const isStudent = payeeType === 'Student', isEmployee = payeeType === 'Employee', isNonUE = payeeType === 'NonUEEmployee', isVendor = payeeType === 'Vendor';
  const is149 = (isEmployee || isNonUE) && EMPLOYEE_149_NATURES.includes(nature);
  const isSection156 = isNonUE && nature === SECTION_156_NATURE;
  const noTax = isStudent || (isVendor && !VENDOR_TAXABLE_NATURES.includes(nature)) || ((isEmployee || isNonUE) && !is149 && !isSection156);
  const nonue153 = isNonUE && is149 && nonueMethod === 'Section153_1b';
  return { isStudent, isEmployee, isNonUE, isVendor, is149, isSection156, noTax, nonue153, isRelease: !isStudent && nature === 'Release of Security' };
}

/* Same effect as the original "onBillNatureChange": ticks/unticks the tax boxes that suit this payee and nature. */
export function applyNature(f) {
  const n = natureFlags(f.payeeType, f.nature, f.nonueMethod);
  const patch = {};
  if (n.noTax) { patch.applyIT = false; patch.applyST = false; patch.applyPST = false; }
  else if (n.isEmployee || n.isNonUE) { patch.applyIT = true; patch.applyST = false; patch.applyPST = false; }
  else { patch.applyIT = true; patch.applyST = f.nature === 'Supply'; patch.applyPST = f.nature === 'Service' || f.nature === 'Contract'; }
  const next = { ...f, ...patch };
  if (!next.applyST) next.manualST = { ...next.manualST, on: false };
  if (!next.applyPST) next.manualPST = { ...next.manualPST, on: false };
  if (!(n.isVendor && !n.noTax)) {
    next.security = { ...next.security, on: false };
    next.penalty = { ...next.penalty, on: false };
    next.other = { ...next.other, on: false };
  }
  if (!n.isStudent) next.studDed = { ...next.studDed, on: false };
  return next;
}

const rateRow = (mode = 'rate') => ({ on: false, mode, rate: '', amount: '' });
export function blankForm() {
  return {
    entryMode: 'single', receivingOffice: '', payFrom: '', date: todayISO(), fy: DEFAULT_FY, billNo: '', campus: '',
    headMode: 'single', headId: '', splits: [{ headId: '', amount: '' }, { headId: '', amount: '' }],
    payeeType: 'Vendor',
    vendor: '', cnic: '', iban: '', bank: '',
    employeeId: '', empName: '', empDesignation: '', empCnic: '', empIban: '', empBank: '', empNotFound: false,
    nonueCnic: '', nonueName: '', nonueIban: '', nonueBank: '',
    studentId: '', program: '', session: '', shift: 'Morning', studentCnic: '', benTitle: '', benIban: '',
    annualIncome: '', annualIncomeUE: '', affidavit: false,
    amount: '', billDesc: '',
    nature: '', refundCat: REFUND_CATEGORIES[0], refundOther: '', thesisClass: '', thesisStudent: '',
    visProgram: '', visSubject: '', visCrHrs: '', visRate: '', visLectures: '',
    benevSub: BENEVOLENT_SUBS[0], nonueMethod: 'Section149', taxpayerType: 'Individual/AOP', serviceCat: VENDOR_SERVICE_CATEGORIES[0][0], examSub: '',
    fbrStatus: 'Filer', praStatus: 'Active', applyIT: false, applyST: false, applyPST: false,
    pstInvoiceNo: '', vendorInvoiceDate: '', contractCat: 'NewProjects',
    manualTax: { ...rateRow(), section: '' }, manualST: rateRow(), manualPST: rateRow(),
    security: { ...rateRow(), basis: '' }, penalty: { ...rateRow('amount'), basis: '' }, other: { ...rateRow('amount'), category: '', basis: '' },
    studDed: { on: false, category: '', basis: '', amount: '' }
  };
}

/* Everything the server needs to work out the taxes (same fields the original screen sent). */
export function taxParams(f) {
  const cnic = f.payeeType === 'NonUEEmployee' ? f.nonueCnic : f.cnic;
  return {
    grossAmount: f.amount || 0, payeeType: f.payeeType, billNature: f.nature,
    refundCategory: f.refundCat === '__other__' ? f.refundOther : f.refundCat,
    fbrStatus: f.fbrStatus, serviceCategory: f.serviceCat, taxpayerType: f.taxpayerType, praStatus: f.praStatus, fy: f.fy || DEFAULT_FY,
    employeeId: f.employeeId, cnic, examSubCategory: f.examSub, thesisClass: f.thesisClass, thesisStudentName: f.thesisStudent,
    visitingProgram: f.visProgram, visitingSubject: f.visSubject, visitingCrHrs: f.visCrHrs, visitingRate: f.visRate, visitingLectures: f.visLectures,
    benevolentFundSubCategory: f.benevSub, nonUeTaxMethod: f.nonueMethod, contractCategory: f.contractCat,
    manualTaxOverride: f.manualTax.on, manualTaxSection: f.manualTax.section, manualTaxMode: f.manualTax.mode, manualTaxRate: f.manualTax.rate, manualTaxAmount: f.manualTax.amount,
    manualSalesTaxOverride: f.manualST.on, salesTaxMode: f.manualST.mode, salesTaxManualRate: f.manualST.rate, salesTaxManualAmount: f.manualST.amount,
    manualPSTOverride: f.manualPST.on, pstMode: f.manualPST.mode, pstManualRate: f.manualPST.rate, pstManualAmount: f.manualPST.amount,
    affidavitLowIncome: f.affidavit,
    applyIncomeTax: f.applyIT, applySalesTax: f.applyST, applyPST: f.applyPST,
    applySecurity: f.security.on, securityBasis: f.security.basis, securityMode: f.security.mode, securityRate: f.security.rate, securityAmount: f.security.amount,
    applyPenalty: f.penalty.on, penaltyBasis: f.penalty.basis, penaltyMode: f.penalty.mode, penaltyRate: f.penalty.rate, penaltyAmount: f.penalty.amount,
    applyOtherDeduction: f.other.on, otherDeductionCategory: f.other.category, otherDeductionBasis: f.other.basis, otherDeductionMode: f.other.mode,
    otherDeductionRate: f.other.rate, otherDeductionAmount: f.other.amount,
    applyStudentDeduction: f.studDed.on, studentDeductionCategory: f.studDed.category, studentDeductionBasis: f.studDed.basis, studentDeductionAmount: f.studDed.amount
  };
}

/* The payee's name as the original screen resolved it (used for the "security held" lookup). */
export function payeeName(f) {
  return f.payeeType === 'Employee' ? f.empName : f.payeeType === 'NonUEEmployee' ? f.nonueName : f.payeeType === 'Student' ? f.benTitle : f.vendor;
}
export function incomeKey(f) {
  return f.payeeType === 'Employee' ? f.employeeId.trim() : f.payeeType === 'NonUEEmployee' ? f.nonueCnic.trim() : '';
}

/* A date from the server -> yyyy-mm-dd in the user's own calendar. */
export function toDateInput(d) {
  if (!d) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(String(d))) return String(d);
  const dt = new Date(d);
  if (isNaN(dt)) return '';
  const p = n => String(n).padStart(2, '0');
  return dt.getFullYear() + '-' + p(dt.getMonth() + 1) + '-' + p(dt.getDate());
}

/* Fill the form from a saved bill (edit mode). */
export function formFromBill(e, res, base) {
  let f = { ...base };
  f.entryMode = 'single';
  f.date = toDateInput(e.EntryDate); f.fy = e.FY || DEFAULT_FY; f.billNo = e.BillNo || ''; f.billDesc = e.BillDescription || ''; f.amount = e.Amount || '';
  f.payFrom = e.PayFromAccountID || ''; f.receivingOffice = e.ReceivingOfficeID || '';
  f.pstInvoiceNo = e.PSTInvoiceNo || ''; f.vendorInvoiceDate = toDateInput(e.VendorInvoiceDate);
  f.campus = e.CampusID || '';
  if (res.headSplits && res.headSplits.length) { f.headMode = 'multi'; f.splits = res.headSplits.map(sp => ({ headId: sp.HeadID, amount: sp.Amount })); }
  else { f.headMode = 'single'; f.headId = e.HeadID || ''; }
  const pt = e.PayeeType || 'Vendor';
  f.payeeType = pt;
  if (pt === 'Vendor') { f.vendor = e.VendorName || ''; f.cnic = e.CNIC_NTN || ''; f.iban = e.IBAN || ''; f.bank = e.BankName || ''; }
  else if (pt === 'Employee') { f.employeeId = e.EmployeeID || ''; }
  else if (pt === 'NonUEEmployee') { f.nonueCnic = e.CNIC_NTN || ''; f.nonueName = e.VendorName || ''; f.nonueIban = e.IBAN || ''; f.nonueBank = e.BankName || ''; }
  else if (pt === 'Student') {
    f.studentId = e.StudentID || ''; f.program = e.Program || ''; f.session = e.Session || ''; if (e.Shift) f.shift = e.Shift;
    f.benTitle = e.VendorName || ''; f.benIban = e.IBAN || ''; f.studentCnic = e.CNIC_NTN || '';
  }
  f.nature = e.BillNature || '';
  if (e.NonUETaxMethod) f.nonueMethod = e.NonUETaxMethod;
  f = applyNature(f);
  if (e.RefundCategory) { if (REFUND_CATEGORIES.includes(e.RefundCategory)) f.refundCat = e.RefundCategory; else { f.refundCat = '__other__'; f.refundOther = e.RefundCategory; } }
  if (e.TaxpayerType) f.taxpayerType = e.TaxpayerType;
  if (e.ServiceCategory) f.serviceCat = e.ServiceCategory;
  if (e.FBRStatus) f.fbrStatus = e.FBRStatus;
  if (e.PRAStatus) f.praStatus = e.PRAStatus;
  if (e.ExamSubCategory) f.examSub = e.ExamSubCategory;
  if (e.ThesisClass) f.thesisClass = e.ThesisClass;
  if (e.ThesisStudentName) f.thesisStudent = e.ThesisStudentName;
  if (e.VisitingProgram) f.visProgram = e.VisitingProgram;
  if (e.VisitingSubject) f.visSubject = e.VisitingSubject;
  if (e.VisitingCrHrs) f.visCrHrs = e.VisitingCrHrs;
  if (e.VisitingRate) f.visRate = e.VisitingRate;
  if (e.VisitingLectures) f.visLectures = e.VisitingLectures;
  if (e.BenevolentFundSubCategory) f.benevSub = e.BenevolentFundSubCategory;
  if (e.ContractCategory) f.contractCat = e.ContractCategory;
  if (e.ManualTaxOverride) f.manualTax = { on: true, section: e.ManualTaxSection || '', mode: e.ManualTaxMode || 'rate', rate: e.ManualTaxRate || '', amount: e.ManualTaxAmount || '' };
  if (e.ManualSalesTaxOverride) f.manualST = { on: true, mode: e.SalesTaxMode || 'rate', rate: e.SalesTaxRate ? (e.SalesTaxRate * 100).toFixed(2) : '', amount: e.SalesTaxAmount || '' };
  if (e.ManualPSTOverride) f.manualPST = { on: true, mode: e.PSTMode || 'rate', rate: e.PSTRate ? (e.PSTRate * 100).toFixed(2) : '', amount: e.PSTAmount || '' };
  if (e.AffidavitLowIncome) f.affidavit = true;
  f.applyIT = Number(e.IncomeTaxAmount) > 0 || !!e.IncomeTaxSection;
  f.applyST = !!e.SalesTaxApplied;
  f.applyPST = !!e.PSTApplied;
  if (e.SecurityApplied) f.security = { on: true, mode: 'amount', rate: '', amount: e.SecurityAmount || '', basis: e.SecurityBasis || '' };
  if (e.PenaltyApplied) f.penalty = { on: true, mode: 'amount', rate: '', amount: e.PenaltyAmount || '', basis: e.PenaltyBasis || '' };
  if (e.OtherDeductionApplied) f.other = { on: true, mode: 'amount', rate: '', amount: e.OtherDeductionAmount || '', category: e.OtherDeductionCategory || '', basis: e.OtherDeductionBasis || '' };
  if (e.StudentDeductionApplied) f.studDed = { on: true, category: e.StudentDeductionCategory || '', basis: e.StudentDeductionBasis || '', amount: e.StudentDeductionAmount || '' };
  return f;
}

/* ---------- CSV reading ---------- */
// handles quoted fields, embedded commas and escaped quotes ("")
export function parseCSV(text) {
  const rows = [];
  let row = [], field = '', inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') { if (text[i + 1] === '"') { field += '"'; i++; } else inQuotes = false; }
      else field += c;
    } else if (c === '"') inQuotes = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(field); field = ''; rows.push(row); row = []; }
    else field += c;
  }
  if (field.length || row.length) { row.push(field); rows.push(row); }
  return rows.filter(r => r.some(cell => String(cell).trim() !== ''));
}

export const BULK_HINTS = {
  Vendor: 'Columns: VendorName, CNIC, IBAN, BankName, Amount, IncomeTaxAmount, SalesTaxAmount, PSTAmount, SecurityAmount, PenaltyAmount, OtherDeductionAmount, Description, FBRSection. FBRSection is REQUIRED on any row that has an IncomeTaxAmount - it is the FBR withholding section applied to that row, e.g. "153(1)(a) - Supply of Goods" - it is shown per beneficiary on reports. If a CNIC already on file is used, Name/IBAN/Bank are auto-fetched - leave them blank or matching, they will be overwritten from the existing record. If any row has a PSTAmount, fill in the PST Invoice Number/Date below. Receiving Office and Pay From Account are set once, above, for the whole bill.',
  Student: 'Columns: StudentID, Name, CNIC, IBAN, Program, Session, Shift, Amount, DeductionAmount, Description, ReceivingOffice, PayFromAccount. If a Student ID already on file is used, Name/CNIC/IBAN/Program/Session/Shift are auto-fetched. ReceivingOffice/PayFromAccount are OPTIONAL per row (must match an existing office name / "Account Title - Bank Name" exactly) - leave blank to use the Received From/Pay From Account picked above for the whole bill; fill them in only for a row that was actually received from, or is to be paid from, something different.',
  Employee: 'Columns: PayeeType (Employee or NonUEEmployee), EmployeeID (UE - auto-fetches Name/CNIC/IBAN/Bank, do not type them) / CNIC (Non-UE - auto-fetches if already on file), Name/IBAN/BankName (Non-UE only, for a brand-new person), Nature (Overtime and Mobile Bill/Refreshment/POL are UE-only; Honorarium and everything else are shared with Non-UE), ExamSubCategory (Conduct of Exam only), ThesisClass/ThesisStudentName (Thesis Evaluation only), BenevolentFundSubCategory (Benevolent Fund only, UE only), VisitingProgram/VisitingSubject/VisitingCrHrs/VisitingRate/VisitingLectures (required for UE Visiting Faculty and Paper Setting/Marking, either payee type), AffidavitLowIncome (Non-UE only, Yes/No - if Yes, Section 149 tax is zero), TaxMethod (Non-UE only, leave blank or "Section149" for the slab system, or "Section153_1b" for the flat-rate alternative), TaxpayerStatus (Non-UE only, required if TaxMethod is Section153_1b - "Active" or "Inactive"), Amount, Description, ReceivingOffice, PayFromAccount. Income Tax itself is always calculated automatically - there is no Income Tax column to fill in, and each row gets its own FBR Section. ReceivingOffice/PayFromAccount are OPTIONAL per row (must match an existing office name / "Account Title - Bank Name" exactly) - leave blank to use what was picked above for the whole bill.'
};

const emptyEmp = { PayeeType: 'Employee', EmployeeID: '', CNIC: '', Name: '', IBAN: '', BankName: '', Nature: '', ExamSubCategory: '', ThesisClass: '', ThesisStudentName: '', BenevolentFundSubCategory: '', AffidavitLowIncome: '', TaxMethod: '', TaxpayerStatus: '' };
const nonue = (o) => ({ ...emptyEmp, PayeeType: 'NonUEEmployee', ...o });
const ue = (o) => ({ ...emptyEmp, ...o });
export const BULK_TEMPLATES = {
  Vendor: {
    columns: ['VendorName', 'CNIC', 'IBAN', 'BankName', 'Amount', 'IncomeTaxAmount', 'SalesTaxAmount', 'PSTAmount', 'SecurityAmount', 'PenaltyAmount', 'OtherDeductionAmount', 'Description', 'FBRSection'],
    examples: [
      { VendorName: 'ABC Traders (Pvt) Ltd', CNIC: '1234567890123', IBAN: 'PK00BANK0000000000000001', BankName: 'Bank Alpha', Amount: '100000', IncomeTaxAmount: '5000', SalesTaxAmount: '8475', PSTAmount: '0', SecurityAmount: '0', PenaltyAmount: '0', OtherDeductionAmount: '0', Description: 'Supply of goods - Filer, Company', FBRSection: '153(1)(a) - Supply of Goods' },
      { VendorName: 'XYZ Services', CNIC: '9876543210123', IBAN: 'PK00BANK0000000000000002', BankName: 'Bank Beta', Amount: '50000', IncomeTaxAmount: '4500', SalesTaxAmount: '0', PSTAmount: '8000', SecurityAmount: '2500', PenaltyAmount: '0', OtherDeductionAmount: '0', Description: 'Rendering of services, Security deducted', FBRSection: '153(1)(b) - Services' },
      { VendorName: 'Build & Co Contractors', CNIC: '1122334455667', IBAN: 'PK00BANK0000000000000003', BankName: 'Bank Gamma', Amount: '200000', IncomeTaxAmount: '15000', SalesTaxAmount: '0', PSTAmount: '0', SecurityAmount: '10000', PenaltyAmount: '5000', OtherDeductionAmount: '0', Description: 'Execution of contract', FBRSection: '153(1)(c) - Execution of Contracts' },
      { VendorName: 'Known Vendor (CNIC already on file)', CNIC: '1234567890123', IBAN: '', BankName: '', Amount: '30000', IncomeTaxAmount: '1500', SalesTaxAmount: '0', PSTAmount: '0', SecurityAmount: '0', PenaltyAmount: '0', OtherDeductionAmount: '0', Description: 'IBAN/Bank left blank - auto-fetched from CNIC already on file', FBRSection: '153(1)(a) - Supply of Goods' }
    ]
  },
  Student: {
    columns: ['StudentID', 'Name', 'CNIC', 'IBAN', 'Program', 'Session', 'Shift', 'Amount', 'DeductionAmount', 'Description', 'ReceivingOffice', 'PayFromAccount'],
    examples: [
      { StudentID: 'S1001', Name: 'Ahmed Raza', CNIC: '3520112345678', IBAN: 'PK00BANK0000000000000010', Program: 'BS Computer Science', Session: '2023-2027', Shift: 'Morning', Amount: '25000', DeductionAmount: '0', Description: 'Scholarship - full amount, no deduction', ReceivingOffice: '', PayFromAccount: '' },
      { StudentID: 'S1002', Name: 'Sana Malik', CNIC: '3520187654321', IBAN: 'PK00BANK0000000000000011', Program: 'BBA', Session: '2022-2026', Shift: 'Evening', Amount: '15000', DeductionAmount: '0', Description: 'Refund of Fee - Extra Deposited', ReceivingOffice: '', PayFromAccount: '' },
      { StudentID: 'S1003', Name: 'Bilal Hussain', CNIC: '3520111223344', IBAN: 'PK00BANK0000000000000012', Program: 'BS Mathematics', Session: '2023-2027', Shift: 'Morning', Amount: '8000', DeductionAmount: '1000', Description: 'Refund of Fee - Library Security, with a deduction retained', ReceivingOffice: '', PayFromAccount: '' },
      { StudentID: 'S1001', Name: '', CNIC: '', IBAN: '', Program: '', Session: '', Shift: '', Amount: '5000', DeductionAmount: '0', Description: 'Other fields left blank - auto-fetched because Student ID S1001 already exists (see row 1)', ReceivingOffice: '', PayFromAccount: '' },
      { StudentID: 'S1004', Name: 'Zara Iqbal', CNIC: '3520155667788', IBAN: 'PK00BANK0000000000000013', Program: 'BS Physics', Session: '2023-2027', Shift: 'Morning', Amount: '10000', DeductionAmount: '0', Description: 'Received from and paid via a DIFFERENT office/account than the rest of this bill - type the exact office name / "Account Title - Bank Name" here', ReceivingOffice: 'Main Campus Office', PayFromAccount: 'Operating Account - Bank Alpha' }
    ]
  },
  Employee: {
    columns: ['PayeeType', 'EmployeeID', 'CNIC', 'Name', 'IBAN', 'BankName', 'Nature', 'ExamSubCategory', 'ThesisClass', 'ThesisStudentName', 'BenevolentFundSubCategory', 'VisitingProgram', 'VisitingSubject', 'VisitingCrHrs', 'VisitingRate', 'VisitingLectures', 'AffidavitLowIncome', 'TaxMethod', 'TaxpayerStatus', 'Amount', 'Description', 'ReceivingOffice', 'PayFromAccount'],
    examples: [
      ue({ EmployeeID: 'E101', Nature: 'UE Visiting Faculty', VisitingProgram: 'BS Computer Science', VisitingSubject: 'Data Structures', VisitingCrHrs: '3', VisitingRate: '2000', VisitingLectures: '20', Amount: '40000', Description: 'Taxable - Section 149 slab, calculated automatically. Program/Subject/Cr. Hrs./Rate/Lectures are required for this Nature.' }),
      ue({ EmployeeID: 'E102', Nature: 'Conduct of Exam', ExamSubCategory: 'Mid-Term Invigilation', Amount: '10000', Description: 'Taxable - Section 149, sub-category filled in for Conduct of Exam' }),
      ue({ EmployeeID: 'E101', Nature: 'Medical', Amount: '5000', Description: 'Not Taxable - Medical, tax is always 0 regardless' }),
      ue({ EmployeeID: 'E103', Nature: 'TADA', Amount: '3000', Description: 'Not Taxable - TADA, tax is always 0 regardless' }),
      ue({ EmployeeID: 'E104', Nature: 'Thesis Evaluation', ThesisClass: 'BS Computer Science - 7th', ThesisStudentName: 'Ahmed Raza', Amount: '8000', Description: 'Taxable - Section 149, Class and Student Name required' }),
      ue({ EmployeeID: 'E105', Nature: 'Benevolent Fund', BenevolentFundSubCategory: 'Marriage Grant', Amount: '50000', Description: 'Not Taxable - Benevolent Fund, sub-category required, tax is always 0 regardless' }),
      nonue({ CNIC: '3520112223334', Name: 'Visiting Examiner - New', IBAN: 'PK00BANK0000000000000020', BankName: 'Bank Delta', Nature: 'Examiners', AffidavitLowIncome: 'No', TaxMethod: 'Section149', Amount: '12000', Description: 'Non-UE, brand new - tax calculated automatically under Section 149' }),
      nonue({ CNIC: '3520112223334', Nature: 'Examiners', AffidavitLowIncome: 'No', TaxMethod: 'Section149', Amount: '12000', Description: 'Same person, later row - Name/IBAN/Bank auto-fetched; tax builds on the row above, even within the same file' }),
      nonue({ CNIC: '3520199998888', Name: 'Affidavit Example', IBAN: 'PK00BANK0000000000000021', BankName: 'Bank Delta', Nature: 'Examiners', AffidavitLowIncome: 'Yes', TaxMethod: 'Section149', Amount: '12000', Description: 'Affidavit of Low Income submitted - Section 149 tax is zero' }),
      nonue({ CNIC: '3520144445555', Name: '153(1)(b) Active Example', IBAN: 'PK00BANK0000000000000024', BankName: 'Bank Delta', Nature: 'Examiners', AffidavitLowIncome: 'No', TaxMethod: 'Section153_1b', TaxpayerStatus: 'Active', Amount: '20000', Description: 'Section 153(1)(b) - Services (Individual/AOP), Active/Registered Taxpayer rate' }),
      nonue({ CNIC: '3520133334444', Name: '153(1)(b) Inactive Example', IBAN: 'PK00BANK0000000000000025', BankName: 'Bank Delta', Nature: 'Examiners', AffidavitLowIncome: 'No', TaxMethod: 'Section153_1b', TaxpayerStatus: 'Inactive', Amount: '20000', Description: 'Section 153(1)(b) at the Inactive Taxpayer rate' }),
      nonue({ CNIC: '3520155556666', Name: 'Board Member Example', IBAN: 'PK00BANK0000000000000022', BankName: 'Bank Delta', Nature: "Honoraria to Statutory Body Meeting's Member", AffidavitLowIncome: 'No', Amount: '20000', Description: 'Section 156 Honoraria - flat rate, calculated automatically' }),
      nonue({ CNIC: '3520166667777', Name: 'Thesis Examiner Example', IBAN: 'PK00BANK0000000000000023', BankName: 'Bank Delta', Nature: 'Thesis Evaluation', ThesisClass: 'BS Mathematics - 8th', ThesisStudentName: 'Bilal Hussain', AffidavitLowIncome: 'No', TaxMethod: 'Section149', Amount: '8000', Description: 'Non-UE - Section 149 slab, calculated automatically' }),
      ue({ EmployeeID: 'E106', Nature: 'Non-Teaching', Amount: '15000', Description: 'Received from and paid via a DIFFERENT office/account than the rest of this bill - type the exact office name / "Account Title - Bank Name" here', ReceivingOffice: 'Main Campus Office', PayFromAccount: 'Operating Account - Bank Alpha' })
    ]
  }
};

/* Reads the uploaded rows. Returns { items, errors }. lookups = { employees, nonue, vendors, students, offices, accounts } */
export function parseBulkRows(rows, bulkType, lookups) {
  const header = rows[0].map(h => h.trim()), dataRows = rows.slice(1);
  const errors = [], items = [];
  const { employees, nonue: nonueMap, vendors, students, offices, accounts } = lookups;
  const resolveOfficeAccount = (obj, rowNum) => {
    let receivingOfficeId = '', payFromAccountId = '';
    const officeName = String(obj.ReceivingOffice || '').trim();
    if (officeName) {
      const o = offices.find(x => x.OfficeName.toLowerCase() === officeName.toLowerCase());
      if (!o) errors.push('Row ' + rowNum + ': ReceivingOffice "' + officeName + '" does not match any office on file (Admin > Receiving Offices).'); else receivingOfficeId = o.OfficeID;
    }
    const accountName = String(obj.PayFromAccount || '').trim();
    if (accountName) {
      const a = accounts.find(x => (x.AccountTitle + ' - ' + x.BankName).toLowerCase() === accountName.toLowerCase());
      if (!a) errors.push('Row ' + rowNum + ': PayFromAccount "' + accountName + '" does not match any account on file (must be exactly "Account Title - Bank Name").'); else payFromAccountId = a.AccountID;
    }
    return { receivingOfficeId, payFromAccountId };
  };
  dataRows.forEach((cells, idx) => {
    const obj = {};
    header.forEach((h, i) => { obj[h] = (cells[i] || '').trim(); });
    const rowNum = idx + 2;
    const amount = Number(obj.Amount);
    if (!amount || amount <= 0) { errors.push('Row ' + rowNum + ': invalid or missing Amount.'); return; }

    if (bulkType === 'Vendor') {
      if (!obj.VendorName && !obj.CNIC) { errors.push('Row ' + rowNum + ': Vendor name or CNIC is required.'); return; }
      const known = obj.CNIC ? vendors[String(obj.CNIC).toLowerCase()] : null;
      const name = obj.VendorName || (known ? known.VendorName : '');
      const iban = obj.IBAN || (known ? known.IBAN : '');
      const bankName = obj.BankName || (known ? known.BankName : '');
      const mismatch = !!known && ((obj.VendorName && known.VendorName && obj.VendorName !== known.VendorName) || (obj.IBAN && known.IBAN && obj.IBAN !== known.IBAN) || (obj.BankName && known.BankName && obj.BankName !== known.BankName));
      if (!name) { errors.push('Row ' + rowNum + ': Vendor name is required for a new vendor.'); return; }
      if (obj.CNIC && !isValidCnicOrNtn(obj.CNIC)) { errors.push('Row ' + rowNum + ': CNIC/NTN must be a CNIC (35201-1222334-4) or an NTN (12345678).'); return; }
      if (iban && !isValidIban(iban)) { errors.push('Row ' + rowNum + ': IBAN must start with PK and be 24 characters in total.'); return; }
      const incomeTax = Number(obj.IncomeTaxAmount) || 0, salesTax = Number(obj.SalesTaxAmount) || 0, pst = Number(obj.PSTAmount) || 0,
        security = Number(obj.SecurityAmount) || 0, penalty = Number(obj.PenaltyAmount) || 0, other = Number(obj.OtherDeductionAmount) || 0;
      if (incomeTax > 0 && !String(obj.FBRSection || '').trim()) { errors.push('Row ' + rowNum + ': FBRSection is required when IncomeTaxAmount is entered - state the FBR section the tax was calculated under (e.g. 153(1)(a) - Supply of Goods).'); return; }
      items.push({ payeeType: 'Vendor', name, cnic: obj.CNIC, iban, bankName, __existingMismatch: mismatch, fbrSection: obj.FBRSection || '', amount, incomeTaxAmount: incomeTax, salesTaxAmount: salesTax, pstAmount: pst, securityAmount: security, penaltyAmount: penalty, otherDeductionAmount: other, net: amount - incomeTax - salesTax - pst - security - penalty - other, description: obj.Description });
    } else if (bulkType === 'Student') {
      if (!obj.StudentID) { errors.push('Row ' + rowNum + ': Student ID is required.'); return; }
      const known = students[String(obj.StudentID).toLowerCase()];
      const name = obj.Name || (known ? known.Name : ''), cnic = obj.CNIC || (known ? known.CNIC : ''), iban = obj.IBAN || (known ? known.IBAN : '');
      const program = obj.Program || (known ? known.Program : ''), session = obj.Session || (known ? known.Session : ''), shift = obj.Shift || (known ? known.Shift : '');
      const mismatch = !!known && ((obj.Name && known.Name && obj.Name !== known.Name) || (obj.CNIC && known.CNIC && obj.CNIC !== known.CNIC) || (obj.IBAN && known.IBAN && obj.IBAN !== known.IBAN));
      if (!name) { errors.push('Row ' + rowNum + ': Name is required for a new student.'); return; }
      if (cnic && !isValidCnic(cnic)) { errors.push('Row ' + rowNum + ': CNIC must be in the format 35201-1222334-4.'); return; }
      if (iban && !isValidIban(iban)) { errors.push('Row ' + rowNum + ': IBAN must start with PK and be 24 characters in total.'); return; }
      const deduction = Number(obj.DeductionAmount) || 0;
      const oa = resolveOfficeAccount(obj, rowNum);
      items.push({ payeeType: 'Student', studentId: obj.StudentID, name, cnic, iban, __existingMismatch: mismatch, program, session, shift, amount, incomeTaxAmount: 0, salesTaxAmount: 0, pstAmount: 0, securityAmount: 0, penaltyAmount: 0, otherDeductionAmount: deduction, net: amount - deduction, description: obj.Description, receivingOfficeId: oa.receivingOfficeId, payFromAccountId: oa.payFromAccountId, receivingOfficeName: obj.ReceivingOffice || '', payFromAccountName: obj.PayFromAccount || '' });
    } else {
      const payeeType = obj.PayeeType === 'NonUEEmployee' ? 'NonUEEmployee' : 'Employee';
      const nature = obj.Nature || obj.EmployeeCategory;
      if (!nature) { errors.push('Row ' + rowNum + ': Nature is required.'); return; }
      const isTaxableCategory = EMPLOYEE_149_NATURES.includes(nature) || nature === SECTION_156_NATURE || (payeeType === 'Employee' && UE_ONLY_TAXABLE_NATURES.includes(nature));
      const isNonTaxable = payeeType === 'Employee' && UE_NON_TAXABLE_NATURES_BULK.includes(nature);
      if (!isTaxableCategory && !isNonTaxable) { errors.push('Row ' + rowNum + ': "' + nature + '" is not a valid Nature for ' + (payeeType === 'Employee' ? 'a UE Employee' : 'a Non-UE Employee') + '.'); return; }
      if (payeeType === 'NonUEEmployee' && isNonTaxable) { errors.push('Row ' + rowNum + ': Non-UE Employees have no non-taxable category - "' + nature + '" is not valid.'); return; }
      let name, cnic, iban, bankName, mismatch = false;
      if (payeeType === 'Employee') {
        const emp = employees[String(obj.EmployeeID).toLowerCase()];
        if (!emp) { errors.push('Row ' + rowNum + ': Employee ID "' + obj.EmployeeID + '" not found.'); return; }
        name = emp.Name; cnic = emp.CNIC; iban = emp.IBAN; bankName = emp.BankName;
      } else {
        const known = obj.CNIC ? nonueMap[String(obj.CNIC).toLowerCase()] : null;
        name = obj.Name || (known ? known.Name : ''); cnic = obj.CNIC; iban = obj.IBAN || (known ? known.IBAN : ''); bankName = obj.BankName || (known ? known.BankName : '');
        mismatch = !!known && ((obj.Name && known.Name && obj.Name !== known.Name) || (obj.IBAN && known.IBAN && obj.IBAN !== known.IBAN) || (obj.BankName && known.BankName && obj.BankName !== known.BankName));
        if (!cnic || !name) { errors.push('Row ' + rowNum + ': CNIC and Name are required for a new Non-UE Employee.'); return; }
        if (!isValidCnic(cnic)) { errors.push('Row ' + rowNum + ': CNIC must be in the format 35201-1222334-4.'); return; }
        if (iban && !isValidIban(iban)) { errors.push('Row ' + rowNum + ': IBAN must start with PK and be 24 characters in total.'); return; }
      }
      // Income Tax for a taxable Nature is calculated by the server when the bill is saved.
      const incomeTax = isNonTaxable ? 0 : null, net = isNonTaxable ? amount : null;
      if (nature === 'Thesis Evaluation' && (!obj.ThesisClass || !obj.ThesisStudentName)) { errors.push('Row ' + rowNum + ': Thesis Evaluation requires both Class and Student Name.'); return; }
      if (nature === 'Benevolent Fund' && !obj.BenevolentFundSubCategory) { errors.push('Row ' + rowNum + ': Benevolent Fund requires a sub-category.'); return; }
      if (VISITING_NATURES.includes(nature) && (!obj.VisitingProgram || !obj.VisitingSubject || !obj.VisitingCrHrs || !obj.VisitingRate || !obj.VisitingLectures)) { errors.push('Row ' + rowNum + ': ' + nature + ' requires Program, Subject, Cr. Hrs., Rate, and Lectures.'); return; }
      let nonUeTaxMethod = 'Section149', fbrStatus = 'NonFiler';
      if (payeeType === 'NonUEEmployee' && String(obj.TaxMethod || '').trim() === 'Section153_1b') {
        nonUeTaxMethod = 'Section153_1b';
        const status = String(obj.TaxpayerStatus || '').trim().toLowerCase();
        if (status !== 'active' && status !== 'inactive') { errors.push('Row ' + rowNum + ': TaxpayerStatus must be Active or Inactive when TaxMethod is Section153_1b.'); return; }
        fbrStatus = status === 'active' ? 'Filer' : 'NonFiler';
      }
      const oa = resolveOfficeAccount(obj, rowNum);
      items.push({ payeeType, employeeId: obj.EmployeeID, name, cnic, iban, bankName, amount, billNature: nature, __existingMismatch: mismatch, incomeTaxAmount: incomeTax, salesTaxAmount: 0, pstAmount: 0, securityAmount: 0, penaltyAmount: 0, otherDeductionAmount: 0, net, description: obj.Description, examSubCategory: obj.ExamSubCategory, thesisClass: obj.ThesisClass, thesisStudentName: obj.ThesisStudentName, benevolentFundSubCategory: obj.BenevolentFundSubCategory, visitingProgram: obj.VisitingProgram, visitingSubject: obj.VisitingSubject, visitingCrHrs: obj.VisitingCrHrs, visitingRate: obj.VisitingRate, visitingLectures: obj.VisitingLectures, nonUeTaxMethod, fbrStatus, affidavitLowIncome: isTruthyCsv(obj.AffidavitLowIncome), receivingOfficeId: oa.receivingOfficeId, payFromAccountId: oa.payFromAccountId, receivingOfficeName: obj.ReceivingOffice || '', payFromAccountName: obj.PayFromAccount || '' });
    }
  });
  return { items, errors };
}
