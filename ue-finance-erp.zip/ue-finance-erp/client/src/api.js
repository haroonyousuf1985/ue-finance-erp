/* api.js - talks to this app's own server. The login token is kept for this browser tab only. */
const T = 'cbs_token', U = 'cbs_user';
let onExpired = null;

async function post(url, body) {
  let resp;
  try { resp = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); }
  catch (e) { throw new Error('Cannot reach the server. Check your internet connection and try again.'); }
  let data;
  try { data = await resp.json(); } catch (e) { throw new Error('The server sent an unreadable reply (HTTP ' + resp.status + ').'); }
  if (!data.ok) throw new Error(data.error || 'Unknown server error.');
  return data.result;
}

export const session = {
  token: () => { try { return sessionStorage.getItem(T); } catch (e) { return null; } },
  user: () => { try { const u = sessionStorage.getItem(U); return u ? JSON.parse(u) : null; } catch (e) { return null; } },
  save(user, token) { try { sessionStorage.setItem(U, JSON.stringify(user)); sessionStorage.setItem(T, token); } catch (e) {} },
  clear() { try { sessionStorage.removeItem(U); sessionStorage.removeItem(T); } catch (e) {} },
  onExpired(fn) { onExpired = fn; }
};

export function login(username, password) { return post('/api/login', { username, password }); }
export function logout() { const t = session.token(); return t ? post('/api/logout', { token: t }).catch(() => {}) : Promise.resolve(); }

/* gs('getBillsByStatus', 'Received', '') -> result, or throws an Error with a readable message */
export async function gs(fn, ...args) {
  try { return await post('/api/call', { token: session.token(), fn, args }); }
  catch (e) {
    if (/SESSION_EXPIRED|SESSION_REQUIRED/.test(e.message) && onExpired) onExpired();
    throw e;
  }
}
