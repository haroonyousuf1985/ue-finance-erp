import React, { createContext, useCallback, useContext, useRef, useState } from 'react';

/* ---------- toasts (the little messages at the bottom) ---------- */
const ToastCtx = createContext(null);
export function useToast() { return useContext(ToastCtx); }

export function ToastProvider({ children }) {
  const [items, setItems] = useState([]);
  const id = useRef(0);
  const remove = useCallback(i => setItems(list => list.filter(t => t.id !== i)), []);
  const toast = useCallback((message, type = 'success', sticky = false) => {
    const i = ++id.current;
    setItems(list => list.concat({ id: i, message, type }));
    if (!sticky) setTimeout(() => remove(i), type === 'error' ? 4500 : 2500);
    return () => remove(i);
  }, [remove]);

  /* run(fn, loadingText, successText): shows "loading", then success or the error. Returns fn's result (or {success:false}). */
  const run = useCallback(async (fn, loadingText, successText) => {
    const stop = toast(loadingText, 'loading', true);
    try {
      const result = await fn();
      stop();
      if (result && result.success === false) { toast(result.message || 'Failed.', 'error'); return result; }
      if (successText) toast(successText, 'success');
      return result;
    } catch (e) {
      stop(); toast(e.message || 'Something went wrong.', 'error');
      return { success: false, message: e.message };
    }
  }, [toast]);

  return (
    <ToastCtx.Provider value={{ toast, run }}>
      {children}
      <div id="toastWrap">
        {items.map(t => (
          <div key={t.id} className={'toast ' + t.type}>{t.type === 'loading' && <div className="spinner" />}<span>{t.message}</span></div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function EmptyRow({ cols, text, error }) {
  return <tr><td colSpan={cols} style={{ textAlign: 'center', color: error ? 'var(--danger)' : 'var(--text-muted)' }}>{text || 'No bills here right now.'}</td></tr>;
}

export function FYSelect({ value, onChange, options, id }) {
  return (
    <select id={id} value={value} onChange={e => onChange(e.target.value)}>
      <option value="">All Years</option>
      {options.map(fy => <option key={fy} value={fy}>{fy}</option>)}
    </select>
  );
}

export function Modal({ children, onClose, maxWidth = 560, id, z = 105 }) {
  return (
    <div id={id} style={{ position: 'fixed', inset: 0, background: '#0007', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: z, padding: 16 }}
      onMouseDown={e => { if (e.target === e.currentTarget && onClose) onClose(); }}>
      <div className="card" style={{ background: 'var(--navy-light)', maxWidth, width: '100%', margin: 0, maxHeight: '90vh', overflowY: 'auto' }}>{children}</div>
    </div>
  );
}

export function BillLink({ id, onOpen }) {
  return <a href="#bill" onClick={e => { e.preventDefault(); onOpen(id); }} style={{ color: 'var(--accent)', fontWeight: 600, textDecoration: 'underline' }}>{id}</a>;
}
