/* bridge.js - gives the not-yet-converted screens the small piece of Google's browser API (google.script.run)
   they were written against, and sends each call to this app's own server. */
(function () {
  async function post(url, body) {
    let resp;
    try { resp = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); }
    catch (e) { throw new Error('Cannot reach the server. Check your internet connection and try again.'); }
    let data;
    try { data = await resp.json(); } catch (e) { throw new Error('The server sent an unreadable reply (HTTP ' + resp.status + ').'); }
    if (!data.ok) throw new Error(data.error || 'Unknown server error.');
    return data.result;
  }
  var ROUTES = {
    apiLogin: function (u, p) { return post('/api/login', { username: u, password: p }); },
    apiLogout: function (t) { return post('/api/logout', { token: t }); },
    apiCall: function (token, fn, args) { return post('/api/call', { token: token, fn: fn, args: args }); }
  };
  function makeRunner(onSuccess, onFailure) {
    return new Proxy({}, {
      get: function (_, name) {
        if (name === 'withSuccessHandler') return function (fn) { return makeRunner(fn, onFailure); };
        if (name === 'withFailureHandler') return function (fn) { return makeRunner(onSuccess, fn); };
        if (name === 'withUserObject') return function () { return makeRunner(onSuccess, onFailure); };
        if (typeof name !== 'string' || name === 'then') return undefined;
        return function () {
          var args = Array.prototype.slice.call(arguments);
          var route = ROUTES[name];
          var p = route ? route.apply(null, args) : Promise.reject(new Error('Unknown server function: ' + name));
          p.then(function (r) { if (onSuccess) onSuccess(r); }, function (e) { if (onFailure) onFailure(e); else console.error(e); });
        };
      }
    });
  }
  window.google = window.google || {};
  window.google.script = { run: makeRunner(null, null), host: { close: function () {} } };
})();
