/* frame.js - runs inside the page that shows the not-yet-converted screens within the React website. */
(function () {
  var qs = new URLSearchParams(location.search), tab = qs.get('tab'), sub = qs.get('sub');
  if (sub) { var st = document.createElement('style'); st.textContent = 'nav.subtabs{display:none !important}'; document.head.appendChild(st); }
  if (tab === 'admin' && sub === 'tools') {
    // the Setup & Records sections are real React pages now; show only the sections that are not converted yet
    var st2 = document.createElement('style');
    st2.textContent = '#tab-admin > .no-print:first-child, #adm-alloc, #adm-heads, #adm-users, #adm-taxsettings, #adm-employees, #adm-nonue, #adm-bankaccounts, #adm-offices, #adm-manageentries, #adm-pipeline, #adm-syscheck { display:none !important; }';
    document.head.appendChild(st2);
  }
  // a session that ended is handled by the React website (it shows the login page)
  window.forceRelogin_ = function () { try { parent.postMessage({ type: 'session-ended' }, '*'); } catch (e) {} };
  window.logout = function () { try { parent.postMessage({ type: 'session-ended' }, '*'); } catch (e) {} };
  window.addEventListener('load', function () {
    setTimeout(function () {
      try { if (CURRENT_USER && tab) { showTab(tab); if (sub && tab !== 'admin') showSubTab(sub); if (qs.get('diary') && tab === 'entry') enterDiaryBill(qs.get('diary')); } } catch (e) { console.error(e); }
    }, 0);
  });
  window.addEventListener('storage', function (e) {
    if (e.key === 'themePreference') document.body.classList.toggle('light', e.newValue !== 'dark');
  });
  // the website's own password window handles password changes
  window.showPasswordChange = function () { try { parent.postMessage({ type: 'change-password' }, '*'); } catch (e) {} };
})();
